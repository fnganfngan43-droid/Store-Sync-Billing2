import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { describe, expect, it, vi } from 'vitest';

describe('Sales invoice print data', () => {
  it('resolves a missing unit label using the saved unit ID without modifying the invoice', async () => {
    document.body.innerHTML = '<main id="invoices"></main>';
    const invoice = {
      id: 7, invoiceNo: '7', date: '2026-10-20', type: 'نقدي', currencyId: 1,
      beforeDiscount: 30, net: 30, discount: 0,
      lines: [{ itemCode: 'A', itemName: 'صنف', unitId: '2', unitName: '', qty: 3, price: 10, total: 30 }],
    };
    const print = vi.fn();
    const stores = {
      CUSTOMERS: 'customers', INV_WAREHOUSES: 'warehouses', BANKS: 'banks', CASHBOXES: 'cashboxes',
      CURRENCIES: 'currencies', INV_ITEMS: 'items', INV_UNITS: 'units', INV_GROUPS_MAIN: 'groups', SALES_INVOICES: 'invoices',
    };
    const fixtures: Record<string, unknown[]> = {
      currencies: [{ id: 1, name: 'ريال', symbol: 'ر', type: 'محلي', rate: 1 }],
      units: [{ id: 2, name: 'حبة' }], invoices: [invoice],
    };
    const context = vm.createContext({
      document, console, STORES: stores,
      FarisDB: { getAll: async (store: string) => fixtures[store] || [], get: async () => invoice },
      SalesConfig: { getSettings: async () => ({ numberingMode: 'يدوي' }) },
      Utils: {
        escapeHtml: (value: unknown) => String(value ?? ''), attachAutocomplete: () => {},
        el: (html: string) => { const template = document.createElement('template'); template.innerHTML = html.trim(); return template.content.firstElementChild; },
      },
      ReportPrint: { print, amountToWords: () => '' },
    });
    vm.runInContext(readFileSync('public/faris/js/screens/sales/sales-invoices.js', 'utf8') + '\nglobalThis.invoices = SalesInvoices;', context);
    await context['invoices'].render(document.getElementById('invoices'));
    document.getElementById('si-search')?.click();
    await vi.waitFor(() => expect(document.querySelector('#si-list-rows tr[data-id="7"]')).not.toBeNull());
    (document.querySelector('#si-list-rows tr[data-id="7"]') as HTMLElement).click();
    document.getElementById('si-print')?.click();
    await vi.waitFor(() => expect(print).toHaveBeenCalledOnce());
    const data = print.mock.calls[0]?.[0];
    expect(data.rows[0][2]).toBe('حبة');
    expect(invoice.lines[0]?.unitName).toBe('');
  });
});