import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { beforeEach, describe, expect, it, vi } from 'vitest';

type Block = { rows: string[][]; totals: { summaryRow: string[]; balance: number } };
type Result = { blocks: Block[] };
let getResult: () => Promise<Result | null>;
const stores = {
  CURRENCIES: 'currencies', COUNTRIES: 'countries', GOVERNORATES: 'governorates', LOCATIONS: 'locations',
  ACCOUNTS: 'accounts', CUSTOMERS: 'customers', CASHBOXES: 'cashboxes', BANKS: 'banks', SUPPLIERS: 'suppliers',
  OPENING_BALANCES: 'opening', JOURNAL: 'journal', VOUCHERS: 'vouchers', CURRENCY_EXCHANGES: 'exchange',
};
const fixtures: Record<string, Record<string, unknown>[]> = {
  currencies: [{ id: 1, symbol: 'ر', name: 'محلي' }, { id: 2, symbol: '$', name: 'دولار' }],
  countries: [{ id: 1, name: 'أ' }, { id: 2, name: 'ب' }],
  governorates: [{ id: 10, countryId: 1, name: 'أ' }, { id: 20, countryId: 2, name: 'ب' }],
  locations: [{ governorateId: 10, city: 'عدن' }, { governorateId: 20, city: 'صنعاء' }],
  accounts: [{ code: '110', name: 'العملاء', type: 'فرعي', analyticType: 'عميل', currencies: [1, 2] }],
  customers: [
    { parentAccountCode: '110', partyNumber: '1', name: 'أحمد', currencies: [1, 2], countryId: 1, governorateId: 10, city: 'عدن' },
    { parentAccountCode: '110', partyNumber: '2', name: 'باسم', currencies: [1, 2], countryId: 2, governorateId: 20, city: 'صنعاء' },
    { parentAccountCode: '110', partyNumber: '3', name: 'جمال', currencies: [1] },
  ],
  opening: [
    { accountCode: '110', analyticCode: '110-1', date: '2026-01-02', currencyId: 1, debit: 100, credit: 40 },
    { accountCode: '110', analyticCode: '110-2', date: '2026-01-02', currencyId: 1, debit: 20, credit: 120 },
    { accountCode: '110', analyticCode: '110-1', date: '2026-01-02', currencyId: 2, debit: 1000, credit: 0 },
    { accountCode: '110', analyticCode: '110-2', date: '2025-12-31', currencyId: 1, debit: 999, credit: 0 },
  ],
  journal: [{ date: '2026-01-03', lines: [{ accountCode: '110', analyticCode: '110-1', currencyId: 1, debit: 5, credit: 0 }] }],
};

function field(id: string, value: string) {
  const el = document.getElementById(id) as HTMLInputElement | HTMLSelectElement | null;
  if (!el) throw new Error(`Missing field ${id}`);
  el.value = value;
  return el;
}

async function view() {
  const previous = await getResult();
  document.getElementById('as-view')?.click();
  await vi.waitFor(async () => {
    const next = await getResult();
    expect(next).not.toBeNull();
    expect(next).not.toBe(previous);
  });
  const result = await getResult();
  if (!result) throw new Error('No report');
  const first = result.blocks[0];
  if (!first) throw new Error('No report block');
  return [first, ...result.blocks.slice(1)] as [Block, ...Block[]];
}

beforeEach(async () => {
  document.body.innerHTML = '<main id="report"></main>';
  const ctx = vm.createContext({
    document, console, STORES: stores,
    FarisDB: {
      getAll: async (store: string) => fixtures[store] || [],
      getAllByIndex: async (store: string, index: string, value: unknown) => (fixtures[store] || []).filter(row => row[index] === value),
    },
    Utils: { escapeHtml: (v: unknown) => String(v ?? ''), attachAutocomplete: () => {}, toast: vi.fn() },
    ReportPrint: {
      toolbarHtml: () => '', amountToWords: () => '',
      bindToolbar: (_id: string, getter: typeof getResult) => { getResult = getter; },
    },
    AccountAnalyticPicker: { formatAnalyticDisplay: (_account: string, analytic: string) => analytic },
  });
  vm.runInContext(readFileSync('public/faris/js/screens/reports/report-data.js', 'utf8'), ctx);
  vm.runInContext(readFileSync('public/faris/js/screens/reports/account-statement.js', 'utf8') + '\nglobalThis.report = ReportAccountStatement;', ctx);
  await ctx['report'].render(document.getElementById('report'));
  field('as-from', '2026-01-01');
  field('as-to', '2026-12-31');
  field('as-report-type', 'اجمالي');
  field('as-account-type', 'عميل');
  field('as-currency', '1');
});

describe('Account statement filters and summary balances', () => {
  it('puts net debit 65 and net credit 100 on their respective sides, with final credit 35', async () => {
    const [block] = await view();
    expect(block.rows[0]?.slice(2)).toEqual(['65.00', '']);
    expect(block.rows[1]?.slice(2)).toEqual(['', '100.00']);
    expect(block.totals.summaryRow.slice(2)).toEqual(['', '35.00']);
    expect(block.totals.balance).toBe(-35);
  });

  it('filters actual customer locations, excluding customers without a location', async () => {
    field('as-country-from', '1');
    field('as-country-to', '1');
    const [block] = await view();
    expect(block.rows.map(row => row[0])).toEqual(['1']);
    expect(block.totals.summaryRow.slice(2)).toEqual(['65.00', '']);
  });

  it('applies governorate and city ranges to summary members', async () => {
    field('as-country-from', '2').dispatchEvent(new Event('change'));
    await vi.waitFor(() => expect(document.querySelector('#as-gov-from option[value="20"]')).not.toBeNull());
    field('as-gov-from', '20').dispatchEvent(new Event('change'));
    field('as-gov-to', '20'); // add the upper bound option through its country selector
    field('as-country-to', '2').dispatchEvent(new Event('change'));
    await vi.waitFor(() => expect(document.querySelector('#as-gov-to option[value="20"]')).not.toBeNull());
    field('as-gov-to', '20').dispatchEvent(new Event('change'));
    field('as-city-from', 'صنعاء');
    field('as-city-to', 'صنعاء');
    const [block] = await view();
    expect(block.rows.map(row => row[0])).toEqual(['2']);
  });

  it('uses selected currency and operation for amount conditions', async () => {
    field('as-filter-by', 'المبلغ');
    field('as-amount-op', '=');
    field('as-amount-value', '60');
    field('as-op-type', 'opening');
    const [block] = await view();
    expect(block.rows.map(row => row[0])).toEqual(['1']);
    expect(block.rows[0]?.slice(2)).toEqual(['60.00', '']);
  });

  it('orders the displayed summary members by account number descending', async () => {
    field('as-filter-by', 'رقم الحساب');
    field('as-sort', 'تنازلي');
    const [block] = await view();
    expect(block.rows.map(row => row[0])).toEqual(['3', '2', '1']);
  });

  it('orders names descending and filters negative balances by amount', async () => {
    field('as-filter-by', 'اسم الحساب');
    field('as-sort', 'تنازلي');
    expect((await view())[0].rows.map(row => row[0])).toEqual(['3', '2', '1']);
    field('as-filter-by', 'المبلغ');
    field('as-amount-op', '<');
    field('as-amount-value', '0');
    const [block] = await view();
    expect(block.rows.map(row => row[0])).toEqual(['2']);
    expect(block.totals.summaryRow.slice(2)).toEqual(['', '100.00']);
  });

  it('does not combine foreign currency movements into the chosen currency', async () => {
    field('as-currency', '2');
    const [block] = await view();
    expect(block.rows[0]?.slice(2)).toEqual(['1000.00', '']);
    expect(block.totals.summaryRow.slice(2)).toEqual(['1000.00', '']);
  });

  it('clears stale city selection after the country changes', async () => {
    field('as-country-from', '1').dispatchEvent(new Event('change'));
    field('as-gov-from', '10').dispatchEvent(new Event('change'));
    field('as-city-from', 'عدن');
    field('as-country-from', '2').dispatchEvent(new Event('change'));
    await vi.waitFor(() => expect((document.getElementById('as-city-from') as HTMLSelectElement).value).toBe(''));
  });
});