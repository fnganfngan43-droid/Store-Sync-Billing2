# Invoice printing
- [x] Hide sales invoice row numbering and resolve the printed unit name.
- [x] Stack previous and current customer balances at the right-hand start below the table.
- [x] Verify invoice printing with isolated fixtures and run report regression tests.
- [x] Equalize invoice side margins, pair balances with totals, and add an outer invoice border.
- [x] Verify the revised printed invoice with isolated fixtures and report regression tests.

# Sales toolbars
- [x] Hide edit / print / journal / delete buttons in sales invoices and sales returns screens until an invoice is selected from the search list.
- [x] Verify show/hide states in both screens with Playwright against seeded fixtures.

# Sales summary report
- [x] Reorder summary report columns: date, invoice no, account no, account name, currency, amount, reference no.
- [x] Verify the new summary table in the preview with seeded fixtures.
