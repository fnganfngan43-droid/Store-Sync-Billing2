/* =========================================================
   تهيئة المبيعات - إعدادات شاملة بعدة تبويبات
   ========================================================= */

const SalesConfig = (function () {
  const SETTINGS_ID = 'main';

  const DEFAULTS = {
    allowZeroPriceSale: false,
    allowPriceEditAfterSave: false,
    requireAgent: false,
    printUnitCost: false,
    allowTaxRateEdit: false,
    enableItemDiscount: true,
    enableInvoiceDiscount: true,
    enableCash: true,
    enableBankTransfer: true,
    enableCredit: true,
    requireBankForTransfer: true,
    requireTransferNumber: true,
    requireCustomerForCredit: true,
    allowCashCustomerSale: true,
    numberingMode: 'تلقائي',
    invoicePrefix: 'INV',
    nextInvoiceNumber: 1,
    separateNumberingPerType: true,
    printFormat: 'A4',
    printBarcode: true,
    printHeaderNotes: true,
    printItemNotes: false,
    preventSaveWithoutCustomer: true,
    preventSaveWithoutWarehouse: true,
    lockInvoiceAfterDay: false,
    allowExceedCreditLimit: false
  };

  let currentTab = 'general';

  async function render(container) {
    currentTab = 'general';
    const settings = await getSettings();

    container.innerHTML = `
      <nav class="sub-nav" id="sc-tabs">
        ${tabButton('general', 'الإعدادات العامة')}
        ${tabButton('payment', 'أنواع الفواتير والدفع')}
        ${tabButton('numbering', 'ترقيم الفواتير')}
        ${tabButton('print', 'الطباعة والتقرير')}
        ${tabButton('control', 'صلاحيات وضوابط')}
      </nav>
      <div id="sc-tab-content"></div>
      <div class="toolbar" style="margin-top:14px;">
        <button class="btn btn-primary" id="sc-save">💾 حفظ</button>
        <button class="btn btn-secondary" id="sc-defaults">↺ افتراضي</button>
        <button class="btn btn-ghost" id="sc-exit">🚪 خروج</button>
      </div>
    `;

    container.querySelector('#sc-tabs').addEventListener('click', (e) => {
      const btn = e.target.closest('.nav-icon-btn');
      if (!btn) return;
      currentTab = btn.dataset.key;
      renderTab();
    });
    container.querySelector('#sc-save').addEventListener('click', onSave);
    container.querySelector('#sc-defaults').addEventListener('click', applyDefaultsToForm);
    container.querySelector('#sc-exit').addEventListener('click', () => App.show('home', { replace: true }));

    renderTab();
  }

  function tabButton(key, label) {
    return `<button class="nav-icon-btn ${key === 'general' ? 'active' : ''}" data-key="${key}"><span class="nav-label">${label}</span></button>`;
  }
  function selectTabButton(key) {
    document.querySelectorAll('#sc-tabs .nav-icon-btn').forEach(b => b.classList.toggle('active', b.dataset.key === key));
  }

  async function renderTab() {
    selectTabButton(currentTab);
    const s = await getSettings();
    const el = document.getElementById('sc-tab-content');
    if (currentTab === 'general') el.innerHTML = generalTabHtml(s);
    else if (currentTab === 'payment') el.innerHTML = paymentTabHtml(s);
    else if (currentTab === 'numbering') el.innerHTML = numberingTabHtml(s);
    else if (currentTab === 'print') el.innerHTML = printTabHtml(s);
    else if (currentTab === 'control') el.innerHTML = controlTabHtml(s);
    Utils.applyInlineLabels(el);
  }

  function generalTabHtml(s) {
    return `
      <div class="form-grid">
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-zero-price" ${s.allowZeroPriceSale ? 'checked' : ''}> السماح بالبيع بسعر صفر (بيع مجاني)</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-price-edit" ${s.allowPriceEditAfterSave ? 'checked' : ''}> السماح بتعديل السعر بعد الحفظ</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-require-agent" ${s.requireAgent ? 'checked' : ''}> إجباري اختيار المندوب</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-print-unit-cost" ${s.printUnitCost ? 'checked' : ''}> طباعة تكلفة الوحدة في الفاتورة (أخفِها عن العملاء عادة)</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-tax-edit" ${s.allowTaxRateEdit ? 'checked' : ''}> السماح بتعديل نسبة الضريبة</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-item-discount" ${s.enableItemDiscount ? 'checked' : ''}> تفعيل خصم الصنف (% أو مبلغ)</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-invoice-discount" ${s.enableInvoiceDiscount ? 'checked' : ''}> تفعيل خصم الفاتورة</label>
      </div>
    `;
  }

  function paymentTabHtml(s) {
    return `
      <div class="form-grid">
        <label class="required field-wide">تفعيل نوع الفاتورة</label>
        <label class="checkbox-row"><input type="checkbox" id="sc-enable-cash" ${s.enableCash ? 'checked' : ''}> نقدي</label>
        <label class="checkbox-row"><input type="checkbox" id="sc-enable-transfer" ${s.enableBankTransfer ? 'checked' : ''}> تحويل بنكي</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-enable-credit" ${s.enableCredit ? 'checked' : ''}> آجل</label>

        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-require-bank" ${s.requireBankForTransfer ? 'checked' : ''}> إجباري اختيار البنك للتحويل</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-require-transfer-no" ${s.requireTransferNumber ? 'checked' : ''}> إجباري رقم التحويل</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-require-customer-credit" ${s.requireCustomerForCredit ? 'checked' : ''}> إجباري اختيار العميل للآجل</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-allow-cash-customer" ${s.allowCashCustomerSale ? 'checked' : ''}> السماح بالبيع للعميل النقدي (عميل "نقدي" افتراضي)</label>
      </div>
    `;
  }

  function numberingTabHtml(s) {
    return `
      <div class="form-grid">
        <label class="required field-wide">ترقيم الفواتير
          <select id="sc-numbering-mode"><option value="تلقائي">تلقائي</option><option value="يدوي">يدوي</option></select>
        </label>
        <label class="optional">بادئة رقم الفاتورة<input type="text" id="sc-prefix" value="${Utils.escapeHtml(s.invoicePrefix)}"></label>
        <label class="required">رقم الفاتورة التالي<input type="number" id="sc-next-number" value="${s.nextInvoiceNumber}" min="1"></label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-separate-numbering" ${s.separateNumberingPerType ? 'checked' : ''}> ترقيم منفصل لكل نوع (أرقام منفصلة للنقدي والآجل)</label>
      </div>
    `;
  }

  function printTabHtml(s) {
    return `
      <div class="form-grid">
        <label class="required field-wide">حجم التقرير للطباعة
          <select id="sc-print-format"><option value="A4">A4</option><option value="80mm">80mm</option></select>
        </label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-print-barcode" ${s.printBarcode ? 'checked' : ''}> طباعة الباركود في الفاتورة</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-print-header-notes" ${s.printHeaderNotes ? 'checked' : ''}> طباعة ملاحظات الهيدر</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-print-item-notes" ${s.printItemNotes ? 'checked' : ''}> طباعة ملاحظات الصنف</label>
      </div>
    `;
  }

  function controlTabHtml(s) {
    return `
      <div class="form-grid">
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-prevent-no-customer" ${s.preventSaveWithoutCustomer ? 'checked' : ''}> منع حفظ الفاتورة بدون عميل</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-prevent-no-warehouse" ${s.preventSaveWithoutWarehouse ? 'checked' : ''}> منع حفظ الفاتورة بدون مخزن</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-lock-after-day" ${s.lockInvoiceAfterDay ? 'checked' : ''}> قفل الفاتورة بعد يوم من الحفظ</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="sc-exceed-credit" ${s.allowExceedCreditLimit ? 'checked' : ''}> السماح بتجاوز حد ائتمان العميل</label>
      </div>
    `;
  }

  function readFormIntoSettings() {
    const s = { id: SETTINGS_ID };
    const byId = (id) => document.getElementById(id);

    if (byId('sc-zero-price')) {
      s.allowZeroPriceSale = byId('sc-zero-price').checked;
      s.allowPriceEditAfterSave = byId('sc-price-edit').checked;
      s.requireAgent = byId('sc-require-agent').checked;
      s.printUnitCost = byId('sc-print-unit-cost').checked;
      s.allowTaxRateEdit = byId('sc-tax-edit').checked;
      s.enableItemDiscount = byId('sc-item-discount').checked;
      s.enableInvoiceDiscount = byId('sc-invoice-discount').checked;
    }
    if (byId('sc-enable-cash')) {
      s.enableCash = byId('sc-enable-cash').checked;
      s.enableBankTransfer = byId('sc-enable-transfer').checked;
      s.enableCredit = byId('sc-enable-credit').checked;
      s.requireBankForTransfer = byId('sc-require-bank').checked;
      s.requireTransferNumber = byId('sc-require-transfer-no').checked;
      s.requireCustomerForCredit = byId('sc-require-customer-credit').checked;
      s.allowCashCustomerSale = byId('sc-allow-cash-customer').checked;
    }
    if (byId('sc-numbering-mode')) {
      s.numberingMode = byId('sc-numbering-mode').value;
      s.invoicePrefix = byId('sc-prefix').value.trim();
      s.nextInvoiceNumber = Number(byId('sc-next-number').value) || 1;
      s.separateNumberingPerType = byId('sc-separate-numbering').checked;
    }
    if (byId('sc-print-format')) {
      s.printFormat = byId('sc-print-format').value;
      s.printBarcode = byId('sc-print-barcode').checked;
      s.printHeaderNotes = byId('sc-print-header-notes').checked;
      s.printItemNotes = byId('sc-print-item-notes').checked;
    }
    if (byId('sc-prevent-no-customer')) {
      s.preventSaveWithoutCustomer = byId('sc-prevent-no-customer').checked;
      s.preventSaveWithoutWarehouse = byId('sc-prevent-no-warehouse').checked;
      s.lockInvoiceAfterDay = byId('sc-lock-after-day').checked;
      s.allowExceedCreditLimit = byId('sc-exceed-credit').checked;
    }
    return s;
  }

  async function onSave() {
    const current = await getSettings();
    const partial = readFormIntoSettings();
    const merged = { ...current, ...partial, id: SETTINGS_ID };
    await FarisDB.put(STORES.SALES_SETTINGS, merged);
    Utils.toast('تم حفظ إعدادات المبيعات', 'success');
  }

  async function applyDefaultsToForm() {
    const ok = await Utils.confirmDialog('سيتم إرجاع كل حقول هذا التبويب للقيم الافتراضية (دون حفظ فوري). هل تريد المتابعة؟');
    if (!ok) return;
    document.getElementById('sc-tab-content').dataset.defaults = '1';
    await renderTabWithDefaults();
    Utils.toast('أُعيدت القيم الافتراضية، اضغط "حفظ" لتثبيتها', 'info');
  }

  async function renderTabWithDefaults() {
    selectTabButton(currentTab);
    const el = document.getElementById('sc-tab-content');
    const s = DEFAULTS;
    if (currentTab === 'general') el.innerHTML = generalTabHtml(s);
    else if (currentTab === 'payment') el.innerHTML = paymentTabHtml(s);
    else if (currentTab === 'numbering') el.innerHTML = numberingTabHtml(s);
    else if (currentTab === 'print') el.innerHTML = printTabHtml(s);
    else if (currentTab === 'control') el.innerHTML = controlTabHtml(s);
    Utils.applyInlineLabels(el);
  }

  async function getSettings() {
    const saved = await FarisDB.get(STORES.SALES_SETTINGS, SETTINGS_ID);
    return { ...DEFAULTS, ...(saved || {}) };
  }

  return { render, getSettings };
})();
