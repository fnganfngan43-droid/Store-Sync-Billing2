/* =========================================================
   شاشة المشتريات - الحاوية وشريط التنقل بين شاشاتها الفرعية
   ========================================================= */

const ScreenPurchases = (function () {
  const tabs = [
    { key: 'invoices', label: 'فاتورة مشتريات', icon: '🧾', render: (c) => PurchaseInvoices.render(c) },
    { key: 'returns', label: 'مرجوع مشتريات', icon: '↩️', render: (c) => PurchaseReturns.render(c) },
    { key: 'discount', label: 'خصم مكتسب', icon: '🏷️', render: (c) => PurchaseStub.render(c, 'earnedDiscount') },
    { key: 'config', label: 'تهيئة المشتريات', icon: '⚙️', render: (c) => PurchaseConfig.render(c) }
  ];

  let activeTab = null;

  function init() {
    App.register('purchases', { onShow });

    document.getElementById('purchases-back-home').addEventListener('click', () => App.show('home', { replace: true }));

    const nav = document.getElementById('purchases-nav');
    nav.innerHTML = tabs.map(t => `
      <button class="nav-icon-btn" data-key="${t.key}">
        <span class="nav-icon">${t.icon}</span>
        <span class="nav-label">${t.label}</span>
      </button>`).join('');

    nav.addEventListener('click', (e) => {
      const btn = e.target.closest('.nav-icon-btn');
      if (!btn) return;
      selectTab(btn.dataset.key);
    });
  }

  function onShow() {
    selectTab(activeTab || 'invoices');
  }

  function selectTab(key) {
    activeTab = key;
    document.querySelectorAll('#purchases-nav .nav-icon-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.key === key);
    });
    const tab = tabs.find(t => t.key === key);
    const content = document.getElementById('purchases-content');
    content.innerHTML = '';
    tab.render(content);
  }

  return { init };
})();
