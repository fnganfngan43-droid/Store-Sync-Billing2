/* =========================================================
   مرجوع المشتريات
   نفس بنية فاتورة المشتريات (مورد/صندوق)، وبنفس منطق ربط
   مرتجع المبيعات بفاتورته الأصلية (بحث عن فاتورة الشراء لكل
   صنف، قفل السعر، وسقف أقصى للكمية المرتجعة).
   قيد تلقائي واحد عكسي عند الحفظ: مدين المورد/الصندوق، دائن المخزون.
   ========================================================= */

const PurchaseReturns = (function () {
  let mode = 'add'; // add | search
  let draftLines = [];
  let lineCounter = 0;
  let editId = null;
  let currentJournalId = null;
  let selectedReturnId = null;
  let activeMenuLineId = null;

  let suppliersCache = [];
  let warehousesCache = [];
  let cashboxesCache = [];
  let currenciesCache = [];
  let itemsCache = [];
  let unitsFlat = [];
  let mainGroupsCache = [];
  let purchaseInvoicesCache = [];

  function currencyById(id) { return currenciesCache.find(c => c.id === id); }
  function unitById(id) { return unitsFlat.find(u => u.id === id); }
  function localCurrency() { return currenciesCache.find(c => c.type === 'محلي'); }
  function convertAmount(amount, fromCurrency, toCurrency) {
    if (!fromCurrency || !toCurrency || fromCurrency.id === toCurrency.id) return amount;
    const local = fromCurrency.type === 'محلي' ? amount : amount * fromCurrency.rate;
    return toCurrency.type === 'محلي' ? local : local / toCurrency.rate;
  }
  function round2(n) { return Math.round((n + Number.EPSILON) * 100) / 100; }
  function unitLinkFactor(item, unitId) {
    if (!item) return 1;
    const u = item.units.find(x => x.unitId === unitId);
    return u ? (u.linkFactor || 1) : 1;
  }

  async function render(container) {
    mode = 'add';
    draftLines = [];
    lineCounter = 0;
    editId = null;
    currentJournalId = null;
    selectedReturnId = null;

    suppliersCache = await FarisDB.getAll(STORES.SUPPLIERS);
    warehousesCache = await FarisDB.getAll(STORES.INV_WAREHOUSES);
    cashboxesCache = await FarisDB.getAll(STORES.CASHBOXES);
    currenciesCache = await FarisDB.getAll(STORES.CURRENCIES);
    itemsCache = await FarisDB.getAll(STORES.INV_ITEMS);
    unitsFlat = await FarisDB.getAll(STORES.INV_UNITS);
    mainGroupsCache = await FarisDB.getAll(STORES.INV_GROUPS_MAIN);
    purchaseInvoicesCache = await FarisDB.getAll(STORES.PURCHASE_INVOICES);

    container.innerHTML = `
      <div class="toolbar icon-only" id="pr-toolbar">
        <button class="btn btn-icon" id="pr-dup" title="نسخ من مرتجع محدد" disabled>🔁</button>
        <button class="btn btn-icon" id="pr-add" title="إضافة">➕</button>
        <button class="btn btn-icon" id="pr-save" title="حفظ">💾</button>
        <button class="btn btn-icon" id="pr-search" title="بحث">🔍</button>
        <button class="btn btn-icon" id="pr-edit" title="تعديل" disabled>✏️</button>
        <button class="btn btn-icon" id="pr-print" title="طباعة" disabled>🖨️</button>
        <button class="btn btn-icon" id="pr-journal" title="عرض القيود" disabled>📋</button>
        <button class="btn btn-icon" id="pr-del" title="حذف" disabled>🗑️</button>
        <button class="btn btn-icon" id="pr-undo" title="تراجع من الإضافة">↩️</button>
      </div>

      <div id="pr-add-view"></div>
      <div id="pr-search-view" class="hidden"></div>

      <div class="popup-sheet" id="pr-journal-popup">
        <div class="popup-header"><span>القيد المحاسبي التلقائي للمرتجع</span><button class="btn-close" id="pr-journal-close">✖️</button></div>
        <div id="pr-journal-content"></div>
      </div>

      <div class="popup-sheet" id="pr-line-menu-popup">
        <div class="popup-header"><span id="pr-line-menu-title">خيارات الصنف</span><button class="btn-close" id="pr-line-menu-close">✖️</button></div>
        <div class="sheet-actions" style="flex-direction:column; gap:8px;">
          <button type="button" class="btn btn-ghost full" id="pr-line-menu-movement">📋 بطاقة حركة الصنف</button>
          <button type="button" class="btn btn-ghost full" id="pr-line-menu-newitem">➕ إضافة صنف جديد</button>
          <button type="button" class="btn btn-danger full" id="pr-line-menu-delete">🗑️ حذف الصف</button>
        </div>
      </div>

      <div class="popup-sheet" id="pr-newitem-popup">
        <div class="popup-header"><span>إضافة صنف جديد</span><button class="btn-close" id="pr-newitem-close">✖️</button></div>
        <div class="form-grid">
          <label class="required"><input type="text" id="pr-ni-code" placeholder="رقم الصنف"></label>
          <label class="required"><input type="text" id="pr-ni-name" placeholder="اسم الصنف"></label>
          <label class="required"><select id="pr-ni-main-group"><option value="" disabled selected hidden>المجموعة الرئيسية</option></select></label>
          <label class="required"><select id="pr-ni-unit"><option value="" disabled selected hidden>الوحدة الأساسية</option></select></label>
        </div>
        <button type="button" class="btn btn-primary full" id="pr-ni-save">💾 حفظ وإضافة للمرتجع</button>
      </div>

      <div class="popup-sheet" id="pr-movement-popup">
        <div class="popup-header"><span>حركة الصنف</span><button class="btn-close" id="pr-movement-close">✖️</button></div>
        <div id="pr-movement-content"></div>
      </div>
    `;

    renderAddView();
    bindToolbar(container);
    setToolbarState('add-empty');
    document.getElementById('pr-no').value = await nextReturnNo();
  }

  /* -------------------- شريط الأدوات -------------------- */
  function bindToolbar(container) {
    container.querySelector('#pr-add').addEventListener('click', onAddNew);
    container.querySelector('#pr-save').addEventListener('click', onSaveReturn);
    container.querySelector('#pr-search').addEventListener('click', onToggleSearch);
    container.querySelector('#pr-edit').addEventListener('click', onEditSelected);
    container.querySelector('#pr-print').addEventListener('click', onPrintSelected);
    container.querySelector('#pr-journal').addEventListener('click', onViewJournal);
    container.querySelector('#pr-journal-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('pr-journal-popup')));
    container.querySelector('#pr-del').addEventListener('click', onDelete);
    container.querySelector('#pr-dup').addEventListener('click', onDuplicateFromSelected);
    container.querySelector('#pr-undo').addEventListener('click', onUndo);

    container.querySelector('#pr-line-menu-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('pr-line-menu-popup')));
    container.querySelector('#pr-line-menu-movement').addEventListener('click', onLineMenuMovement);
    container.querySelector('#pr-line-menu-newitem').addEventListener('click', onLineMenuNewItem);
    container.querySelector('#pr-line-menu-delete').addEventListener('click', onLineMenuDelete);
    container.querySelector('#pr-newitem-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('pr-newitem-popup')));
    container.querySelector('#pr-ni-save').addEventListener('click', onSaveNewItem);
    container.querySelector('#pr-movement-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('pr-movement-popup')));
  }

  function setToolbarState(state) {
    const dis = (id, v) => { const el = document.getElementById(id); if (el) el.disabled = v; };
    // Keep toolbar buttons visible in every state; do not hide them during new-entry mode.
    if (state === 'add-empty') { dis('pr-dup', true); dis('pr-edit', true); dis('pr-print', true); dis('pr-journal', true); dis('pr-del', true); }
    else if (state === 'add-saved') { dis('pr-dup', false); dis('pr-edit', false); dis('pr-print', false); dis('pr-journal', false); dis('pr-del', false); }
    else if (state === 'search-none') { dis('pr-dup', true); dis('pr-edit', true); dis('pr-print', true); dis('pr-journal', true); dis('pr-del', true); }
    else if (state === 'search-selected') { dis('pr-dup', false); dis('pr-edit', false); dis('pr-print', false); dis('pr-journal', false); dis('pr-del', false); }
  }

  /* -------------------- شاشة الإضافة -------------------- */
  function renderAddView() {
    const el = document.getElementById('pr-add-view');
    el.classList.remove('hidden');
    document.getElementById('pr-search-view').classList.add('hidden');

    el.innerHTML = `
      <div class="form-row cols-2">
        <label class="optional"><input type="text" id="pr-no" placeholder="رقم المرجوع" readonly></label>
        <label class="required"><input type="date" id="pr-date" aria-label="التاريخ" required></label>
      </div>

      <div class="form-row cols-2">
        <label class="required">
          <select id="pr-type"><option value="" disabled selected hidden>نوع الفاتورة</option><option value="نقدي">نقدي</option><option value="آجل">آجل</option></select>
        </label>
        <label class="optional"><select id="pr-party-currency"><option value="" disabled selected hidden>رمز العملة</option></select></label>
      </div>

      <div class="form-row cols-2" id="pr-row-party">
        <label class="required hidden" id="pr-cashbox-no-wrap"><input type="text" id="pr-cashbox-no" placeholder="رقم الصندوق" readonly></label>
        <label class="required hidden" id="pr-cashbox-wrap">
          <div class="combo-wrap">
            <input type="text" id="pr-cashbox-input" autocomplete="off" placeholder="اسم الصندوق">
            <div class="autocomplete-list" id="pr-cashbox-list"></div>
          </div>
          <input type="hidden" id="pr-cashbox-id">
        </label>

        <label class="required hidden" id="pr-supplier-no-wrap"><input type="text" id="pr-supplier-no" placeholder="رقم المورد" readonly></label>
        <label class="required hidden" id="pr-supplier-wrap">
          <div class="combo-wrap">
            <input type="text" id="pr-supplier-input" autocomplete="off" placeholder="اسم المورد">
            <div class="autocomplete-list" id="pr-supplier-list"></div>
          </div>
          <input type="hidden" id="pr-supplier-id">
        </label>
      </div>

      <div class="form-row cols-2">
        <label class="optional"><input type="text" id="pr-exchange-rate" placeholder="سعر الصرف" readonly></label>
        <label class="optional"><input type="text" id="pr-local-amount" placeholder="المبلغ محلي" readonly></label>
      </div>

      <div class="form-row cols-2">
        <label class="optional"><input type="text" id="pr-reference" placeholder="رقم المرجع"></label>
        <label class="required"><select id="pr-warehouse" required><option value="" disabled selected hidden>المخزن</option></select></label>
      </div>
      <input type="hidden" id="pr-warehouse-currency">
      <input type="hidden" id="pr-currency">

      <div class="table-scroll" id="pr-items-scroll">
        <table class="data-table" id="pr-items-table">
          <thead><tr>
            <th></th><th>رقم الصنف</th><th>اسم الصنف</th><th>الوحدة</th><th>رقم فاتورة الشراء</th><th>رمز المخزن</th><th>الكمية</th><th>السعر الوحدة</th><th>الخصم</th><th>الإجمالي</th>
          </tr></thead>
          <tbody id="pr-lines-rows"></tbody>
        </table>
      </div>
      <p class="hint">الحقول ذات الخلفية الصفراء إجبارية، والخلفية الرمادية اختيارية.</p>

      <div class="form-grid" style="margin-top:10px;">
        <label class="optional">خصم المرتجع (مبلغ محلي)<input type="number" step="0.01" id="pr-discount" value="0"></label>
      </div>

      <table class="data-table" style="margin-top:8px;">
        <tbody>
          <tr><td><b>إجمالي الكمية</b></td><td id="pr-total-qty">0</td>
              <td><b>إجمالي قبل الخصم</b></td><td id="pr-total-before">0.00</td></tr>
          <tr><td colspan="3"><b>الصافي النهائي</b></td><td id="pr-total-net"><b>0.00</b></td></tr>
        </tbody>
      </table>
    `;

    document.getElementById('pr-warehouse').innerHTML = '<option value="" disabled selected hidden>المخزن</option>' + warehousesCache.map(w => `<option value="${w.id}">${Utils.escapeHtml(w.name)}</option>`).join('');
    document.getElementById('pr-party-currency').innerHTML = '<option value="" disabled selected hidden>رمز العملة</option>' + currenciesCache.map(c => `<option value="${c.id}">(${Utils.escapeHtml(c.symbol)}) ${Utils.escapeHtml(c.name)}</option>`).join('');
    document.getElementById('pr-date').value = new Date().toISOString().slice(0, 10);

    bindAddViewEvents();
    for (let i = 0; i < 10; i++) addReturnRow();
    setHeaderEditable(false);
  }

  function setHeaderEditable(enabled) {
    ['pr-date', 'pr-type', 'pr-party-currency', 'pr-cashbox-input', 'pr-supplier-input', 'pr-reference', 'pr-warehouse'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.disabled = !enabled;
    });
  }

  function bindAddViewEvents() {
    document.getElementById('pr-type').addEventListener('change', onTypeChange);
    document.getElementById('pr-party-currency').addEventListener('change', () => {
      document.getElementById('pr-currency').value = document.getElementById('pr-party-currency').value;
      updateExchangeAndLocalAmount();
    });
    document.getElementById('pr-warehouse').addEventListener('change', () => {
      updateWarehouseCurrencyDisplay();
      updateWarehousePreview();
    });

    const supplierInput = document.getElementById('pr-supplier-input');
    const supplierList = document.getElementById('pr-supplier-list');
    Utils.attachAutocomplete(supplierInput, supplierList, (query) => {
      const list = suppliersCache.map(s => ({ value: s.id, label: `${s.partyNumber} - ${s.name}`, displayValue: s.name }));
      return query ? list.filter(it => it.label.includes(query)) : list;
    }, (item) => {
      supplierInput.value = item.displayValue;
      document.getElementById('pr-supplier-id').value = item.value;
      const supplier = suppliersCache.find(s => s.id === item.value);
      document.getElementById('pr-supplier-no').value = supplier ? supplier.partyNumber : '';
      applyPartyCurrency(supplier);
    });

    const cashboxInput = document.getElementById('pr-cashbox-input');
    const cashboxList = document.getElementById('pr-cashbox-list');
    Utils.attachAutocomplete(cashboxInput, cashboxList, (query) => {
      const list = cashboxesCache.map(c => ({ value: c.id, label: `${c.partyNumber} - ${c.name}`, displayValue: c.name }));
      return query ? list.filter(it => it.label.includes(query)) : list;
    }, (item) => {
      cashboxInput.value = item.displayValue;
      document.getElementById('pr-cashbox-id').value = item.value;
      const cashbox = cashboxesCache.find(c => c.id === item.value);
      document.getElementById('pr-cashbox-no').value = cashbox ? cashbox.partyNumber : '';
      applyPartyCurrency(cashbox);
    });

    document.getElementById('pr-discount').addEventListener('input', recomputeTotals);

    onTypeChange();
    updateExchangeAndLocalAmount();
    updateWarehouseCurrencyDisplay();
  }

  function applyPartyCurrency(party) {
    const currencyId = party && party.defaultCurrency ? party.defaultCurrency : null;
    document.getElementById('pr-currency').value = currencyId || '';
    document.getElementById('pr-party-currency').value = currencyId || '';
    updateExchangeAndLocalAmount();
  }

  function onTypeChange() {
    const type = document.getElementById('pr-type').value;
    const isCash = type === 'نقدي';
    const isCredit = type === 'آجل';
    document.getElementById('pr-cashbox-wrap').classList.toggle('hidden', !isCash);
    document.getElementById('pr-cashbox-no-wrap').classList.toggle('hidden', !isCash);
    document.getElementById('pr-supplier-wrap').classList.toggle('hidden', !isCredit);
    document.getElementById('pr-supplier-no-wrap').classList.toggle('hidden', !isCredit);
    // إعادة تحديد الفواتير المؤهلة لكل صف عند تغيير النوع (لأنها تعتمد على النوع/المورد)
    draftLines.forEach(l => resetRowInvoiceLink(l._id));
  }

  function updateWarehouseCurrencyDisplay() {
    const warehouse = warehousesCache.find(w => w.id === Number(document.getElementById('pr-warehouse').value));
    const currency = warehouse ? currencyById(warehouse.currencyId) : null;
    document.getElementById('pr-warehouse-currency').value = currency ? currency.id : '';
  }

  function updateWarehousePreview() {
    const warehouse = warehousesCache.find(w => w.id === Number(document.getElementById('pr-warehouse').value));
    document.querySelectorAll('#pr-lines-rows .pr-wh-cell').forEach(td => { td.textContent = warehouse ? (warehouse.code || warehouse.name) : ''; });
  }

  function updateExchangeAndLocalAmount() {
    const returnCurrency = currencyById(Number(document.getElementById('pr-currency').value));
    const local = localCurrency();
    const rateField = document.getElementById('pr-exchange-rate');
    const amountField = document.getElementById('pr-local-amount');
    if (!returnCurrency || !local) { rateField.value = ''; amountField.value = ''; return; }
    rateField.value = returnCurrency.type === 'محلي' ? '1' : returnCurrency.rate;
    const net = Number((document.getElementById('pr-total-net').textContent || '0').replace(/[^\d.-]/g, '')) || 0;
    amountField.value = net.toFixed(2);
  }

  function warehouseCode() {
    const wh = warehousesCache.find(w => w.id === Number(document.getElementById('pr-warehouse').value));
    return wh ? (wh.code || wh.name) : '';
  }

  /* -------------------- جدول الأصناف (صفوف جاهزة تفاعلية) -------------------- */
  function addReturnRow(prefill) {
    const row = {
      _id: ++lineCounter, itemCode: '', itemName: '', unitId: null, unitName: '',
      invoiceId: null, invoiceNo: '', warehouseCode: '', unitCostLocal: 0,
      qty: '', price: '', lineDiscount: 0, total: 0, maxQty: null
    };
    if (prefill) Object.assign(row, prefill);
    draftLines.push(row);
    const tbody = document.getElementById('pr-lines-rows');
    if (tbody) tbody.appendChild(buildRowEl(row));
    return row;
  }

  function ensureTrailingRows() {
    const emptyTrailing = [];
    for (let i = draftLines.length - 1; i >= 0 && !draftLines[i].itemCode; i--) emptyTrailing.unshift(draftLines[i]);
    if (emptyTrailing.length < 1) {
      for (let i = 0; i < 5; i++) addReturnRow();
    }
  }

  function focusNextRowFirstField(afterRid) {
    const idx = draftLines.findIndex(l => l._id === afterRid);
    if (idx === draftLines.length - 1) {
      for (let i = 0; i < 5; i++) addReturnRow();
    }
    const nextRow = draftLines[idx + 1];
    if (!nextRow) return;
    const tr = document.querySelector(`#pr-lines-rows tr[data-rid="${nextRow._id}"]`);
    if (tr) tr.querySelector('.pr-item-input').focus();
  }

  function buildRowEl(row) {
    const item = row.itemCode ? itemsCache.find(i => i.code === row.itemCode) : null;
    const unitOptions = (item ? item.units : []).map(u => {
      const unit = unitById(u.unitId);
      return `<option value="${u.unitId}">${unit ? Utils.escapeHtml(unit.name) : ''}</option>`;
    }).join('');

    const tr = Utils.el(`
      <tr data-rid="${row._id}">
        <td><button type="button" class="btn-close" data-menu="${row._id}">⋮</button></td>
        <td class="cell-required">
          <div class="combo-wrap combo-compact">
            <input type="text" class="table-input pr-item-input" autocomplete="off" value="${row.itemCode ? Utils.escapeHtml(row.itemCode + ' - ' + row.itemName) : ''}">
            <div class="autocomplete-list pr-item-list"></div>
          </div>
        </td>
        <td class="pr-name-preview">${Utils.escapeHtml(row.itemName || '')}</td>
        <td class="cell-required"><select class="table-input pr-item-unit">${unitOptions}</select></td>
        <td class="cell-required">
          <div class="combo-wrap combo-compact">
            <input type="text" class="table-input pr-item-invoiceno-input" autocomplete="off" placeholder="رقم فاتورة الشراء" value="${Utils.escapeHtml(row.invoiceNo || '')}">
            <div class="autocomplete-list pr-item-invoiceno-list"></div>
          </div>
        </td>
        <td class="cell-optional pr-wh-cell">${Utils.escapeHtml(row.warehouseCode || warehouseCode())}</td>
        <td class="cell-required"><input type="number" step="0.01" class="table-input pr-item-qty" value="${row.qty}"></td>
        <td class="cell-required"><input type="number" step="0.01" class="table-input pr-item-price" value="${row.price}" ${row.maxQty ? 'readonly' : ''}></td>
        <td class="cell-optional"><input type="number" step="0.01" class="table-input pr-item-discount" value="${row.lineDiscount || 0}"></td>
        <td class="pr-total-preview">${(row.total || 0).toFixed(2)}</td>
      </tr>
    `);

    if (row.unitId) tr.querySelector('.pr-item-unit').value = row.unitId;
    if (row.maxQty) tr.querySelector('.pr-item-qty').dataset.maxQty = row.maxQty;

    const itemInput = tr.querySelector('.pr-item-input');
    const itemList = tr.querySelector('.pr-item-list');
    Utils.attachAutocomplete(itemInput, itemList, (query) => {
      const list = itemsCache.map(it => ({ value: it.code, label: `${it.code} - ${it.name}`, displayValue: `${it.code} - ${it.name}` }));
      return query ? list.filter(it => it.label.includes(query)) : list;
    }, (picked) => {
      itemInput.value = picked.displayValue;
      onRowItemChosen(row._id, picked.value);
    });

    const invNoInput = tr.querySelector('.pr-item-invoiceno-input');
    const invNoList = tr.querySelector('.pr-item-invoiceno-list');
    Utils.attachAutocomplete(invNoInput, invNoList, (query) => {
      const list = eligibleInvoicesForItem(row.itemCode).map(m => ({ value: m.invoiceId, label: `${m.invoiceNo} (متاح: ${m.qty})`, displayValue: m.invoiceNo, meta: m }));
      return query ? list.filter(it => it.label.includes(query)) : list;
    }, (picked) => {
      invNoInput.value = picked.displayValue;
      onRowInvoiceMatched(row._id, picked.meta);
    });
    invNoInput.addEventListener('input', () => { if (!invNoInput.value) resetRowInvoiceLink(row._id); });

    tr.querySelector('.pr-item-unit').addEventListener('change', () => onRowUnitChange(row._id));
    tr.querySelector('.pr-item-qty').addEventListener('input', () => onRowQtyInput(row._id));
    tr.querySelector('.pr-item-price').addEventListener('input', () => onRowFieldInput(row._id));
    tr.querySelector('.pr-item-discount').addEventListener('input', () => onRowFieldInput(row._id));
    tr.querySelector('[data-menu]').addEventListener('click', () => openLineMenu(row._id));

    const order = ['.pr-item-input', '.pr-item-unit', '.pr-item-invoiceno-input', '.pr-item-qty', '.pr-item-price', '.pr-item-discount'];
    order.forEach((sel, idx) => {
      tr.querySelector(sel).addEventListener('keydown', (e) => {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        if (idx === 0) {
          const currentRow = draftLines.find(l => l._id === row._id);
          const entered = tr.querySelector('pr-item-input').value.trim();
          const validItem = currentRow && currentRow.itemCode && itemsCache.some(it => it.code === currentRow.itemCode) && (entered === currentRow.itemCode || entered === `${currentRow.itemCode} - ${currentRow.itemName}`);
          if (!entered || !validItem) {
            Utils.toast(!entered ? 'يرجى إدخال رقم الصنف واختياره من القائمة' : 'رقم الصنف غير صحيح، اختر صنفًا من القائمة', 'error');
            tr.querySelector('pr-item-input').focus();
            return;
          }
        }
        if (idx < order.length - 1) tr.querySelector(order[idx + 1]).focus();
        else focusNextRowFirstField(row._id);
      });
    });

    return tr;
  }

  function onRowItemChosen(rid, code) {
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const item = itemsCache.find(i => i.code === code);
    row.itemCode = code;
    row.itemName = item ? item.name : '';
    row.unitId = item && item.units.length ? (item.units.find(u => u.isBase) || item.units[0]).unitId : null;
    row.warehouseCode = warehouseCode();

    const tr = document.querySelector(`#pr-lines-rows tr[data-rid="${rid}"]`);
    tr.querySelector('.pr-name-preview').textContent = row.itemName;
    tr.querySelector('.pr-wh-cell').textContent = row.warehouseCode;
    const unitSelect = tr.querySelector('.pr-item-unit');
    unitSelect.innerHTML = (item ? item.units : []).map(u => {
      const unit = unitById(u.unitId);
      return `<option value="${u.unitId}">${unit ? Utils.escapeHtml(unit.name) : ''}</option>`;
    }).join('');
    if (row.unitId) unitSelect.value = row.unitId;

    resetRowInvoiceLink(rid);
    ensureTrailingRows();
  }

  // فواتير الشراء المؤهلة للمرتجع: من نفس نوع الفاتورة (وإن كانت آجلة فمن نفس المورد)، وتحتوي على الصنف المختار
  function eligibleInvoicesForItem(code) {
    if (!code) return [];
    const type = document.getElementById('pr-type').value;
    const supplierId = Number(document.getElementById('pr-supplier-id').value) || null;

    const results = [];
    purchaseInvoicesCache.forEach(inv => {
      if (!type || inv.type !== type) return;
      if (type === 'آجل' && supplierId && inv.supplierId !== supplierId) return;
      (inv.lines || []).forEach(l => {
        if (l.itemCode === code) {
          const unitCostLocal = l.qty ? (l.totalCostLocal || 0) / l.qty : 0;
          results.push({ invoiceId: inv.id, invoiceNo: inv.invoiceNo, qty: l.qty, price: l.price, unitId: l.unitId, unitName: l.unitName, unitCostLocal });
        }
      });
    });
    return results;
  }

  function onRowInvoiceMatched(rid, meta) {
    if (!meta) return;
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const tr = document.querySelector(`#pr-lines-rows tr[data-rid="${rid}"]`);
    const qtyField = tr.querySelector('.pr-item-qty');
    const priceField = tr.querySelector('.pr-item-price');

    row.invoiceId = meta.invoiceId;
    row.invoiceNo = meta.invoiceNo;
    row.maxQty = meta.qty;
    row.qty = meta.qty;
    row.price = meta.price;
    row.unitCostLocal = meta.unitCostLocal || 0;
    row.originalUnitId = meta.unitId;
    if (meta.unitId) { row.unitId = meta.unitId; tr.querySelector('.pr-item-unit').value = meta.unitId; }

    qtyField.value = meta.qty;
    qtyField.dataset.maxQty = meta.qty;
    priceField.value = meta.price;
    priceField.readOnly = true;

    updateRowTotal(rid);
  }

  function resetRowInvoiceLink(rid) {
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const tr = document.querySelector(`#pr-lines-rows tr[data-rid="${rid}"]`);
    if (!tr) return;
    row.invoiceId = null;
    row.invoiceNo = '';
    row.maxQty = null;
    const qtyField = tr.querySelector('.pr-item-qty');
    const priceField = tr.querySelector('.pr-item-price');
    qtyField.dataset.maxQty = '';
    priceField.readOnly = false;
    tr.querySelector('.pr-item-invoiceno-input').value = '';
  }

  function onRowUnitChange(rid) {
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const tr = document.querySelector(`#pr-lines-rows tr[data-rid="${rid}"]`);
    const newUnitId = Number(tr.querySelector('.pr-item-unit').value) || null;
    if (row.originalUnitId && newUnitId && row.originalUnitId !== newUnitId) {
      const item = itemsCache.find(i => i.code === row.itemCode);
      const originalFactor = unitLinkFactor(item, row.originalUnitId);
      const newFactor = unitLinkFactor(item, newUnitId);
      row.unitCostLocal = originalFactor ? row.unitCostLocal * (newFactor / originalFactor) : row.unitCostLocal;
      row.originalUnitId = newUnitId;
    }
    row.unitId = newUnitId;
    updateRowTotal(rid);
  }

  function onRowQtyInput(rid) {
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const tr = document.querySelector(`#pr-lines-rows tr[data-rid="${rid}"]`);
    const qtyField = tr.querySelector('.pr-item-qty');
    const max = Number(qtyField.dataset.maxQty);
    if (max && Number(qtyField.value) > max) {
      Utils.toast(`لا يمكن أن تزيد كمية المرتجع عن كمية فاتورة الشراء الأصلية (${max})`, 'error');
      qtyField.value = max;
    }
    onRowFieldInput(rid);
  }

  function onRowFieldInput(rid) {
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const tr = document.querySelector(`#pr-lines-rows tr[data-rid="${rid}"]`);
    row.qty = tr.querySelector('.pr-item-qty').value;
    row.price = tr.querySelector('.pr-item-price').value;
    row.lineDiscount = Number(tr.querySelector('.pr-item-discount').value) || 0;
    updateRowTotal(rid);
  }

  function updateRowTotal(rid) {
    const row = draftLines.find(l => l._id === rid);
    if (!row) return;
    const tr = document.querySelector(`#pr-lines-rows tr[data-rid="${rid}"]`);
    const qty = Number(row.qty) || 0;
    const price = Number(row.price) || 0;
    const discount = Number(row.lineDiscount) || 0;
    row.total = Math.max(0, qty * price - discount);
    tr.querySelector('.pr-total-preview').textContent = row.total.toFixed(2);
    recomputeTotals();
  }

  /* -------------------- قائمة الخيارات السريعة (⋮) -------------------- */
  function openLineMenu(lineId) {
    activeMenuLineId = lineId;
    const line = draftLines.find(l => l._id === lineId);
    document.getElementById('pr-line-menu-title').textContent = line && line.itemName ? `صنف: ${line.itemName}` : 'خيارات الصنف';
    Utils.openSheet(document.getElementById('pr-line-menu-popup'));
  }

  async function onLineMenuMovement() {
    const line = draftLines.find(l => l._id === activeMenuLineId);
    Utils.closeSheet(document.getElementById('pr-line-menu-popup'));
    if (!line || !line.itemCode) { Utils.toast('اختر صنفًا في هذا الصف أولًا', 'error'); return; }
    await openItemMovement(line.itemCode, line.itemName);
  }

  function onLineMenuNewItem() {
    Utils.closeSheet(document.getElementById('pr-line-menu-popup'));
    openNewItemPopup();
  }

  function onLineMenuDelete() {
    const tr = document.querySelector(`#pr-lines-rows tr[data-rid="${activeMenuLineId}"]`);
    if (tr) tr.remove();
    draftLines = draftLines.filter(l => l._id !== activeMenuLineId);
    Utils.closeSheet(document.getElementById('pr-line-menu-popup'));
    if (!draftLines.length) addReturnRow();
    recomputeTotals();
  }

  async function openItemMovement(itemCode, itemName) {
    const warehouseId = Number(document.getElementById('pr-warehouse').value);
    const opening = (await FarisDB.getAllByIndex(STORES.INV_OPENING_STOCK, 'itemCode', itemCode)).filter(s => s.warehouseId === warehouseId);
    const entries = [];
    opening.forEach(s => entries.push({ date: '', type: 'رصيد افتتاحي', incoming: s.quantity, outgoing: 0 }));

    const salesInvoices = await FarisDB.getAll(STORES.SALES_INVOICES);
    salesInvoices.forEach(inv => {
            (inv.lines || []).forEach(l => { if ((l.warehouseId || inv.warehouseId) !== warehouseId) return; if (l.itemCode === itemCode) entries.push({ date: inv.date, type: 'فاتورة مبيعات', incoming: 0, outgoing: l.qty }); });
    });
    const salesReturns = await FarisDB.getAll(STORES.SALES_RETURNS);
    salesReturns.forEach(ret => {
      (ret.lines || []).forEach(l => { if ((l.warehouseId || ret.warehouseId) !== warehouseId) return; if (l.itemCode === itemCode) entries.push({ date: ret.date, type: 'مرتجع مبيعات', incoming: l.qty, outgoing: 0 }); });
    });
    purchaseInvoicesCache.forEach(pinv => {
      if (pinv.warehouseId !== warehouseId) return;
      (pinv.lines || []).forEach(l => { if (l.itemCode === itemCode) entries.push({ date: pinv.date, type: 'فاتورة مشتريات', incoming: l.qty, outgoing: 0 }); });
    });
    const purchaseReturns = await FarisDB.getAll(STORES.PURCHASE_RETURNS);
    purchaseReturns.forEach(ret => {
      if (ret.warehouseId !== warehouseId) return;
      if (ret.id === editId) return;
      (ret.lines || []).forEach(l => { if (l.itemCode === itemCode) entries.push({ date: ret.date, type: 'مرجوع مشتريات', incoming: 0, outgoing: l.qty }); });
    });

    entries.sort((a, b) => String(a.date).localeCompare(String(b.date)));
    let balance = 0;
    const rows = entries.map(e => {
      balance += e.incoming - e.outgoing;
      return `<tr><td>${Utils.escapeHtml(e.date)}</td><td>${Utils.escapeHtml(e.type)}</td><td>${e.incoming || ''}</td><td>${e.outgoing || ''}</td><td>${balance}</td></tr>`;
    }).join('') || '<tr><td colspan="5" class="empty-row">لا توجد حركة مسجَّلة لهذا الصنف في هذا المخزن</td></tr>';

    document.getElementById('pr-movement-content').innerHTML = `
      <p><b>الصنف:</b> ${Utils.escapeHtml(itemName)}</p>
      <table class="data-table"><thead><tr><th>تاريخ</th><th>نوع الحركة</th><th>وارد</th><th>صادر</th><th>الرصيد</th></tr></thead>
      <tbody>${rows}</tbody></table>
    `;
    Utils.openSheet(document.getElementById('pr-movement-popup'));
  }

  /* -------------------- إضافة صنف جديد سريعًا -------------------- */
  function openNewItemPopup() {
    document.getElementById('pr-ni-code').value = '';
    document.getElementById('pr-ni-name').value = '';
    document.getElementById('pr-ni-main-group').innerHTML = '<option value="" disabled selected hidden>المجموعة الرئيسية</option>' +
      mainGroupsCache.map(m => `<option value="${m.id}">${Utils.escapeHtml(m.name)}</option>`).join('');
    document.getElementById('pr-ni-unit').innerHTML = '<option value="" disabled selected hidden>الوحدة الأساسية</option>' +
      unitsFlat.map(u => `<option value="${u.id}">${Utils.escapeHtml(u.name)}</option>`).join('');
    Utils.openSheet(document.getElementById('pr-newitem-popup'));
  }

  async function onSaveNewItem() {
    const code = document.getElementById('pr-ni-code').value.trim();
    const name = document.getElementById('pr-ni-name').value.trim();
    const mainGroupId = Number(document.getElementById('pr-ni-main-group').value) || null;
    const unitId = Number(document.getElementById('pr-ni-unit').value) || null;
    if (!code || !name || !mainGroupId || !unitId) { Utils.toast('أكمل كل الحقول', 'error'); return; }
    if (itemsCache.some(i => i.code === code)) { Utils.toast('رقم الصنف مستخدم مسبقًا', 'error'); return; }

    const value = { code, name, mainGroupId, subGroupId: null, detailGroupId: null, units: [{ unitId, package: 1, level: 'أصغر وحدة', linkFactor: 1, isBase: true, isSellUnit: true, isPurchaseUnit: true }] };
    await FarisDB.put(STORES.INV_ITEMS, value);
    itemsCache.push(value);
    Utils.toast('تمت إضافة الصنف، وأُدرج في المرتجع', 'success');
    Utils.closeSheet(document.getElementById('pr-newitem-popup'));

    const tr = document.querySelector(`#pr-lines-rows tr[data-rid="${activeMenuLineId}"]`);
    if (tr) {
      tr.querySelector('.pr-item-input').value = `${code} - ${name}`;
      onRowItemChosen(activeMenuLineId, code);
    }
  }

  /* -------------------- الإجماليات -------------------- */
  function recomputeTotals() {
    const filled = draftLines.filter(l => l.itemCode);
    const totalQty = filled.reduce((s, l) => s + (Number(l.qty) || 0), 0);
    const totalBefore = filled.reduce((s, l) => s + (Number(l.total) || 0), 0);
    const discount = Number(document.getElementById('pr-discount').value) || 0;
    const net = Math.max(0, totalBefore - discount);

    document.getElementById('pr-total-qty').textContent = totalQty;
    document.getElementById('pr-total-before').textContent = totalBefore.toFixed(2);
    document.getElementById('pr-total-net').innerHTML = `<b>${net.toFixed(2)}</b>`;
    updateExchangeAndLocalAmount();
  }

  async function nextReturnNo() {
    const returns = await FarisDB.getAll(STORES.PURCHASE_RETURNS);
    return `PR-${returns.length + 1}`;
  }

  async function onAddNew() {
    mode = 'add';
    editId = null;
    currentJournalId = null;
    draftLines = [];
    renderAddView();
    setHeaderEditable(true);
    document.getElementById('pr-no').value = await nextReturnNo();
    setToolbarState('add-empty');
  }

  function onUndo() {
    draftLines = [];
    editId = null;
    currentJournalId = null;
    renderAddView();
    setToolbarState('add-empty');
  }

  /* -------------------- توليد القيد المحاسبي التلقائي -------------------- */
  async function buildJournalLines(ret) {
    const warehouse = warehousesCache.find(w => w.id === ret.warehouseId);
    if (!warehouse) return { error: 'تعذر تحديد المخزن' };
    const mapping = await FarisDB.get(STORES.INV_GL_MAPPING, warehouse.groupId);
    const allAccounts = await FarisDB.getAll(STORES.ACCOUNTS);
    const resolveAccount = (acc) => {
      if (!acc) return acc;
      const found = allAccounts.find(a => a.code === acc.code);
      return found ? { code: acc.code, name: found.name } : acc;
    };
    if (!mapping || !mapping.inventoryAccount) {
      return { error: `تعذر إنشاء القيد، حساب المخزون غير مربوط في "ربط المخزون بالأستاذ العام" لمجموعة مخازن (${warehouse.name})` };
    }

    const returnCurrency = currencyById(ret.currencyId);
    const warehouseCurrency = currencyById(warehouse.currencyId);
    const local = localCurrency();
    const retRate = returnCurrency.type === 'محلي' ? 1 : returnCurrency.rate;
    const whRate = warehouseCurrency.type === 'محلي' ? 1 : warehouseCurrency.rate;

    let debitAccount, debitAnalyticCode = '', debitAnalyticName = '';
    if (ret.type === 'نقدي') {
      const cashbox = cashboxesCache.find(c => c.id === ret.cashboxId);
      if (!cashbox) return { error: 'اختر صندوق المرتجع لإنشاء القيد' };
      debitAccount = { code: cashbox.parentAccountCode, name: cashbox.name };
      debitAnalyticCode = `${cashbox.parentAccountCode}-${cashbox.partyNumber}`;
      debitAnalyticName = cashbox.name;
    } else {
      const supplier = suppliersCache.find(s => s.id === ret.supplierId);
      if (!supplier) return { error: 'اختر مورد المرتجع لإنشاء القيد' };
      debitAccount = { code: supplier.parentAccountCode, name: supplier.name };
      debitAnalyticCode = `${supplier.parentAccountCode}-${supplier.partyNumber}`;
      debitAnalyticName = supplier.name;
    }

    const mk = (account, analyticCode, analyticName, currency, rate, statement, debit, credit) => ({
      accountCode: account.code, accountName: account.name,
      analyticCode: analyticCode || account.code, analyticName: analyticName || account.name,
      currencyId: currency.id, currencySymbol: currency.symbol, exchangeRate: rate,
      statement,
      debit: round2(debit), credit: round2(credit),
      debitLocal: round2(convertAmount(debit, currency, local)),
      creditLocal: round2(convertAmount(credit, currency, local))
    });

    // مدين المورد/الصندوق (بعملة المرتجع) بصافي المرتجع؛ دائن المخزون (بعملة المخزون) بالتكلفة الفعلية المرتجعة
    const statement = ret.type === 'نقدي'
      ? `مرجوع مشتريات نقدي رقم ${ret.returnNo}`
      : `مرجوع مشتريات آجل رقم ${ret.returnNo} إلى المورد ${debitAnalyticName}`;

    // ملاحظة: unitCostLocal مأخوذة من تكلفة سطر فاتورة الشراء الأصلية، وهي مخزَّنة بعملة المخزون (وليس بالعملة المحلية)
    const inventoryValueWarehouseCurrency = ret.lines.reduce((s, l) => s + (l.qty * (l.unitCostLocal || 0)), 0);

    const lines = [
      mk(debitAccount, debitAnalyticCode, debitAnalyticName, returnCurrency, retRate, statement, ret.net, 0),
      mk(resolveAccount(mapping.inventoryAccount), '', '', warehouseCurrency, whRate, statement, 0, inventoryValueWarehouseCurrency)
    ];
    return { lines };
  }

  async function onSaveReturn() {
    const filledLines = draftLines.filter(l => l.itemCode);
    if (!filledLines.length) { Utils.toast('أضف صنفًا واحدًا على الأقل', 'error'); return; }
    const missingInvoice = filledLines.find(l => !l.invoiceId);
    if (missingInvoice) { Utils.toast(`اختر رقم فاتورة الشراء الأصلية لصنف "${missingInvoice.itemName}"`, 'error'); return; }

    const type = document.getElementById('pr-type').value;
    if (!type) { Utils.toast('اختر نوع الفاتورة', 'error'); return; }
    const warehouseId = Number(document.getElementById('pr-warehouse').value);
    if (!warehouseId) { Utils.toast('اختر المخزن', 'error'); return; }
    if (type === 'نقدي' && !document.getElementById('pr-cashbox-id').value) { Utils.toast('اختر الصندوق', 'error'); return; }
    if (type === 'آجل' && !document.getElementById('pr-supplier-id').value) { Utils.toast('اختر المورد', 'error'); return; }
    if (!document.getElementById('pr-currency').value) {
      Utils.toast('تعذّر تحديد عملة المرتجع، تأكد أن للجهة المختارة عملة افتراضية في بياناتها', 'error');
      return;
    }

    const supplier = suppliersCache.find(s => s.id === Number(document.getElementById('pr-supplier-id').value));
    const cashbox = cashboxesCache.find(c => c.id === Number(document.getElementById('pr-cashbox-id').value));
    const beforeDiscount = filledLines.reduce((s, l) => s + (Number(l.total) || 0), 0);
    const discount = Number(document.getElementById('pr-discount').value) || 0;
    const net = Math.max(0, beforeDiscount - discount);

    const ret = {
      returnNo: document.getElementById('pr-no').value || await nextReturnNo(),
      date: document.getElementById('pr-date').value,
      type,
      supplierId: type === 'آجل' ? Number(document.getElementById('pr-supplier-id').value) : null,
      supplierName: supplier ? supplier.name : '',
      cashboxId: type === 'نقدي' ? Number(document.getElementById('pr-cashbox-id').value) : null,
      cashboxName: cashbox ? cashbox.name : '',
      reference: document.getElementById('pr-reference').value.trim(),
      warehouseId,
      currencyId: Number(document.getElementById('pr-currency').value),
      lines: filledLines.map(({ _id, maxQty, originalUnitId, ...rest }) => ({ ...rest, qty: Number(rest.qty), price: Number(rest.price) })),
      discount, beforeDiscount, net
    };
    if (editId) ret.id = editId;
    if (currentJournalId) ret.journalId = currentJournalId;

    const journalResult = await buildJournalLines(ret);
    if (journalResult.error) { Utils.toast(journalResult.error, 'error'); return; }
    ret.journalLines = journalResult.lines;

    const savedId = await FarisDB.put(STORES.PURCHASE_RETURNS, ret);

    const journalPayload = { date: ret.date, lines: journalResult.lines.map(l => ({ ...l, refNo: ret.returnNo })) };
    if (currentJournalId) {
      const existingEntry = await FarisDB.get(STORES.JOURNAL, currentJournalId);
      journalPayload.id = currentJournalId;
      journalPayload.entryNo = existingEntry ? existingEntry.entryNo : String(currentJournalId);
      await FarisDB.put(STORES.JOURNAL, journalPayload);
    } else {
      const journalEntries = await FarisDB.getAll(STORES.JOURNAL);
      const entryNo = journalEntries.length ? Math.max(...journalEntries.map(j => Number(j.entryNo) || 0)) + 1 : 1;
      journalPayload.entryNo = String(entryNo);
      currentJournalId = await FarisDB.put(STORES.JOURNAL, journalPayload);
      ret.id = savedId;
      ret.journalId = currentJournalId;
      await FarisDB.put(STORES.PURCHASE_RETURNS, ret);
    }

    Utils.toast('تم حفظ مرجوع المشتريات وترحيل قيده المحاسبي بنجاح', 'success');
    editId = savedId;
    setToolbarState('add-saved');
    setHeaderEditable(false);
  }

  /* -------------------- البحث / القائمة -------------------- */
  async function onToggleSearch() {
    mode = mode === 'search' ? 'add' : 'search';
    if (mode === 'search') {
      document.getElementById('pr-add-view').classList.add('hidden');
      const el = document.getElementById('pr-search-view');
      el.classList.remove('hidden');
      await renderSearchView(el);
    } else {
      document.getElementById('pr-search-view').classList.add('hidden');
      document.getElementById('pr-add-view').classList.remove('hidden');
      setToolbarState('add-empty');
    }
  }

  async function renderSearchView(el) {
    el.innerHTML = `
      <div class="toolbar search-row">
        <input type="text" id="pr-list-search" placeholder="🔍 بحث...">
        <select id="pr-list-col"><option value="">الكل</option>${['رقم المرجوع', 'التاريخ', 'المورد/الصندوق', 'المخزن', 'النوع'].map(c => `<option value="${c}">${c}</option>`).join('')}</select>
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>رقم المرجوع</th><th>التاريخ</th><th>المورد/الصندوق</th><th>المخزن</th><th>النوع</th><th>الصافي</th></tr></thead>
          <tbody id="pr-list-rows"></tbody>
        </table>
      </div>
    `;
    el.querySelector('#pr-list-search').addEventListener('input', loadListRows);
    el.querySelector('#pr-list-col').addEventListener('change', loadListRows);
    await loadListRows();
    setToolbarState('search-none');
  }

  async function loadListRows() {
    let returns = await FarisDB.getAll(STORES.PURCHASE_RETURNS);
    const search = document.getElementById('pr-list-search').value.trim();
    const col = document.getElementById('pr-list-col').value;
    const whMap = Object.fromEntries(warehousesCache.map(w => [w.id, w.name]));

    if (search) {
      returns = returns.filter(r => {
        const partyName = r.type === 'نقدي' ? r.cashboxName : r.supplierName;
        const map = { 'رقم المرجوع': r.returnNo, 'التاريخ': r.date, 'المورد/الصندوق': partyName, 'المخزن': whMap[r.warehouseId], 'النوع': r.type };
        const haystack = col ? map[col] : Object.values(map).join(' ');
        return String(haystack || '').includes(search);
      });
    }

    const rows = document.getElementById('pr-list-rows');
    rows.innerHTML = returns.map(r => {
      const partyName = r.type === 'نقدي' ? r.cashboxName : r.supplierName;
      return `<tr data-id="${r.id}">
        <td>${Utils.escapeHtml(r.returnNo)}</td><td>${Utils.escapeHtml(r.date)}</td>
        <td>${Utils.escapeHtml(partyName || '')}</td><td>${Utils.escapeHtml(whMap[r.warehouseId] || '')}</td>
        <td>${Utils.escapeHtml(r.type)}</td><td>${r.net.toFixed(2)}</td>
      </tr>`;
    }).join('') || '<tr><td colspan="6" class="empty-row">لا توجد مرتجعات محفوظة بعد</td></tr>';

    rows.querySelectorAll('tr[data-id]').forEach(tr => {
      tr.addEventListener('click', () => selectReturnRow(Number(tr.dataset.id), tr));
    });
  }

  function selectReturnRow(id, tr) {
    selectedReturnId = id;
    document.querySelectorAll('#pr-list-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    setToolbarState('search-selected');
  }

  async function loadReturnIntoAddFields(id) {
    const ret = await FarisDB.get(STORES.PURCHASE_RETURNS, id);
    document.getElementById('pr-add-view').classList.remove('hidden');
    document.getElementById('pr-search-view').classList.add('hidden');
    renderAddView();

    document.getElementById('pr-no').value = ret.returnNo;
    document.getElementById('pr-date').value = ret.date;
    document.getElementById('pr-type').value = ret.type;
    onTypeChange();
    document.getElementById('pr-currency').value = ret.currencyId;
    document.getElementById('pr-party-currency').value = ret.currencyId;
    document.getElementById('pr-warehouse').value = ret.warehouseId;
    updateWarehouseCurrencyDisplay();
    updateWarehousePreview();
    document.getElementById('pr-reference').value = ret.reference || '';

    if (ret.supplierId) {
      const supplier = suppliersCache.find(s => s.id === ret.supplierId);
      document.getElementById('pr-supplier-input').value = supplier ? supplier.name : ret.supplierName;
      document.getElementById('pr-supplier-id').value = ret.supplierId;
      document.getElementById('pr-supplier-no').value = supplier ? supplier.partyNumber : '';
    }
    if (ret.cashboxId) {
      const cashbox = cashboxesCache.find(c => c.id === ret.cashboxId);
      document.getElementById('pr-cashbox-input').value = cashbox ? cashbox.name : ret.cashboxName;
      document.getElementById('pr-cashbox-id').value = ret.cashboxId;
      document.getElementById('pr-cashbox-no').value = cashbox ? cashbox.partyNumber : '';
    }
    document.getElementById('pr-discount').value = ret.discount;

    draftLines = [];
    document.getElementById('pr-lines-rows').innerHTML = '';
    (ret.lines || []).forEach(l => addReturnRow(l));
    for (let i = 0; i < 5; i++) addReturnRow();
    editId = ret.id;
    currentJournalId = ret.journalId || null;
    recomputeTotals();
    setToolbarState('add-saved');
    mode = 'add';
    setHeaderEditable(true);
  }

  // يتحقق أن تعديل/حذف مرجوع المشتريات آمن زمنيًا: لا حركة واردة لاحقة اعتمدت على توازن الكمية بعد هذا المرتجع
  async function findLockingMovement(ret) {
    for (let idx = 0; idx < (ret.lines || []).length; idx++) {
      const l = ret.lines[idx];
      const key = `purchase-return-${ret.id}-${idx}`;
      const blocker = await ItemMovementEngine.findBlockingLaterMovement(l.itemCode, ret.warehouseId, ret.date, false, key);
      if (blocker) return { itemName: l.itemName, blocker };
    }
    return null;
  }

  async function onEditSelected() {
    if (!selectedReturnId) return;
    const ret = await FarisDB.get(STORES.PURCHASE_RETURNS, selectedReturnId);
    const locked = await findLockingMovement(ret);
    if (locked) {
      Utils.toast(`لا يمكن تعديل المرتجع: صنف "${locked.itemName}" له حركة لاحقة (${locked.blocker.type} رقم ${locked.blocker.docNo} بتاريخ ${locked.blocker.date})`, 'error');
      return;
    }
    await loadReturnIntoAddFields(selectedReturnId);
  }

  async function onDuplicateFromSelected() {
    const id = editId || selectedReturnId;
    if (!id) return;
    await loadReturnIntoAddFields(id);
    editId = null;
    currentJournalId = null;
    document.getElementById('pr-no').value = await nextReturnNo();
    document.getElementById('pr-date').value = new Date().toISOString().slice(0, 10);
    setToolbarState('add-empty');
    Utils.toast('انسخت بيانات المرتجع، عدّل ما يلزم ثم احفظ كمرتجع جديد', 'info');
  }

  async function onDelete() {
    const id = editId || selectedReturnId;
    if (!id) return;
    const ret = await FarisDB.get(STORES.PURCHASE_RETURNS, id);
    const locked = await findLockingMovement(ret);
    if (locked) {
      Utils.toast(`لا يمكن حذف المرتجع: صنف "${locked.itemName}" له حركة لاحقة (${locked.blocker.type} رقم ${locked.blocker.docNo} بتاريخ ${locked.blocker.date})`, 'error');
      return;
    }
    const ok = await Utils.confirmDialog('هل تريد حذف هذا المرتجع؟ (لا يمكن التراجع)');
    if (!ok) return;
    if (ret && ret.journalId) {
      await FarisDB.remove(STORES.JOURNAL, ret.journalId);
    }
    await FarisDB.remove(STORES.PURCHASE_RETURNS, id);
    Utils.toast('تم حذف المرتجع وقيده المحاسبي', 'success');
    if (mode === 'search') await loadListRows();
    else onAddNew();
  }

  async function onViewJournal() {
    const id = editId || selectedReturnId;
    if (!id) return;
    const ret = await FarisDB.get(STORES.PURCHASE_RETURNS, id);
    const lines = ret.journalLines || [];
    const rows = lines.map(l => `
      <tr>
        <td>${Utils.escapeHtml(l.accountCode)}</td>
        <td>${Utils.escapeHtml(l.accountName)}</td>
        <td>${Utils.escapeHtml(l.currencySymbol || '')}</td>
        <td>${l.exchangeRate || ''}</td>
        <td>${Utils.escapeHtml(l.statement)}</td>
        <td>${l.debit || ''}</td>
        <td>${l.credit || ''}</td>
        <td>${l.debitLocal || ''}</td>
        <td>${l.creditLocal || ''}</td>
      </tr>`).join('') || '<tr><td colspan="9" class="empty-row">لا يوجد قيد محفوظ</td></tr>';

    document.getElementById('pr-journal-content').innerHTML = `
      <div class="table-scroll" style="overflow-x:auto;">
        <table class="data-table" style="table-layout:auto; width:auto; min-width:100%;">
          <thead><tr>
            <th>رقم الحساب</th><th>اسم الحساب</th><th>رمز العملة</th><th>سعر الصرف</th><th>البيان</th>
            <th>مدين</th><th>دائن</th><th>مدين محلي</th><th>دائن محلي</th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    `;
    Utils.openSheet(document.getElementById('pr-journal-popup'));
  }

  function onPrintSelected() {
    const id = editId || selectedReturnId;
    if (!id) return;
    FarisDB.get(STORES.PURCHASE_RETURNS, id).then(ret => {
      const currency = currencyById(ret.currencyId);
      const symbol = currency ? currency.symbol : '';
      const currencyName = currency ? currency.name : '';
      const partyName = ret.type === 'نقدي' ? ret.cashboxName : ret.supplierName;
      const partyLabel = ret.type === 'نقدي' ? 'اسم الصندوق' : 'اسم المورد';

      const headers = ['م', 'رقم الصنف', 'اسم الصنف', 'الوحدة', 'رقم فاتورة الشراء', 'الكمية', 'السعر الوحدة', 'الخصم', 'الإجمالي'];
      const rows = ret.lines.map((l, i) => [i + 1, l.itemCode, l.itemName, l.unitName, l.invoiceNo, l.qty, l.price.toFixed(2), (l.lineDiscount || 0).toFixed(2), l.total.toFixed(2)]);

      const extraHeaderHtml = `
        <div class="doc-header-row">
          <div class="dh-right"><b>رقم المرجوع:</b> ${Utils.escapeHtml(ret.returnNo)}</div>
          <div class="dh-center">مرجوع مشتريات: ${Utils.escapeHtml(ret.type)}</div>
          <div class="dh-left">${Utils.escapeHtml(ret.date)}</div>
        </div>
        <div class="doc-header-row">
          <div class="dh-right"><b>${Utils.escapeHtml(partyLabel)}:</b> ${Utils.escapeHtml(partyName || '')}</div>
          <div class="dh-center"></div>
          <div class="dh-left">${Utils.escapeHtml(currencyName)}</div>
        </div>
      `;

      const discountLine = ret.discount > 0
        ? `<div class="df-line"><b>الخصم السابق:</b> <span>${ret.discount.toFixed(2)}</span></div>`
        : '';
      const netWords = ReportPrint.amountToWords(ret.net, currencyName, currency ? currency.fraction : '');
      const extraFooterHtml = `
        <div class="doc-footer-lines">
          <div class="df-line"><b>اجمالي المرجوع:</b> <span>${ret.beforeDiscount.toFixed(2)} ${Utils.escapeHtml(symbol)}</span></div>
          ${discountLine}
          <div class="df-line"><b>اجمالي صافي المرجوع:</b> <span>${ret.net.toFixed(2)} ${Utils.escapeHtml(symbol)}</span></div>
          <div class="df-words"><b>صافي اجمالي المرجوع:</b> ${Utils.escapeHtml(netWords)}</div>
        </div>
      `;

      ReportPrint.print({
        title: `مرجوع مشتريات رقم ${ret.returnNo}`,
        extraHeaderHtml, extraFooterHtml,
        headers, rows
      });
    });
  }

  return { render };
})();
