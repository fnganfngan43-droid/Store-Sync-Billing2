/* =========================================================
   شاشات العملاء / الصناديق / البنوك / الموردين - فرعية من الدليل المحاسبي
   (منطق مشترك، يتغير حسب النوع المُمرَّر)
   ========================================================= */

const ChartParties = (function () {

  const CONFIG = {
    customers: { store: STORES.CUSTOMERS, analyticType: 'عميل', title: 'العملاء', numberLabel: 'رقم العميل' },
    cashboxes: { store: STORES.CASHBOXES, analyticType: 'صناديق', title: 'الصناديق', numberLabel: 'رقم الصندوق' },
    banks: { store: STORES.BANKS, analyticType: 'بنوك', title: 'البنوك', numberLabel: 'رقم البنك' },
    suppliers: { store: STORES.SUPPLIERS, analyticType: 'موردين', title: 'الموردون', numberLabel: 'رقم المورد' }
  };

  let selectedId = null;
  let currentType = null;

  function init() {}

  async function render(container, type) {
    currentType = type;
    selectedId = null;
    const cfg = CONFIG[type];

    container.innerHTML = `
      <div class="toolbar">
        <button class="btn btn-icon" id="pt-add">➕ إضافة</button>
        <button class="btn btn-icon" id="pt-edit" disabled>✏️ تعديل</button>
        <button class="btn btn-icon" id="pt-del" disabled>🗑️ حذف</button>
        ${type === 'customers' ? '<button class="btn btn-icon" id="pt-import">📥 استيراد من إكسل</button>' : ''}
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>${cfg.numberLabel}</th><th>رقم الحساب</th><th>الاسم</th><th>الجوال</th></tr></thead>
          <tbody id="pt-rows"></tbody>
        </table>
      </div>

      <div class="bottom-sheet sheet-tall" id="pt-sheet">
        <div class="sheet-handle"></div>
        <h3 id="pt-sheet-title">إضافة ${cfg.title.replace(/ون$|ات$/, '')}</h3>
        <form id="pt-form">
          <div class="form-grid">
            <label class="required field-wide">الحساب (التحليلي)<select id="pt-parent" required></select></label>
            <label class="optional">${cfg.numberLabel}<input type="text" id="pt-number" placeholder="1 افتراضيًا"></label>
            <label class="required">الاسم<input type="text" id="pt-name" required></label>
            <label class="optional field-wide">رقم الجوال<input type="tel" id="pt-mobile" dir="ltr"></label>

            <label class="optional">الدولة<select id="pt-country"></select></label>
            <label class="optional">المحافظة<select id="pt-gov"></select></label>
            <label class="optional field-wide">المدينة<select id="pt-city"></select></label>

            <label class="required field-wide">العملات (يجب اختيار عملة واحدة على الأقل)
              <div id="pt-currencies" class="checkbox-grid"></div>
            </label>
          </div>

          <div class="sheet-actions">
            <button type="button" class="btn btn-ghost" id="pt-cancel">إلغاء</button>
            <button type="submit" class="btn btn-primary">حفظ</button>
          </div>
        </form>
      </div>

      ${type === 'customers' ? `
      <div class="popup-sheet" id="pt-import-popup">
        <div class="popup-header">
          <span>استيراد العملاء من إكسل</span>
          <button class="btn-close" id="pt-import-close">✖️</button>
        </div>
        <p class="hint">
          يبدأ الاستيراد من الصف الثاني (الصف الأول عناوين). ترتيب الأعمدة يجب أن يكون:<br>
          <b>1) رمز الحساب التحليلي &nbsp; 2) رقم العميل (اختياري) &nbsp; 3) الاسم &nbsp; 4) رقم الجوال &nbsp; 5) الدولة &nbsp; 6) المحافظة &nbsp; 7) المدينة &nbsp; 8) رموز العملات مفصولة بفاصلة</b>
        </p>
        <input type="file" id="pt-import-file" accept=".xlsx,.xls,.csv">
        <p class="hint" id="pt-import-status"></p>
      </div>` : ''}
    `;

    container.querySelector('#pt-add').addEventListener('click', () => openSheet(null));
    container.querySelector('#pt-edit').addEventListener('click', () => openSheet(selectedId));
    container.querySelector('#pt-del').addEventListener('click', onDelete);
    container.querySelector('#pt-cancel').addEventListener('click', () => Utils.closeSheet(document.getElementById('pt-sheet')));
    container.querySelector('#pt-form').addEventListener('submit', onSave);
    container.querySelector('#pt-country').addEventListener('change', onCountryChange);
    container.querySelector('#pt-gov').addEventListener('change', onGovChange);
    container.querySelector('#pt-parent').addEventListener('change', () => renderCurrencyCheckboxes([]));

    if (type === 'customers') {
      container.querySelector('#pt-import').addEventListener('click', () => {
        document.getElementById('pt-import-status').textContent = '';
        document.getElementById('pt-import-file').value = '';
        Utils.openSheet(document.getElementById('pt-import-popup'));
      });
      container.querySelector('#pt-import-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('pt-import-popup')));
      container.querySelector('#pt-import-file').addEventListener('change', onImportExcel);
    }

    await loadRows();
  }

  async function fillParentAccounts(selectEl, selectedValue) {
    const cfg = CONFIG[currentType];
    const accounts = await FarisDB.getAllByIndex(STORES.ACCOUNTS, 'analyticType', cfg.analyticType);
    selectEl.innerHTML = accounts.map(a => `<option value="${a.code}">${a.code} - ${Utils.escapeHtml(a.name)}</option>`).join('')
      || '<option value="">لا توجد حسابات تحليلية من هذا النوع بعد</option>';
    if (selectedValue) selectEl.value = selectedValue;
  }

  async function fillCountries(selectEl, selectedValue) {
    const countries = await FarisDB.getAll(STORES.COUNTRIES);
    selectEl.innerHTML = '<option value="">—</option>' + countries.map(c => `<option value="${c.id}">${Utils.escapeHtml(c.name)}</option>`).join('');
    if (selectedValue) selectEl.value = selectedValue;
  }

  async function fillGovs(selectEl, countryId, selectedValue) {
    const govs = countryId ? await FarisDB.getAllByIndex(STORES.GOVERNORATES, 'countryId', Number(countryId)) : [];
    selectEl.innerHTML = '<option value="">—</option>' + govs.map(g => `<option value="${g.id}">${Utils.escapeHtml(g.name)}</option>`).join('');
    if (selectedValue) selectEl.value = selectedValue;
  }

  async function fillCities(selectEl, governorateId, selectedValue) {
    const locs = governorateId ? await FarisDB.getAllByIndex(STORES.LOCATIONS, 'governorateId', Number(governorateId)) : [];
    selectEl.innerHTML = '<option value="">—</option>' + locs.map(l => `<option value="${Utils.escapeHtml(l.city)}">${Utils.escapeHtml(l.city)}</option>`).join('');
    if (selectedValue) selectEl.value = selectedValue;
  }

  async function onCountryChange(e) {
    await fillGovs(document.getElementById('pt-gov'), e.target.value);
    await fillCities(document.getElementById('pt-city'), null);
  }
  async function onGovChange(e) {
    await fillCities(document.getElementById('pt-city'), e.target.value);
  }

  async function renderCurrencyCheckboxes(selectedIds = [], defaultId = null) {
    const parentCode = document.getElementById('pt-parent').value;
    const wrap = document.getElementById('pt-currencies');
    const currencies = await FarisDB.getAll(STORES.CURRENCIES);

    let allowedIds = [];
    if (parentCode) {
      const account = await FarisDB.get(STORES.ACCOUNTS, parentCode);
      allowedIds = (account && account.currencies) || [];
    }

    wrap.innerHTML = currencies.map(c => {
      const allowed = allowedIds.includes(c.id);
      const checked = selectedIds.includes(c.id) && allowed;
      return `
      <label class="currency-check ${allowed ? '' : 'disabled'}">
        <input type="checkbox" name="pt-cur" value="${c.id}" ${checked ? 'checked' : ''} ${allowed ? '' : 'disabled'}>
        (${Utils.escapeHtml(c.symbol)}) ${Utils.escapeHtml(c.name)}
        <input type="radio" name="pt-cur-default" value="${c.id}" ${defaultId === c.id ? 'checked' : ''} ${allowed ? '' : 'disabled'} title="عملة افتراضية">
      </label>`;
    }).join('') || '<p class="hint">أضف عملات أولًا من شاشة التهيئة</p>';
  }

  async function loadRows() {
    const cfg = CONFIG[currentType];
    const items = await FarisDB.getAll(cfg.store);
    const rows = document.getElementById('pt-rows');
    rows.innerHTML = items.map(p => `
      <tr data-id="${p.id}">
        <td>${Utils.escapeHtml(p.partyNumber)}</td>
        <td>${Utils.escapeHtml(p.parentAccountCode)}</td>
        <td>${Utils.escapeHtml(p.name)}</td>
        <td>${Utils.escapeHtml(p.mobile || '')}</td>
      </tr>`).join('') || `<tr><td colspan="4" class="empty-row">لا توجد سجلات بعد</td></tr>`;

    rows.querySelectorAll('tr[data-id]').forEach(tr => {
      tr.addEventListener('click', () => selectRow(Number(tr.dataset.id), tr));
    });
  }

  function selectRow(id, tr) {
    selectedId = id;
    document.querySelectorAll('#pt-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    document.getElementById('pt-edit').disabled = false;
    document.getElementById('pt-del').disabled = false;
  }

  async function nextPartyNumber(parentAccountCode) {
    const cfg = CONFIG[currentType];
    const siblings = await FarisDB.getAllByIndex(cfg.store, 'parentAccountCode', parentAccountCode);
    if (!siblings.length) return 1;
    const numeric = siblings.map(s => Number(s.partyNumber)).filter(n => !isNaN(n));
    if (!numeric.length) return 1;
    return Math.max(...numeric) + 1;
  }

  async function openSheet(id) {
    const sheet = document.getElementById('pt-sheet');
    document.getElementById('pt-form').reset();
    await fillParentAccounts(document.getElementById('pt-parent'));
    await fillCountries(document.getElementById('pt-country'));
    await fillGovs(document.getElementById('pt-gov'), null);
    await fillCities(document.getElementById('pt-city'), null);

    if (id) {
      const item = await FarisDB.get(CONFIG[currentType].store, id);
      document.getElementById('pt-parent').value = item.parentAccountCode;
      document.getElementById('pt-number').value = item.partyNumber;
      document.getElementById('pt-name').value = item.name;
      document.getElementById('pt-mobile').value = item.mobile || '';
      await fillCountries(document.getElementById('pt-country'), item.countryId);
      await fillGovs(document.getElementById('pt-gov'), item.countryId, item.governorateId);
      await fillCities(document.getElementById('pt-city'), item.governorateId, item.city);
      await renderCurrencyCheckboxes(item.currencies || [], item.defaultCurrency || null);
      sheet.dataset.editId = id;
    } else {
      await renderCurrencyCheckboxes([]);
      sheet.dataset.editId = '';
    }

    Utils.openSheet(sheet);
    Utils.bindKeyboardAwareScroll(sheet);
  }

  async function onSave(e) {
    e.preventDefault();
    const sheet = document.getElementById('pt-sheet');
    const editId = sheet.dataset.editId ? Number(sheet.dataset.editId) : null;
    const cfg = CONFIG[currentType];

    const parentAccountCode = document.getElementById('pt-parent').value;
    if (!parentAccountCode) {
      Utils.toast('يجب إنشاء حساب تحليلي من هذا النوع في الدليل المحاسبي أولًا', 'error');
      return;
    }

    let partyNumber = document.getElementById('pt-number').value.trim();
    if (!editId && !partyNumber) {
      partyNumber = String(await nextPartyNumber(parentAccountCode));
    }

    const checked = Array.from(document.querySelectorAll('input[name="pt-cur"]:checked')).map(i => Number(i.value));
    const def = document.querySelector('input[name="pt-cur-default"]:checked');

    if (!checked.length) {
      Utils.toast('يجب اختيار عملة واحدة على الأقل', 'error');
      document.getElementById('pt-currencies').closest('label').classList.add('field-invalid');
      return;
    }
    document.getElementById('pt-currencies').closest('label').classList.remove('field-invalid');

    const name = document.getElementById('pt-name').value.trim();
    const siblings = await FarisDB.getAllByIndex(cfg.store, 'parentAccountCode', parentAccountCode);
    const dup = siblings.some(s => s.name === name && s.id !== editId);
    if (dup) {
      Utils.toast('هذا الاسم مكرر تحت نفس الحساب، اختر اسمًا آخر', 'error');
      document.getElementById('pt-name').classList.add('field-invalid');
      return;
    }
    document.getElementById('pt-name').classList.remove('field-invalid');

    const value = {
      parentAccountCode,
      partyNumber,
      name,
      mobile: document.getElementById('pt-mobile').value.trim(),
      countryId: document.getElementById('pt-country').value ? Number(document.getElementById('pt-country').value) : null,
      governorateId: document.getElementById('pt-gov').value ? Number(document.getElementById('pt-gov').value) : null,
      city: document.getElementById('pt-city').value || '',
      currencies: checked,
      defaultCurrency: def ? Number(def.value) : (checked[0] || null)
    };
    if (editId) value.id = editId;

    await FarisDB.put(cfg.store, value);
    Utils.closeSheet(sheet);
    Utils.toast('تم الحفظ بنجاح', 'success');
    await loadRows();
  }

  async function onDelete() {
    if (!selectedId) return;
    const cfg = CONFIG[currentType];
    const item = await FarisDB.get(cfg.store, selectedId);
    const analyticCode = `${item.parentAccountCode}-${item.partyNumber}`;

    if (await ReportData.hasMovement(item.parentAccountCode, analyticCode)) {
      Utils.toast('لا يمكن حذف هذا السجل لوجود حركة له في شاشة العمليات', 'error');
      return;
    }

    const ok = await Utils.confirmDialog('هل تريد حذف هذا السجل؟');
    if (!ok) return;
    await FarisDB.remove(cfg.store, selectedId);
    selectedId = null;
    document.getElementById('pt-edit').disabled = true;
    document.getElementById('pt-del').disabled = true;
    await loadRows();
    Utils.toast('تم الحذف', 'success');
  }

  async function onImportExcel(e) {
    const file = e.target.files[0];
    if (!file) return;
    const statusEl = document.getElementById('pt-import-status');
    statusEl.textContent = 'جاري القراءة...';

    if (typeof XLSX === 'undefined') {
      statusEl.textContent = 'تعذّر تحميل مكتبة قراءة إكسل. تأكد من توفر اتصال إنترنت عند أول استخدام لهذه الميزة.';
      return;
    }

    try {
      const cfg = CONFIG[currentType];
      const data = await file.arrayBuffer();
      const wb = XLSX.read(data, { type: 'array' });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: false, defval: '' });
      const dataRows = rows.slice(1);

      const accounts = await FarisDB.getAllByIndex(STORES.ACCOUNTS, 'analyticType', cfg.analyticType);
      const currencies = await FarisDB.getAll(STORES.CURRENCIES);
      const locations = await FarisDB.getAll(STORES.LOCATIONS);
      const countries = await FarisDB.getAll(STORES.COUNTRIES);
      const govs = await FarisDB.getAll(STORES.GOVERNORATES);

      let added = 0, skipped = 0;

      for (const row of dataRows) {
        const [parentAccountCode, partyNumberRaw, name, mobile, countryName, govName, city, currencySymbols] =
          row.map(v => String(v ?? '').trim());

        if (!parentAccountCode || !name) { skipped++; continue; }
        const parent = accounts.find(a => a.code === parentAccountCode);
        if (!parent) { skipped++; continue; }

        const siblings = await FarisDB.getAllByIndex(cfg.store, 'parentAccountCode', parentAccountCode);
        if (siblings.some(s => s.name === name)) { skipped++; continue; }

        const matchedCurrencies = (currencySymbols || '')
          .split(',').map(s => s.trim()).filter(Boolean)
          .map(sym => { const c = currencies.find(c => c.symbol === sym || c.name === sym); return c ? c.id : null; })
          .filter(id => id !== null && (parent.currencies || []).includes(id));
        if (!matchedCurrencies.length) { skipped++; continue; }

        const country = countries.find(c => c.name === countryName);
        const gov = govs.find(g => g.name === govName && (!country || g.countryId === country.id));

        let partyNumber = partyNumberRaw;
        if (!partyNumber) {
          const numeric = siblings.map(s => Number(s.partyNumber)).filter(n => !isNaN(n));
          partyNumber = String(numeric.length ? Math.max(...numeric) + 1 : 1);
        }

        const value = {
          parentAccountCode, partyNumber, name,
          mobile, countryId: country ? country.id : null, governorateId: gov ? gov.id : null,
          city: city || '', currencies: matchedCurrencies, defaultCurrency: matchedCurrencies[0]
        };
        await FarisDB.put(cfg.store, value);
        added++;
      }

      statusEl.textContent = `تم استيراد ${added} سجل، وتخطي ${skipped} صف (بيانات ناقصة/مكررة/حساب أو عملة غير موجودة).`;
      await loadRows();
    } catch (err) {
      statusEl.textContent = 'تعذّرت قراءة الملف، تأكد من صيغة الإكسل.';
    }
    e.target.value = '';
  }

  return { init, render };
})();
