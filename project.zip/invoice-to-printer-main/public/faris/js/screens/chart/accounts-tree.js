/* =========================================================
   شاشة الدليل المحاسبي (الشجرة) - فرعية من شاشة الدليل
   ========================================================= */

const ChartTree = (function () {
  let selectedCode = null;
  let expanded = new Set(['1', '2', '3', '4']);
  let allAccounts = [];
  let currenciesCache = [];

  function init() {}

  async function render(container) {
    selectedCode = null;
    container.innerHTML = `
      <div class="toolbar">
        <button class="btn btn-icon" id="acc-add" disabled>➕ إضافة</button>
        <button class="btn btn-icon" id="acc-edit" disabled>✏️ تعديل</button>
        <button class="btn btn-icon" id="acc-del" disabled>🗑️ حذف</button>
        <button class="btn btn-icon" id="acc-import">📥 استيراد من إكسل</button>
      </div>
      <div class="tree-scroll" id="acc-tree"></div>

      <div class="bottom-sheet sheet-tall" id="acc-sheet">
        <div class="sheet-handle"></div>
        <h3 id="acc-sheet-title">إضافة حساب</h3>
        <form id="acc-form">
          <div class="form-grid">
            <label class="optional field-wide">الحساب الأب<input type="text" id="acc-parent-display" readonly></label>
            <label class="required field-wide">اسم الحساب<input type="text" id="acc-name" required></label>

            <label class="required">نوع الحساب
              <select id="acc-type" required>
                <option value="رئيسي">رئيسي</option>
                <option value="فرعي">فرعي</option>
              </select>
            </label>

            <label class="required">طبيعة الحساب
              <select id="acc-nature" required>
                <option value="مدين">مدين</option>
                <option value="دائن">دائن</option>
              </select>
            </label>

            <label class="required">نوع التقرير
              <select id="acc-report-type" required>
                <option value="ميزانية عمومية">ميزانية عمومية</option>
                <option value="أرباح وخسائر">أرباح وخسائر</option>
              </select>
            </label>

            <label class="required" id="acc-analytic-wrap">نوع الحساب التحليلي
              <select id="acc-analytic-type">
                <option value="عام">عام</option>
                <option value="عميل">عملاء</option>
                <option value="صناديق">صناديق</option>
                <option value="بنوك">بنوك</option>
                <option value="موردين">موردون</option>
              </select>
            </label>

            <label class="required field-wide">العملات المسموحة (يجب اختيار عملة واحدة على الأقل)
              <div id="acc-currencies" class="checkbox-grid"></div>
            </label>

            <label class="optional field-wide">رقم الحساب (تلقائي)<input type="text" id="acc-code-preview" readonly></label>
          </div>

          <div class="sheet-actions">
            <button type="button" class="btn btn-ghost" id="acc-cancel">إلغاء</button>
            <button type="submit" class="btn btn-primary">حفظ</button>
          </div>
        </form>
      </div>

      <div class="popup-sheet" id="acc-import-popup">
        <div class="popup-header">
          <span>استيراد الدليل المحاسبي من إكسل</span>
          <button class="btn-close" id="acc-import-close">✖️</button>
        </div>
        <p class="hint">
          يبدأ الاستيراد من الصف الثاني (الصف الأول عناوين). ترتيب الأعمدة يجب أن يكون:<br>
          <b>1) رقم الحساب الأب &nbsp; 2) اسم الحساب &nbsp; 3) نوع الحساب (رئيسي/فرعي) &nbsp; 4) طبيعة الحساب (مدين/دائن) &nbsp; 5) نوع التقرير &nbsp; 6) نوع الحساب التحليلي (اختياري) &nbsp; 7) رموز العملات مفصولة بفاصلة</b>
        </p>
        <input type="file" id="acc-import-file" accept=".xlsx,.xls,.csv">
        <p class="hint" id="acc-import-status"></p>
      </div>
    `;

    container.querySelector('#acc-add').addEventListener('click', () => openAddSheet());
    container.querySelector('#acc-edit').addEventListener('click', () => openEditSheet(selectedCode));
    container.querySelector('#acc-del').addEventListener('click', onDelete);
    container.querySelector('#acc-cancel').addEventListener('click', () => Utils.closeSheet(document.getElementById('acc-sheet')));
    container.querySelector('#acc-form').addEventListener('submit', onSave);
    container.querySelector('#acc-type').addEventListener('change', onTypeChange);

    container.querySelector('#acc-import').addEventListener('click', () => {
      document.getElementById('acc-import-status').textContent = '';
      document.getElementById('acc-import-file').value = '';
      Utils.openSheet(document.getElementById('acc-import-popup'));
    });
    container.querySelector('#acc-import-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('acc-import-popup')));
    container.querySelector('#acc-import-file').addEventListener('change', onImportExcel);

    await loadTree();
  }

  async function loadTree() {
    allAccounts = await FarisDB.getAll(STORES.ACCOUNTS);
    currenciesCache = await FarisDB.getAll(STORES.CURRENCIES);
    drawTree();
  }

  function drawTree() {
    const roots = allAccounts.filter(a => !a.parentCode).sort((a, b) => a.code.localeCompare(b.code));
    const wrap = document.getElementById('acc-tree');
    wrap.innerHTML = '';
    roots.forEach(r => wrap.appendChild(buildNode(r)));
  }

  function buildNode(account) {
    const children = allAccounts.filter(a => a.parentCode === account.code).sort((a, b) => a.code.localeCompare(b.code));
    const hasChildren = children.length > 0;
    const isExpanded = expanded.has(account.code);

    const li = Utils.el(`
      <div class="tree-node">
        <div class="tree-row ${selectedCode === account.code ? 'selected' : ''}" data-code="${account.code}">
          <span class="tree-toggle ${hasChildren ? '' : 'invisible'}">${hasChildren ? (isExpanded ? '▾' : '▸') : '•'}</span>
          <span class="tree-label">
            <span class="tree-code">${account.code}</span>
            <span class="tree-name">${Utils.escapeHtml(account.name)}</span>
            ${account.type === 'فرعي' ? `<span class="tag tag-sub">${account.analyticType || 'عام'}</span>` : ''}
          </span>
        </div>
        <div class="tree-children ${isExpanded ? '' : 'hidden'}"></div>
      </div>
    `);

    li.querySelector('.tree-toggle').addEventListener('click', (e) => {
      e.stopPropagation();
      if (!hasChildren) return;
      if (expanded.has(account.code)) expanded.delete(account.code);
      else expanded.add(account.code);
      drawTree();
    });

    li.querySelector('.tree-label').addEventListener('click', () => selectNode(account));

    if (hasChildren && isExpanded) {
      const childWrap = li.querySelector('.tree-children');
      children.forEach(c => childWrap.appendChild(buildNode(c)));
    }

    return li;
  }

  function selectNode(account) {
    selectedCode = account.code;
    drawTree();

    const canHaveChildren = account.type === 'رئيسي';
    document.getElementById('acc-add').disabled = !canHaveChildren;
    document.getElementById('acc-edit').disabled = false;
    document.getElementById('acc-del').disabled = !!account.fixed;
  }

  function renderCurrencyCheckboxes(selectedIds = [], defaultId = null, allowedIds = null) {
    const wrap = document.getElementById('acc-currencies');
    wrap.innerHTML = currenciesCache.map(c => {
      const allowed = !allowedIds || allowedIds.includes(c.id);
      const checked = selectedIds.includes(c.id) && allowed;
      return `
      <label class="currency-check ${allowed ? '' : 'disabled'}">
        <input type="checkbox" name="acc-cur" value="${c.id}" ${checked ? 'checked' : ''} ${allowed ? '' : 'disabled'}>
        (${Utils.escapeHtml(c.symbol)}) ${Utils.escapeHtml(c.name)}
        <input type="radio" name="acc-cur-default" value="${c.id}" ${defaultId === c.id ? 'checked' : ''} ${allowed ? '' : 'disabled'} title="عملة افتراضية">
      </label>`;
    }).join('') || '<p class="hint">أضف عملات أولًا من شاشة التهيئة</p>';
  }

  function onTypeChange(e) {
    document.getElementById('acc-analytic-wrap').classList.toggle('hidden', e.target.value !== 'فرعي');
  }

  async function openAddSheet() {
    if (!selectedCode) return;
    const parent = allAccounts.find(a => a.code === selectedCode);
    if (!parent || parent.type !== 'رئيسي') {
      Utils.toast('لا يمكن إضافة حساب فرعي تحت هذا العنصر', 'error');
      return;
    }

    const sheet = document.getElementById('acc-sheet');
    document.getElementById('acc-form').reset();
    document.getElementById('acc-sheet-title').textContent = 'إضافة حساب';
    document.getElementById('acc-parent-display').value = `${parent.code} - ${parent.name}`;
    document.getElementById('acc-nature').value = parent.nature;
    document.getElementById('acc-analytic-wrap').classList.add('hidden');
    const newRank = parent.rank + 1;
    renderCurrencyCheckboxes([], null, newRank <= 2 ? null : (parent.currencies || []));

    // إذا كان الأب من الرتبة 4 فلا يمكن إلا إضافة حساب فرعي (تحليلي)
    const typeSelect = document.getElementById('acc-type');
    if (parent.rank >= 4) {
      typeSelect.value = 'فرعي';
      typeSelect.querySelector('option[value="رئيسي"]').disabled = true;
      document.getElementById('acc-analytic-wrap').classList.remove('hidden');
    } else {
      typeSelect.querySelector('option[value="رئيسي"]').disabled = false;
      typeSelect.value = 'رئيسي';
    }

    sheet.dataset.mode = 'add';
    sheet.dataset.parentCode = parent.code;
    sheet.dataset.parentRank = parent.rank;
    sheet.dataset.editCode = '';

    document.getElementById('acc-code-preview').value = 'يُحدد تلقائيًا عند الحفظ';

    Utils.openSheet(sheet);
    Utils.bindKeyboardAwareScroll(sheet);
  }

  async function openEditSheet(code) {
    if (!code) return;
    const account = allAccounts.find(a => a.code === code);
    if (!account || account.fixed) return;

    const sheet = document.getElementById('acc-sheet');
    document.getElementById('acc-form').reset();
    document.getElementById('acc-sheet-title').textContent = 'تعديل حساب';

    const parent = allAccounts.find(a => a.code === account.parentCode);
    document.getElementById('acc-parent-display').value = parent ? `${parent.code} - ${parent.name}` : '—';
    document.getElementById('acc-name').value = account.name;
    document.getElementById('acc-type').value = account.type;
    document.getElementById('acc-type').disabled = true; // لا يمكن تغيير النوع بعد الإنشاء لتفادي كسر الترقيم
    document.getElementById('acc-nature').value = account.nature;
    document.getElementById('acc-report-type').value = account.reportType || 'ميزانية عمومية';
    document.getElementById('acc-code-preview').value = account.code;

    document.getElementById('acc-analytic-wrap').classList.toggle('hidden', account.type !== 'فرعي');
    if (account.type === 'فرعي') {
      document.getElementById('acc-analytic-type').value = account.analyticType || 'عام';
    }

    renderCurrencyCheckboxes(account.currencies || [], account.defaultCurrency || null,
      account.rank <= 2 ? null : (parent ? (parent.currencies || []) : null));

    sheet.dataset.mode = 'edit';
    sheet.dataset.editCode = account.code;
    sheet.dataset.parentCode = account.parentCode || '';

    Utils.openSheet(sheet);
    Utils.bindKeyboardAwareScroll(sheet);
  }

  function collectCurrencies() {
    const checked = Array.from(document.querySelectorAll('input[name="acc-cur"]:checked')).map(i => Number(i.value));
    const def = document.querySelector('input[name="acc-cur-default"]:checked');
    return { currencies: checked, defaultCurrency: def ? Number(def.value) : (checked[0] || null) };
  }

  async function onSave(e) {
    e.preventDefault();
    const sheet = document.getElementById('acc-sheet');
    const mode = sheet.dataset.mode;
    const { currencies, defaultCurrency } = collectCurrencies();

    const name = document.getElementById('acc-name').value.trim();
    const type = document.getElementById('acc-type').value;
    const nature = document.getElementById('acc-nature').value;
    const reportType = document.getElementById('acc-report-type').value;
    const analyticType = type === 'فرعي' ? document.getElementById('acc-analytic-type').value : null;
    const parentCodeForCheck = mode === 'add' ? sheet.dataset.parentCode : sheet.dataset.parentCode;
    const editCode = sheet.dataset.editCode;

    const nameField = document.getElementById('acc-name');
    const dupName = allAccounts.some(a => a.parentCode === parentCodeForCheck && a.name === name && a.code !== editCode);
    if (dupName) {
      Utils.toast('اسم الحساب مكرر تحت نفس الحساب الأب، اختر اسمًا آخر', 'error');
      nameField.classList.add('field-invalid');
      return;
    }
    nameField.classList.remove('field-invalid');

    if (!currencies.length) {
      Utils.toast('يجب اختيار عملة واحدة على الأقل للحساب', 'error');
      document.getElementById('acc-currencies').closest('label').classList.add('field-invalid');
      return;
    }
    document.getElementById('acc-currencies').closest('label').classList.remove('field-invalid');

    if (mode === 'add') {
      const parentCode = sheet.dataset.parentCode;
      const parent = allAccounts.find(a => a.code === parentCode);
      const code = await AccountNumbering.nextCode(parentCode, type);
      const rank = parent.rank + 1;

      const account = {
        code, name, type, nature, reportType, rank,
        parentCode, analyticType, currencies, defaultCurrency, fixed: false
      };
      await FarisDB.put(STORES.ACCOUNTS, account);
      expanded.add(parentCode);
      Utils.toast(`تم إنشاء الحساب برقم ${code}`, 'success');
    } else {
      const code = sheet.dataset.editCode;
      const account = allAccounts.find(a => a.code === code);
      account.name = name;
      account.nature = nature;
      account.reportType = reportType;
      account.analyticType = analyticType;
      account.currencies = currencies;
      account.defaultCurrency = defaultCurrency;
      await FarisDB.put(STORES.ACCOUNTS, account);
      Utils.toast('تم تعديل الحساب بنجاح', 'success');
    }

    Utils.closeSheet(sheet);
    await loadTree();
  }

  async function onDelete() {
    if (!selectedCode) return;
    const account = allAccounts.find(a => a.code === selectedCode);
    if (!account || account.fixed) return;

    const child = allAccounts.find(a => a.parentCode === account.code);
    if (child) {
      Utils.toast(`لا يمكن حذف هذا الحساب لأن الحساب "${child.code} - ${child.name}" مرتبط به، احذف الحساب المرتبط أولًا`, 'error');
      return;
    }

    const partyStores = { 'عميل': STORES.CUSTOMERS, 'صناديق': STORES.CASHBOXES, 'بنوك': STORES.BANKS, 'موردين': STORES.SUPPLIERS };
    if (account.analyticType && partyStores[account.analyticType]) {
      const linked = await FarisDB.getAllByIndex(partyStores[account.analyticType], 'parentAccountCode', account.code);
      if (linked.length > 0) {
        Utils.toast('لا يمكن الحذف، يوجد سجلات مرتبطة بهذا الحساب', 'error');
        return;
      }
    }

    if (await ReportData.hasMovement(account.code, null)) {
      Utils.toast('لا يمكن حذف هذا الحساب لوجود حركة له في شاشة العمليات', 'error');
      return;
    }

    const ok = await Utils.confirmDialog(`هل تريد حذف الحساب "${account.name}"؟`);
    if (!ok) return;

    await FarisDB.remove(STORES.ACCOUNTS, account.code);
    selectedCode = null;
    document.getElementById('acc-add').disabled = true;
    document.getElementById('acc-edit').disabled = true;
    document.getElementById('acc-del').disabled = true;
    await loadTree();
    Utils.toast('تم حذف الحساب', 'success');
  }

  async function onImportExcel(e) {
    const file = e.target.files[0];
    if (!file) return;
    const statusEl = document.getElementById('acc-import-status');
    statusEl.textContent = 'جاري القراءة...';

    if (typeof XLSX === 'undefined') {
      statusEl.textContent = 'تعذّر تحميل مكتبة قراءة إكسل. تأكد من توفر اتصال إنترنت عند أول استخدام لهذه الميزة.';
      return;
    }

    try {
      const data = await file.arrayBuffer();
      const wb = XLSX.read(data, { type: 'array' });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: false, defval: '' });

      const dataRows = rows.slice(1); // البدء من الصف الثاني
      currenciesCache = await FarisDB.getAll(STORES.CURRENCIES);
      allAccounts = await FarisDB.getAll(STORES.ACCOUNTS);

      let added = 0, skipped = 0;

      for (const row of dataRows) {
        const [parentCode, name, type, nature, reportType, analyticType, currencySymbols] = row.map(v => String(v ?? '').trim());
        if (!parentCode || !name) { skipped++; continue; }

        const parent = allAccounts.find(a => a.code === parentCode);
        if (!parent || parent.type !== 'رئيسي') { skipped++; continue; }

        const finalType = (type === 'فرعي') ? 'فرعي' : 'رئيسي';
        const dup = allAccounts.some(a => a.parentCode === parentCode && a.name === name);
        if (dup) { skipped++; continue; }

        const matchedCurrencies = (currencySymbols || '')
          .split(',')
          .map(s => s.trim())
          .filter(Boolean)
          .map(sym => {
            const c = currenciesCache.find(c => c.symbol === sym || c.name === sym);
            return c ? c.id : null;
          })
          .filter(id => id !== null);

        if (!matchedCurrencies.length) { skipped++; continue; }

        const code = await AccountNumbering.nextCode(parentCode, finalType);
        const account = {
          code, name,
          type: finalType,
          nature: (nature === 'دائن') ? 'دائن' : 'مدين',
          reportType: (reportType === 'أرباح وخسائر') ? 'أرباح وخسائر' : 'ميزانية عمومية',
          rank: parent.rank + 1,
          parentCode,
          analyticType: finalType === 'فرعي' ? (analyticType || 'عام') : null,
          currencies: matchedCurrencies,
          defaultCurrency: matchedCurrencies[0],
          fixed: false
        };
        await FarisDB.put(STORES.ACCOUNTS, account);
        allAccounts.push(account);
        added++;
      }

      statusEl.textContent = `تم استيراد ${added} حساب، وتخطي ${skipped} صف (بيانات ناقصة/مكررة/عملة غير موجودة).`;
      await loadTree();
    } catch (err) {
      statusEl.textContent = 'تعذّرت قراءة الملف، تأكد من صيغة الإكسل.';
    }
    e.target.value = '';
  }

  return { init, render };
})();
