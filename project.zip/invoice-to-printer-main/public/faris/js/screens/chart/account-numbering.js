/* =========================================================
   محرك ترقيم الحسابات (الدليل المحاسبي)
   القواعد المعتمدة (بالاتفاق مع المستخدم):
   - كل الأرقام بالخانات الإنجليزية (Western digits).
   - الجذور الأربعة (الرتبة 1) ثابتة: 1 2 3 4.
   - حساب "رئيسي" فرعي من رئيسي (رتبة 2 أو 3 أو 4): كود الأب + رقم تسلسلي بخانة واحدة (1..9 ثم 10..).
   - حساب "فرعي" (تحليلي، رتبة 5 أو 6): كود الأب + "0" + رقم تسلسلي بخانتين (01, 02, ...).
   ========================================================= */

const AccountNumbering = (function () {

  async function childrenOf(parentCode) {
    return FarisDB.getAllByIndex(STORES.ACCOUNTS, 'parentCode', parentCode);
  }

  async function nextMainChildCode(parentCode) {
    const kids = await childrenOf(parentCode);
    const mainKids = kids.filter(k => k.type === 'رئيسي');
    let seq = 1;
    const used = new Set(mainKids.map(k => k.code));
    while (used.has(parentCode + String(seq))) seq++;
    return parentCode + String(seq);
  }

  async function nextSubChildCode(parentCode) {
    const kids = await childrenOf(parentCode);
    const subKids = kids.filter(k => k.type === 'فرعي');
    let seq = 1;
    const used = new Set(subKids.map(k => k.code));
    let code;
    do {
      code = parentCode + '0' + String(seq).padStart(2, '0');
      seq++;
    } while (used.has(code));
    return code;
  }

  async function nextCode(parentCode, type) {
    if (type === 'رئيسي') return nextMainChildCode(parentCode);
    return nextSubChildCode(parentCode);
  }

  function rankOf(code, parentRank) {
    return parentRank + 1;
  }

  return { nextCode, childrenOf, rankOf };
})();
