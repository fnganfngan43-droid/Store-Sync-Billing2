/* =========================================================
   صرف عملة
   ========================================================= */

const OpCurrencyExchange = (function () {
  let selectedId = null;
  let currenciesCache = [];
  let resolvedFrom = null; // { accountCode, analyticCode, analyticName }
  let lastEdited = 'amount'; // 'amount' أو 'rate' -- يحدد اتجاه إعادة الحساب

  const PARTY_STORE = { 'عميل': STORES.CUSTOMERS, 'صناديق': STORES.CASHBOXES, 'بنوك': STORES.BANKS, 'موردين': STORES.SUPPLIERS };

  async function render(container) {
    selectedId = null;
    resolvedFrom = null;
    currenciesCache = await FarisDB.getAll(STORES.CURRENCIES);

    container.innerHTML = `
      <div class="toolbar icon-only">
        <button class="btn btn-icon" id="cx-add" title="إضافة">➕</button>
        <button class="btn btn-icon" id="cx-print" title="طباعة">🖨️</button>
        <button class="btn btn-icon" id="cx-edit" disabled title="تعديل">✏️</button>
        <button class="btn btn-icon" id="cx-del" disabled title="حذف">🗑️</button>
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>الرقم</th><th>التاريخ</th><th>الحساب</th><th>من عملة</th><th>إلى عملة</th><th>سعر الصرف</th><th>المبلغ</th></tr></thead>
          <tbody id="cx-rows"></tbody>
        </table>
      </div>

      <div class="bottom-sheet sheet-tall" id="cx-sheet">
        <div class="sheet-handle"></div>
        <h3 id="cx-title">إضافة صرف عملة</h3>
        <form id="cx-form">
          <div class="form-grid">
            <label class="optional">الرقم<input type="text" id="cx-no"></label>
            <label class="required">التاريخ<input type="date" id="cx-date" required></label>
            <label class="optional field-wide">رقم المرجع<input type="text" id="cx-ref"></label>
          </div>

          <div class="voucher-block voucher-debit">
            <h4>الطرف المحول منه</h4>
            <div class="form-grid">
              <label class="required">نوع الحساب التحليلي
                <select id="cx-from-type">
                  <option value="عام">عام</option>
                  <option value="عميل">عملاء</option>
                  <option value="صناديق">صناديق</option>
                  <option value="بنوك">بنوك</option>
                  <option value="موردين">موردون</option>
                </select>
              </label>
              <label class="required">المبلغ (بعملة المصدر)<input type="number" step="0.01" id="cx-from-amount" required></label>

              <label class="required">اسم الحساب
                <div class="combo-wrap">
                  <input type="text" id="cx-from-input" autocomplete="off">
                  <div class="autocomplete-list" id="cx-from-list"></div>
                </div>
              </label>
              <input type="hidden" id="cx-from-value">
              <label class="required">من عملة<select id="cx-from-currency" required></select></label>

              <label class="required">إلى عملة<select id="cx-to-currency" required></select></label>
              <label class="required">سعر الصرف<input type="number" step="0.000001" id="cx-rate" required></label>

              <label class="optional field-wide">البيان<input type="text" id="cx-from-statement"></label>
            </div>
          </div>

          <div class="voucher-block voucher-credit">
            <h4>الطرف المحول إليه</h4>
            <div class="form-grid">
              <label class="optional field-wide">الحساب<input type="text" id="cx-to-display" readonly></label>
              <label class="required">المبلغ (بعملة الوجهة)<input type="number" step="0.01" id="cx-to-amount" required></label>
              <label class="optional field-wide">البيان<input type="text" id="cx-to-statement"></label>
            </div>
          </div>

          <div class="sheet-actions">
            <button type="button" class="btn btn-ghost" id="cx-cancel">إلغاء</button>
            <button type="submit" class="btn btn-primary">حفظ</button>
          </div>
        </form>
      </div>
    `;

    container.querySelector('#cx-add').addEventListener('click', () => openSheet(null));
    container.querySelector('#cx-edit').addEventListener('click', () => openSheet(selectedId));
    container.querySelector('#cx-del').addEventListener('click', onDelete);
    container.querySelector('#cx-print').addEventListener('click', onPrint);
    container.querySelector('#cx-cancel').addEventListener('click', () => Utils.closeSheet(document.getElementById('cx-sheet')));
    container.querySelector('#cx-form').addEventListener('submit', onSave);

    container.querySelector('#cx-from-type').addEventListener('change', () => fillFromAccountOptions());
    container.querySelector('#cx-from-currency').addEventListener('change', onCurrencyPairChange);
    container.querySelector('#cx-to-currency').addEventListener('change', onCurrencyPairChange);
    container.querySelector('#cx-from-amount').addEventListener('input', () => { lastEdited = 'amount'; recompute(); });
    container.querySelector('#cx-rate').addEventListener('input', () => { lastEdited = 'rate'; recompute(); });
    container.querySelector('#cx-to-amount').addEventListener('input', () => { lastEdited = 'toAmount'; recompute(); });

    await fillFromAccountOptions();
    await loadRows();
  }

  function currencySymbol(id) {
    const c = currenciesCache.find(c => c.id === id);
    return c ? c.symbol : '';
  }
  function currencyById(id) {
    return currenciesCache.find(c => c.id === id);
  }

  async function fillFromAccountOptions() {
    const type = document.getElementById('cx-from-type').value;
    const input = document.getElementById('cx-from-input');
    const list = document.getElementById('cx-from-list');
    input.value = '';
    document.getElementById('cx-from-value').value = '';
    resolvedFrom = null;
    document.getElementById('cx-from-currency').innerHTML = '<option value="">—</option>';
    document.getElementById('cx-to-currency').innerHTML = '<option value="">—</option>';
    document.getElementById('cx-to-display').value = '';

    let source = [];
    if (type === 'عام') {
      const accounts = await FarisDB.getAll(STORES.ACCOUNTS);
      source = accounts.filter(a => a.type === 'فرعي' && (!a.analyticType || a.analyticType === 'عام'))
        .map(a => ({ value: a.code, label: `${a.code} - ${a.name}`, displayValue: a.name }));
    } else {
      const store = PARTY_STORE[type];
      const items = await FarisDB.getAll(store);
      source = items.map(p => ({ value: p.id, label: `${p.parentAccountCode}-${p.partyNumber} - ${p.name}`, displayValue: p.name }));
    }

    Utils.attachAutocomplete(input, list, (query) => {
      return query ? source.filter(it => it.label.includes(query)) : source;
    }, (item) => {
      document.getElementById('cx-from-value').value = item.value;
      onFromAccountChange(item.value);
    });
  }

  async function onFromAccountChange(value) {
    const type = document.getElementById('cx-from-type').value;
    if (!value) { resolvedFrom = null; return; }

    let currencyIds = [];
    if (type === 'عام') {
      const account = await FarisDB.get(STORES.ACCOUNTS, value);
      resolvedFrom = { accountCode: account.code, analyticCode: account.code, analyticName: account.name };
      currencyIds = account.currencies || [];
    } else {
      const store = PARTY_STORE[type];
      const party = await FarisDB.get(store, Number(value));
      resolvedFrom = { accountCode: party.parentAccountCode, analyticCode: `${party.parentAccountCode}-${party.partyNumber}`, analyticName: party.name };
      currencyIds = party.currencies || [];
    }

    const list = currenciesCache.filter(c => currencyIds.includes(c.id));
    const opts = list.map(c => `<option value="${c.id}">(${Utils.escapeHtml(c.symbol)}) ${Utils.escapeHtml(c.name)}</option>`).join('') || '<option value="">لا توجد عملات مرتبطة</option>';
    document.getElementById('cx-from-currency').innerHTML = '<option value="">—</option>' + opts;
    document.getElementById('cx-to-currency').innerHTML = '<option value="">—</option>' + opts;
    document.getElementById('cx-to-display').value = resolvedFrom.analyticName;
    onCurrencyPairChange();
  }

  // يحدد الحالة (محلي/أجنبي أو أجنبي/أجنبي) ويملأ سعر الصرف تلقائيًا، ثم يعيد الحساب
  function onCurrencyPairChange() {
    const fromId = Number(document.getElementById('cx-from-currency').value);
    const toId = Number(document.getElementById('cx-to-currency').value);
    const rateField = document.getElementById('cx-rate');

    if (!fromId || !toId) { rateField.value = ''; return; }
    if (fromId === toId) {
      Utils.toast('اختر عملتين مختلفتين', 'error');
      document.getElementById('cx-to-currency').value = '';
      return;
    }

    const from = currencyById(fromId);
    const to = currencyById(toId);
    if (!from || !to) return;

    if (from.type === 'محلي' || to.type === 'محلي') {
      // الحالة الأولى: محلي ↔ أجنبي — سعر الصرف = سعر صرف العملة الأجنبية
      const foreign = from.type === 'اجنبي' ? from : to;
      rateField.value = foreign.rate;
    } else {
      // الحالة الثانية: أجنبي ↔ أجنبي — سعر الصرف = الأعلى ÷ الأدنى
      const higher = from.rate >= to.rate ? from : to;
      const lower = from.rate >= to.rate ? to : from;
      rateField.value = lower.rate ? (higher.rate / lower.rate) : '';
    }

    lastEdited = 'amount';
    recompute();
  }

  function rateBounds() {
    const fromId = Number(document.getElementById('cx-from-currency').value);
    const toId = Number(document.getElementById('cx-to-currency').value);
    const from = currencyById(fromId);
    const to = currencyById(toId);
    if (!from || !to) return { min: null, max: null };

    if (from.type === 'محلي' || to.type === 'محلي') {
      const foreign = from.type === 'اجنبي' ? from : to;
      return { min: foreign.minRate ?? null, max: foreign.maxRate ?? null };
    }
    // في حالة أجنبي↔أجنبي نعتمد حدود العملة ذات سعر الصرف الأعلى (لعدم وجود حدود منفصلة لهذه الحالة في المواصفة)
    const higher = from.rate >= to.rate ? from : to;
    return { min: higher.minRate ?? null, max: higher.maxRate ?? null };
  }

  function recompute() {
    const fromId = Number(document.getElementById('cx-from-currency').value);
    const toId = Number(document.getElementById('cx-to-currency').value);
    const from = currencyById(fromId);
    const to = currencyById(toId);
    if (!from || !to) return;

    const amountField = document.getElementById('cx-from-amount');
    const rateField = document.getElementById('cx-rate');
    const toAmountField = document.getElementById('cx-to-amount');

    let amount = Number(amountField.value) || 0;
    let rate = Number(rateField.value) || 0;
    let toAmount = Number(toAmountField.value) || 0;

    const { min, max } = rateBounds();

    // اتجاه الصيغة: هل حقل "من عملة" هو الطرف الذي نقسم عليه أم نضرب فيه؟
    // محلي↔أجنبي: من=محلي => قسمة، من=أجنبي => ضرب
    // أجنبي↔أجنبي: من = الأعلى سعرًا => ضرب، من = الأدنى سعرًا => قسمة
    let fromIsDivider;
    if (from.type === 'محلي' || to.type === 'محلي') {
      fromIsDivider = from.type === 'محلي';
    } else {
      fromIsDivider = from.rate < to.rate;
    }

    if (lastEdited === 'rate') {
      if (rate) {
        if (min !== null && rate < min) rate = min;
        if (max !== null && rate > max) rate = max;
        rateField.value = rate;
      }
      toAmount = fromIsDivider ? (rate ? amount / rate : 0) : amount * rate;
      toAmountField.value = round2(toAmount);
    } else if (lastEdited === 'toAmount') {
      // إعادة حساب سعر الصرف من المبلغ بعملة الوجهة، مع تقييده بالحدود
      if (toAmount && amount) {
        rate = fromIsDivider ? (amount / toAmount) : (toAmount / amount);
        if (min !== null && rate < min) rate = min;
        if (max !== null && rate > max) rate = max;
        rateField.value = round6(rate);
        toAmount = fromIsDivider ? (rate ? amount / rate : 0) : amount * rate;
        toAmountField.value = round2(toAmount);
      }
    } else {
      // amount تغيّر: أعد حساب المبلغ بعملة الوجهة بنفس سعر الصرف الحالي
      toAmount = fromIsDivider ? (rate ? amount / rate : 0) : amount * rate;
      toAmountField.value = round2(toAmount);
    }

    updateAutoStatements();
  }

  function round2(n) { return Math.round((n + Number.EPSILON) * 100) / 100; }
  function round6(n) { return Math.round((n + Number.EPSILON) * 1000000) / 1000000; }

  function updateAutoStatements() {
    if (!resolvedFrom) return;
    const fromAmount = document.getElementById('cx-from-amount').value || 0;
    const toAmount = document.getElementById('cx-to-amount').value || 0;
    const rate = document.getElementById('cx-rate').value || 0;
    const toName = (currencyById(Number(document.getElementById('cx-to-currency').value)) || {}).name || '';
    const fromName = (currencyById(Number(document.getElementById('cx-from-currency').value)) || {}).name || '';

    const fromStatementField = document.getElementById('cx-from-statement');
    const toStatementField = document.getElementById('cx-to-statement');
    if (!fromStatementField.dataset.touched) fromStatementField.value = `مباع بقيمته ${toAmount} ${toName} بصرف ${rate}`;
    if (!toStatementField.dataset.touched) toStatementField.value = `وارد مشتريات بقيمته ${fromAmount} ${fromName} بصرف ${rate}`;
  }

  async function loadRows() {
    const items = await FarisDB.getAll(STORES.CURRENCY_EXCHANGES);
    const rows = document.getElementById('cx-rows');
    rows.innerHTML = items.map(it => `
      <tr data-id="${it.id}">
        <td>${Utils.escapeHtml(it.no)}</td><td>${Utils.escapeHtml(it.date)}</td>
        <td>${Utils.escapeHtml(it.analyticName)}</td>
        <td>${Utils.escapeHtml(currencySymbol(it.fromCurrencyId))}</td>
        <td>${Utils.escapeHtml(currencySymbol(it.toCurrencyId))}</td>
        <td>${Utils.escapeHtml(it.rate)}</td>
        <td>${it.fromAmount}</td>
      </tr>`).join('') || '<tr><td colspan="7" class="empty-row">لا توجد عمليات صرف عملة بعد</td></tr>';

    rows.querySelectorAll('tr[data-id]').forEach(tr => {
      tr.addEventListener('click', () => selectRow(Number(tr.dataset.id), tr));
    });
  }

  function selectRow(id, tr) {
    selectedId = id;
    document.querySelectorAll('#cx-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    document.getElementById('cx-edit').disabled = false;
    document.getElementById('cx-del').disabled = false;
  }

  async function nextNo() {
    const items = await FarisDB.getAll(STORES.CURRENCY_EXCHANGES);
    const numeric = items.map(i => Number(i.no)).filter(n => !isNaN(n));
    return String(numeric.length ? Math.max(...numeric) + 1 : 1);
  }

  async function openSheet(id) {
    const sheet = document.getElementById('cx-sheet');
    document.getElementById('cx-form').reset();
    document.getElementById('cx-date').value = new Date().toISOString().slice(0, 10);
    document.getElementById('cx-from-statement').dataset.touched = '';
    document.getElementById('cx-to-statement').dataset.touched = '';
    lastEdited = 'amount';
    await fillFromAccountOptions();

    if (id) {
      const item = await FarisDB.get(STORES.CURRENCY_EXCHANGES, id);
      document.getElementById('cx-title').textContent = 'تعديل صرف عملة';
      document.getElementById('cx-no').value = item.no;
      document.getElementById('cx-date').value = item.date;
      document.getElementById('cx-ref').value = item.refNo || '';
      document.getElementById('cx-from-amount').value = item.fromAmount;
      document.getElementById('cx-to-amount').value = item.toAmount;
      document.getElementById('cx-rate').value = item.rate || '';
      document.getElementById('cx-from-statement').value = item.fromStatement || '';
      document.getElementById('cx-from-statement').dataset.touched = '1';
      document.getElementById('cx-to-statement').value = item.toStatement || '';
      document.getElementById('cx-to-statement').dataset.touched = '1';
      sheet.dataset.editId = id;
      Utils.toast('أعد اختيار نوع الحساب واسم الحساب لإعادة تحميل العملات المرتبطة', 'info');
    } else {
      document.getElementById('cx-title').textContent = 'إضافة صرف عملة';
      document.getElementById('cx-no').value = await nextNo();
      sheet.dataset.editId = '';
    }

    Utils.openSheet(sheet);
    Utils.bindKeyboardAwareScroll(sheet);
  }

  async function onSave(e) {
    e.preventDefault();
    const sheet = document.getElementById('cx-sheet');
    const editId = sheet.dataset.editId ? Number(sheet.dataset.editId) : null;

    if (!resolvedFrom) {
      Utils.toast('اختر الحساب التحليلي أولًا', 'error');
      return;
    }
    const fromCurrencyId = Number(document.getElementById('cx-from-currency').value);
    const toCurrencyId = Number(document.getElementById('cx-to-currency').value);
    const fromAmount = Number(document.getElementById('cx-from-amount').value) || 0;
    const toAmount = Number(document.getElementById('cx-to-amount').value) || 0;
    const rate = Number(document.getElementById('cx-rate').value) || 0;

    if (!fromCurrencyId || !toCurrencyId || fromAmount <= 0 || toAmount <= 0 || !rate) {
      Utils.toast('أكمل العملتين والمبلغين وسعر الصرف', 'error');
      return;
    }

    const value = {
      no: document.getElementById('cx-no').value.trim(),
      date: document.getElementById('cx-date').value,
      refNo: document.getElementById('cx-ref').value.trim(),
      accountCode: resolvedFrom.accountCode,
      analyticCode: resolvedFrom.analyticCode,
      analyticName: resolvedFrom.analyticName,
      fromCurrencyId, toCurrencyId, fromAmount, toAmount, rate,
      fromStatement: document.getElementById('cx-from-statement').value.trim(),
      toStatement: document.getElementById('cx-to-statement').value.trim()
    };
    if (editId) value.id = editId;

    await FarisDB.put(STORES.CURRENCY_EXCHANGES, value);
    Utils.closeSheet(sheet);
    Utils.toast('تم الحفظ بنجاح', 'success');
    await loadRows();
  }

  async function onDelete() {
    if (!selectedId) return;
    const ok = await Utils.confirmDialog('هل تريد حذف عملية صرف العملة؟');
    if (!ok) return;
    await FarisDB.remove(STORES.CURRENCY_EXCHANGES, selectedId);
    selectedId = null;
    document.getElementById('cx-edit').disabled = true;
    document.getElementById('cx-del').disabled = true;
    await loadRows();
    Utils.toast('تم الحذف', 'success');
  }

  async function onPrint() {
    const items = await FarisDB.getAll(STORES.CURRENCY_EXCHANGES);
    const headers = ['الرقم', 'التاريخ', 'الحساب', 'من عملة', 'إلى عملة', 'سعر الصرف', 'المبلغ'];
    const rows = items.map(it => [it.no, it.date, it.analyticName, currencySymbol(it.fromCurrencyId), currencySymbol(it.toCurrencyId), it.rate, it.fromAmount]);
    Utils.printTable('صرف عملة', headers, rows);
  }

  return { render };
})();
