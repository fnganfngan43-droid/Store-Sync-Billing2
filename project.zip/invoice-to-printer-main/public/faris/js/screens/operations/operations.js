/* =========================================================
   شاشة العمليات - الحاوية وشريط التنقل بين شاشاتها الفرعية
   ========================================================= */

const ScreenOperations = (function () {

  const tabs = [
    { key: 'opening', label: 'الأرصدة الافتتاحية', icon: '🏁', render: (c) => OpOpeningBalances.render(c) },
    { key: 'journal', label: 'القيود اليومية', icon: '📔', render: (c) => OpJournal.render(c) },
    { key: 'receipt', label: 'سند قبض', icon: '🧾', render: (c) => OpVoucher.render(c, 'receipt') },
    { key: 'payment', label: 'سند الصرف', icon: '💸', render: (c) => OpVoucher.render(c, 'payment') },
    { key: 'exchange', label: 'صرف عملة', icon: '💱', render: (c) => OpCurrencyExchange.render(c) }
  ];

  let activeTab = null;

  function init() {
    App.register('operations', { onShow });

    document.getElementById('operations-back-home').addEventListener('click', () => App.show('home', { replace: true }));

    const nav = document.getElementById('operations-nav');
    nav.innerHTML = tabs.map(t => `
      <button class="nav-icon-btn" data-key="${t.key}">
        <span class="nav-icon">${t.icon}</span>
        <span class="nav-label">${t.label}</span>
      </button>`).join('');

    nav.addEventListener('click', (e) => {
      const btn = e.target.closest('.nav-icon-btn');
      if (!btn) return;
      selectTab(btn.dataset.key);
    });
  }

  function onShow() {
    selectTab(activeTab || 'opening');
  }

  function selectTab(key) {
    activeTab = key;
    document.querySelectorAll('#operations-nav .nav-icon-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.key === key);
    });
    const tab = tabs.find(t => t.key === key);
    const content = document.getElementById('operations-content');
    content.innerHTML = '';
    tab.render(content);
  }

  return { init };
})();
