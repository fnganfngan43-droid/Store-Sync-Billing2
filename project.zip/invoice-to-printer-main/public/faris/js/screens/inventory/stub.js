/* =========================================================
   مستويات التسعير / تسعير الأصناف / الجرد / إقفال المخزون
   (هيكلية فقط - ستُستكمل حقولها في مرحلة قادمة)
   ========================================================= */

const InvStub = (function () {
  const TITLES = {
    pricingLevels: 'مستويات التسعير',
    itemPricing: 'تسعير الأصناف',
    stockCount: 'الجرد',
    closing: 'إقفال المخزون'
  };

  function render(container, key) {
    container.innerHTML = `
      <div class="toolbar icon-only">
        <button class="btn btn-icon" title="إضافة">➕</button>
        <button class="btn btn-icon" title="استيراد إكسل">📥</button>
        <button class="btn btn-icon" disabled title="تعديل">✏️</button>
        <button class="btn btn-icon" disabled title="حذف">🗑️</button>
      </div>
      <div class="toolbar search-row">
        <input type="text" placeholder="🔍 بحث..." disabled>
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>لا توجد بيانات بعد</th></tr></thead>
          <tbody><tr><td class="empty-row">شاشة "${TITLES[key]}" جاهزة هيكليًا، وستُستكمل حقولها في مرحلة قادمة.</td></tr></tbody>
        </table>
      </div>
    `;
  }

  return { render };
})();
