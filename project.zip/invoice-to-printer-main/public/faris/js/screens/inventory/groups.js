/* =========================================================
   المجموعات (رئيسية / فرعية / تفصيلية)
   ========================================================= */

const InvGroups = (function () {
  let selectedId = null;

  async function render(container) {
    selectedId = null;
    container.innerHTML = `
      <div class="toolbar">
        <button class="btn btn-icon" id="ig-add">➕ إضافة</button>
        <button class="btn btn-icon" id="ig-edit" disabled>✏️ تعديل</button>
        <button class="btn btn-icon" id="ig-del" disabled>🗑️ حذف</button>
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>المجموعة الرئيسية</th><th>المجموعة الفرعية</th><th>المجموعة التفصيلية</th></tr></thead>
          <tbody id="ig-rows"></tbody>
        </table>
      </div>

      <div class="bottom-sheet" id="ig-sheet">
        <div class="sheet-handle"></div>
        <h3>إضافة مجموعة</h3>
        <form id="ig-form">
          <div class="form-grid">
            <label class="required field-wide">المجموعة الرئيسية
              <span class="row-inline">
                <select id="ig-main" required></select>
                <button type="button" class="btn-plus" id="ig-open-main">➕</button>
              </span>
            </label>
            <label class="optional field-wide">المجموعة الفرعية
              <span class="row-inline">
                <select id="ig-sub"></select>
                <button type="button" class="btn-plus" id="ig-open-sub">➕</button>
              </span>
            </label>
            <label class="optional field-wide">المجموعة التفصيلية<input type="text" id="ig-detail"></label>
          </div>
          <div class="sheet-actions">
            <button type="button" class="btn btn-ghost" id="ig-cancel">إلغاء</button>
            <button type="submit" class="btn btn-primary">حفظ</button>
          </div>
        </form>
      </div>

      <div class="popup-sheet" id="main-popup">
        <div class="popup-header"><span>إضافة مجموعة رئيسية</span><button class="btn-close" id="main-popup-close">✖️</button></div>
        <form id="main-form">
          <label class="required">اسم المجموعة الرئيسية<input type="text" id="main-name" required></label>
          <button type="submit" class="btn btn-primary full">حفظ</button>
        </form>
      </div>

      <div class="popup-sheet" id="sub-popup">
        <div class="popup-header"><span>إضافة مجموعة فرعية</span><button class="btn-close" id="sub-popup-close">✖️</button></div>
        <form id="sub-form">
          <label class="required">المجموعة الرئيسية<select id="sub-main-select" required></select></label>
          <label class="required">اسم المجموعة الفرعية<input type="text" id="sub-name" required></label>
          <button type="submit" class="btn btn-primary full">حفظ</button>
        </form>
      </div>
    `;

    container.querySelector('#ig-add').addEventListener('click', () => openSheet(null));
    container.querySelector('#ig-edit').addEventListener('click', () => openSheet(selectedId));
    container.querySelector('#ig-del').addEventListener('click', onDelete);
    container.querySelector('#ig-cancel').addEventListener('click', () => Utils.closeSheet(document.getElementById('ig-sheet')));
    container.querySelector('#ig-form').addEventListener('submit', onSave);
    container.querySelector('#ig-main').addEventListener('change', onMainChange);

    container.querySelector('#ig-open-main').addEventListener('click', () => {
      document.getElementById('main-form').reset();
      Utils.openSheet(document.getElementById('main-popup'));
    });
    container.querySelector('#main-popup-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('main-popup')));
    container.querySelector('#main-form').addEventListener('submit', onSaveMain);

    container.querySelector('#ig-open-sub').addEventListener('click', async () => {
      document.getElementById('sub-form').reset();
      await fillMainSelect(document.getElementById('sub-main-select'), document.getElementById('ig-main').value);
      Utils.openSheet(document.getElementById('sub-popup'));
    });
    container.querySelector('#sub-popup-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('sub-popup')));
    container.querySelector('#sub-form').addEventListener('submit', onSaveSub);

    await fillMainSelect(document.getElementById('ig-main'));
    await loadRows();
  }

  async function fillMainSelect(select, selectedValue) {
    const mains = await FarisDB.getAll(STORES.INV_GROUPS_MAIN);
    select.innerHTML = mains.map(m => `<option value="${m.id}">${Utils.escapeHtml(m.name)}</option>`).join('');
    if (selectedValue) select.value = selectedValue;
  }

  async function fillSubSelect(select, mainId, selectedValue) {
    const subs = mainId ? await FarisDB.getAllByIndex(STORES.INV_GROUPS_SUB, 'mainGroupId', Number(mainId)) : [];
    select.innerHTML = '<option value="">—</option>' + subs.map(s => `<option value="${s.id}">${Utils.escapeHtml(s.name)}</option>`).join('');
    if (selectedValue) select.value = selectedValue;
  }

  async function onMainChange(e) {
    await fillSubSelect(document.getElementById('ig-sub'), e.target.value);
  }

  async function onSaveMain(e) {
    e.preventDefault();
    const name = document.getElementById('main-name').value.trim();
    if (!name) return;
    const existing = await FarisDB.getAll(STORES.INV_GROUPS_MAIN);
    if (existing.some(m => m.name === name)) {
      Utils.toast('اسم المجموعة الرئيسية موجود مسبقًا', 'error');
      return;
    }
    const id = await FarisDB.add(STORES.INV_GROUPS_MAIN, { name });
    Utils.closeSheet(document.getElementById('main-popup'));
    await fillMainSelect(document.getElementById('ig-main'), id);
    await fillSubSelect(document.getElementById('ig-sub'), id);
    Utils.toast('تمت إضافة المجموعة الرئيسية', 'success');
  }

  async function onSaveSub(e) {
    e.preventDefault();
    const mainGroupId = Number(document.getElementById('sub-main-select').value);
    const name = document.getElementById('sub-name').value.trim();
    if (!name || !mainGroupId) return;
    const existing = await FarisDB.getAllByIndex(STORES.INV_GROUPS_SUB, 'mainGroupId', mainGroupId);
    if (existing.some(s => s.name === name)) {
      Utils.toast('اسم المجموعة الفرعية موجود مسبقًا لهذه المجموعة الرئيسية', 'error');
      return;
    }
    const id = await FarisDB.add(STORES.INV_GROUPS_SUB, { name, mainGroupId });
    Utils.closeSheet(document.getElementById('sub-popup'));
    if (Number(document.getElementById('ig-main').value) === mainGroupId) {
      await fillSubSelect(document.getElementById('ig-sub'), mainGroupId, id);
    }
    Utils.toast('تمت إضافة المجموعة الفرعية', 'success');
  }

  async function loadRows() {
    const details = await FarisDB.getAll(STORES.INV_GROUPS_DETAIL);
    const subs = await FarisDB.getAll(STORES.INV_GROUPS_SUB);
    const mains = await FarisDB.getAll(STORES.INV_GROUPS_MAIN);
    const subMap = Object.fromEntries(subs.map(s => [s.id, s]));
    const mainMap = Object.fromEntries(mains.map(m => [m.id, m.name]));

    const rows = document.getElementById('ig-rows');
    rows.innerHTML = details.map(d => {
      const sub = subMap[d.subGroupId];
      return `<tr data-id="${d.id}">
        <td>${Utils.escapeHtml(sub ? mainMap[sub.mainGroupId] || '' : '')}</td>
        <td>${Utils.escapeHtml(sub ? sub.name : '')}</td>
        <td>${Utils.escapeHtml(d.name)}</td>
      </tr>`;
    }).join('') || '<tr><td colspan="3" class="empty-row">لا توجد مجموعات بعد</td></tr>';

    rows.querySelectorAll('tr[data-id]').forEach(tr => {
      tr.addEventListener('click', () => selectRow(Number(tr.dataset.id), tr));
    });
  }

  function selectRow(id, tr) {
    selectedId = id;
    document.querySelectorAll('#ig-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    document.getElementById('ig-edit').disabled = false;
    document.getElementById('ig-del').disabled = false;
  }

  async function openSheet(id) {
    const sheet = document.getElementById('ig-sheet');
    document.getElementById('ig-form').reset();
    await fillMainSelect(document.getElementById('ig-main'));

    if (id) {
      const detail = await FarisDB.get(STORES.INV_GROUPS_DETAIL, id);
      const sub = await FarisDB.get(STORES.INV_GROUPS_SUB, detail.subGroupId);
      await fillMainSelect(document.getElementById('ig-main'), sub ? sub.mainGroupId : '');
      await fillSubSelect(document.getElementById('ig-sub'), sub ? sub.mainGroupId : '', detail.subGroupId);
      document.getElementById('ig-detail').value = detail.name;
      sheet.dataset.editId = id;
    } else {
      await fillSubSelect(document.getElementById('ig-sub'), document.getElementById('ig-main').value);
      sheet.dataset.editId = '';
    }
    Utils.openSheet(sheet);
    Utils.bindKeyboardAwareScroll(sheet);
  }

  async function onSave(e) {
    e.preventDefault();
    const sheet = document.getElementById('ig-sheet');
    const editId = sheet.dataset.editId ? Number(sheet.dataset.editId) : null;
    const subGroupId = document.getElementById('ig-sub').value ? Number(document.getElementById('ig-sub').value) : null;
    const name = document.getElementById('ig-detail').value.trim();

    if (!subGroupId || !name) {
      Utils.toast('أكمل المجموعة الفرعية والمجموعة التفصيلية', 'error');
      return;
    }

    const value = { name, subGroupId };
    if (editId) value.id = editId;

    await FarisDB.put(STORES.INV_GROUPS_DETAIL, value);
    Utils.closeSheet(sheet);
    Utils.toast('تم الحفظ بنجاح', 'success');
    await loadRows();
  }

  async function onDelete() {
    if (!selectedId) return;
    const ok = await Utils.confirmDialog('هل تريد حذف هذه المجموعة؟');
    if (!ok) return;
    await FarisDB.remove(STORES.INV_GROUPS_DETAIL, selectedId);
    selectedId = null;
    document.getElementById('ig-edit').disabled = true;
    document.getElementById('ig-del').disabled = true;
    await loadRows();
    Utils.toast('تم الحذف', 'success');
  }

  return { render };
})();
