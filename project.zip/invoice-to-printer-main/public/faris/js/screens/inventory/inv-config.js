/* =========================================================
   تهيئة المخزون - إعدادات شاملة بعدة تبويبات
   ========================================================= */

const InvConfig = (function () {
  const SETTINGS_ID = 'main';

  const GL_FIELDS = [
    { key: 'defaultInventoryAccount', label: 'حساب المخزون الافتراضي' },
    { key: 'costOfSalesAccount', label: 'حساب تكلفة المبيعات' },
    { key: 'costOfSalesReturnAccount', label: 'حساب تكلفة مردود المبيعات' },
    { key: 'purchaseReturnAccount', label: 'حساب مردود المشتريات' },
    { key: 'stockShortageAccount', label: 'حساب عجز المخزون' },
    { key: 'stockSurplusAccount', label: 'حساب فائض المخزون' },
    { key: 'priceDifferenceAccount', label: 'حساب فروقات الأسعار' }
  ];

  const DEFAULTS = {
    valuation: 'المتوسط المرجح',
    allowNegative: false,
    enableBarcode: true,
    enableItemUnits: true,
    enableSerial: false,
    enableBatchExpiry: false,
    gl: {},
    costUpdateMode: 'عند كل عملية',
    requireWarehouse: false,
    printUnitCost: false,
    allowPriceEditAfterSave: false,
    allowTotalDiscountAfterItems: false,
    codingMethod: 'تلقائي',
    codeDigits: 8,
    requireGroupLink: true,
    enableItemImage: true,
    enableMinOrderAlert: false,
    countLockDate: '',
    allowPartialCount: false,
    printCountDiffByCost: false
  };

  let currentTab = 'general';
  let glDraft = {};

  async function render(container) {
    currentTab = 'general';
    const settings = await getSettings();
    glDraft = JSON.parse(JSON.stringify(settings.gl || {}));

    container.innerHTML = `
      <nav class="sub-nav" id="ic-tabs">
        ${tabButton('general', 'الإعدادات العامة')}
        ${tabButton('invoice', 'إعدادات الفواتير')}
        ${tabButton('items', 'إعدادات الأصناف')}
        ${tabButton('count', 'إعدادات الجرد')}
      </nav>
      <div id="ic-tab-content"></div>
      <div class="toolbar" style="margin-top:14px;">
        <button class="btn btn-primary" id="ic-save">💾 حفظ</button>
        <button class="btn btn-secondary" id="ic-defaults">↺ افتراضي</button>
        <button class="btn btn-ghost" id="ic-exit">🚪 خروج</button>
      </div>
    `;

    container.querySelector('#ic-tabs').addEventListener('click', (e) => {
      const btn = e.target.closest('.nav-icon-btn');
      if (!btn) return;
      currentTab = btn.dataset.key;
      renderTab(settings);
    });
    container.querySelector('#ic-save').addEventListener('click', onSave);
    container.querySelector('#ic-defaults').addEventListener('click', () => applyDefaultsToForm(settings));
    container.querySelector('#ic-exit').addEventListener('click', () => App.show('home', { replace: true }));

    renderTab(settings);
  }

  function tabButton(key, label) {
    return `<button class="nav-icon-btn ${key === 'general' ? 'active' : ''}" data-key="${key}"><span class="nav-label">${label}</span></button>`;
  }

  function selectTabButton(key) {
    document.querySelectorAll('#ic-tabs .nav-icon-btn').forEach(b => b.classList.toggle('active', b.dataset.key === key));
  }

  async function renderTab(settings) {
    selectTabButton(currentTab);
    const el = document.getElementById('ic-tab-content');
    if (currentTab === 'general') el.innerHTML = generalTabHtml(settings);
    else if (currentTab === 'gl') { el.innerHTML = glTabHtml(); await bindGlTab(); }
    else if (currentTab === 'invoice') el.innerHTML = invoiceTabHtml(settings);
    else if (currentTab === 'items') el.innerHTML = itemsTabHtml(settings);
    else if (currentTab === 'count') el.innerHTML = countTabHtml(settings);
    Utils.applyInlineLabels(el);
  }

  function generalTabHtml(s) {
    return `
      <div class="form-grid">
        <label class="required field-wide">طريقة تسعير المخزون
          <select id="ic-valuation">
            <option value="المتوسط المرجح">المتوسط المرجح</option>
            <option value="FIFO">الوارد أولاً يصرف أولاً (FIFO)</option>
            <option value="LIFO">الوارد أخيرًا يصرف أولاً (LIFO)</option>
          </select>
        </label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="ic-allow-negative" ${s.allowNegative ? 'checked' : ''}> السماح بالرصيد السالب (يسمح بالبيع والرصيد بالسالب)</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="ic-barcode" ${s.enableBarcode ? 'checked' : ''}> تفعيل الباركود</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="ic-units" ${s.enableItemUnits ? 'checked' : ''}> تفعيل وحدات الصنف (كرتون - حبة - متر)</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="ic-serial" ${s.enableSerial ? 'checked' : ''}> تفعيل الرقم التسلسلي</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="ic-batch" ${s.enableBatchExpiry ? 'checked' : ''}> تفعيل الدفعات وتاريخ الصلاحية</label>
      </div>
    `;
  }

  function glTabHtml() {
    return `
      <p class="hint">كل الحسابات تُسحب من شجرة الدليل المحاسبي (الحسابات الفرعية).</p>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>الحدث</th><th>رقم الحساب</th><th>اسم الحساب</th><th>إجباري</th></tr></thead>
          <tbody id="ic-gl-rows"></tbody>
        </table>
      </div>
    `;
  }

  async function bindGlTab() {
    const allAccounts = (await FarisDB.getAll(STORES.ACCOUNTS)).filter(a => a.type === 'فرعي');
    const source = allAccounts.map(a => ({ value: a.code, label: `${a.code} - ${a.name}`, name: a.name }));
    const tbody = document.getElementById('ic-gl-rows');

    tbody.innerHTML = GL_FIELDS.map(f => `
      <tr data-key="${f.key}">
        <td>${Utils.escapeHtml(f.label)}</td>
        <td>
          <div class="combo-wrap combo-compact">
            <input type="text" class="table-input ic-gl-input" autocomplete="off">
            <div class="autocomplete-list ic-gl-list"></div>
          </div>
        </td>
        <td class="ic-gl-name"></td>
        <td><span class="tag tag-sub">مطلوب</span></td>
      </tr>
    `).join('');

    tbody.querySelectorAll('tr[data-key]').forEach(tr => {
      const key = tr.dataset.key;
      const input = tr.querySelector('.ic-gl-input');
      const list = tr.querySelector('.ic-gl-list');
      const nameCell = tr.querySelector('.ic-gl-name');

      Utils.attachAutocomplete(input, list, (query) => query ? source.filter(it => it.label.includes(query)) : source, (item) => {
        input.value = item.value;
        nameCell.textContent = item.name;
        glDraft[key] = { code: item.value, name: item.name };
      });

      const saved = glDraft[key];
      if (saved && saved.code) {
        input.value = saved.code;
        nameCell.textContent = saved.name;
      }
    });
  }

  function invoiceTabHtml(s) {
    return `
      <div class="form-grid">
        <label class="required field-wide">تحديث تكلفة الصنف
          <select id="ic-cost-update">
            <option value="عند كل عملية">عند كل عملية</option>
            <option value="دوريًا">دوريًا</option>
            <option value="يدويًا">يدويًا</option>
          </select>
        </label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="ic-require-wh" ${s.requireWarehouse ? 'checked' : ''}> إجباري اختيار المخزن</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="ic-print-unit-cost" ${s.printUnitCost ? 'checked' : ''}> طباعة تكلفة الوحدة في الفاتورة</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="ic-edit-price-after" ${s.allowPriceEditAfterSave ? 'checked' : ''}> السماح بتعديل السعر بعد الحفظ</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="ic-total-discount" ${s.allowTotalDiscountAfterItems ? 'checked' : ''}> السماح بخصم إجمالي بعد الأصناف</label>
      </div>
    `;
  }

  function itemsTabHtml(s) {
    return `
      <div class="form-grid">
        <label class="required field-wide">طريقة ترميز الأصناف
          <select id="ic-coding-method"><option value="تلقائي">تلقائي</option><option value="يدوي">يدوي</option></select>
        </label>
        <label class="required">عدد خانات كود الصنف<input type="number" id="ic-code-digits" value="${s.codeDigits}" min="1" max="20"></label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="ic-require-group" ${s.requireGroupLink ? 'checked' : ''}> إجباري ربط المجموعة للصنف</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="ic-item-image" ${s.enableItemImage ? 'checked' : ''}> تفعيل صورة الصنف</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="ic-min-order-alert" ${s.enableMinOrderAlert ? 'checked' : ''}> تفعيل تنبيه حد الطلب الأدنى</label>
      </div>
    `;
  }

  function countTabHtml(s) {
    return `
      <div class="form-grid">
        <label class="optional field-wide">قفل المخزون بعد تاريخ الجرد<input type="date" id="ic-count-lock-date" value="${s.countLockDate || ''}"></label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="ic-partial-count" ${s.allowPartialCount ? 'checked' : ''}> السماح بالجرد الجزئي</label>
        <label class="checkbox-row field-wide"><input type="checkbox" id="ic-print-diff-cost" ${s.printCountDiffByCost ? 'checked' : ''}> طباعة فرق الجرد بالتكلفة</label>
      </div>
    `;
  }

  function readFormIntoSettings() {
    const s = { id: SETTINGS_ID, gl: glDraft };
    const byId = (id) => document.getElementById(id);

    if (byId('ic-valuation')) {
      s.valuation = byId('ic-valuation').value;
      s.allowNegative = byId('ic-allow-negative').checked;
      s.enableBarcode = byId('ic-barcode').checked;
      s.enableItemUnits = byId('ic-units').checked;
      s.enableSerial = byId('ic-serial').checked;
      s.enableBatchExpiry = byId('ic-batch').checked;
    }
    if (byId('ic-cost-update')) {
      s.costUpdateMode = byId('ic-cost-update').value;
      s.requireWarehouse = byId('ic-require-wh').checked;
      s.printUnitCost = byId('ic-print-unit-cost').checked;
      s.allowPriceEditAfterSave = byId('ic-edit-price-after').checked;
      s.allowTotalDiscountAfterItems = byId('ic-total-discount').checked;
    }
    if (byId('ic-coding-method')) {
      s.codingMethod = byId('ic-coding-method').value;
      s.codeDigits = Number(byId('ic-code-digits').value) || 8;
      s.requireGroupLink = byId('ic-require-group').checked;
      s.enableItemImage = byId('ic-item-image').checked;
      s.enableMinOrderAlert = byId('ic-min-order-alert').checked;
    }
    if (byId('ic-count-lock-date')) {
      s.countLockDate = byId('ic-count-lock-date').value;
      s.allowPartialCount = byId('ic-partial-count').checked;
      s.printCountDiffByCost = byId('ic-print-diff-cost').checked;
    }
    return s;
  }

  async function onSave() {
    const current = await getSettings();
    const partial = readFormIntoSettings();
    const merged = { ...current, ...partial, id: SETTINGS_ID, gl: glDraft };
    await FarisDB.put(STORES.INV_SETTINGS, merged);
    Utils.toast('تم حفظ إعدادات المخزون', 'success');
  }

  async function applyDefaultsToForm() {
    const ok = await Utils.confirmDialog('سيتم إرجاع كل حقول هذا التبويب للقيم الافتراضية (دون حفظ فوري). هل تريد المتابعة؟');
    if (!ok) return;
    glDraft = {};
    renderTab(DEFAULTS);
    Utils.toast('أُعيدت القيم الافتراضية، اضغط "حفظ" لتثبيتها', 'info');
  }

  async function getSettings() {
    const saved = await FarisDB.get(STORES.INV_SETTINGS, SETTINGS_ID);
    return { ...DEFAULTS, ...(saved || {}) };
  }

  return { render, getSettings };
})();
