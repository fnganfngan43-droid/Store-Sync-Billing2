/* =========================================================
   بيانات المخزون (المخازن)
   ========================================================= */

const InvWarehouses = (function () {
  let selectedId = null;

  async function render(container) {
    selectedId = null;
    container.innerHTML = `
      <div class="toolbar">
        <button class="btn btn-icon" id="iw-add">➕ إضافة</button>
        <button class="btn btn-icon" id="iw-edit" disabled>✏️ تعديل</button>
        <button class="btn btn-icon" id="iw-del" disabled>🗑️ حذف</button>
      </div>
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr><th>رقم المخزن</th><th>مجموعة المخازن</th><th>اسم المخزن</th><th>الرمز</th><th>العملة</th><th>أمين المخزن</th></tr></thead>
          <tbody id="iw-rows"></tbody>
        </table>
      </div>

      <div class="bottom-sheet" id="iw-sheet">
        <div class="sheet-handle"></div>
        <h3>بيانات المخزن</h3>
        <form id="iw-form">
          <div class="form-grid">
            <label class="optional">رقم المخزون<input type="text" id="iw-number" readonly></label>
            <label class="required with-add-btn">مجموعة المخازن
              <span class="row-inline">
                <select id="iw-group" required></select>
                <button type="button" class="btn-plus" id="iw-open-group">➕</button>
              </span>
            </label>
            <label class="required">اسم المخزن<input type="text" id="iw-name" required></label>
            <label class="optional">رمز المخزن<input type="text" id="iw-code"></label>
            <label class="required">عملة المخزن<select id="iw-currency" required></select></label>
            <label class="optional">اسم أمين المخازن<input type="text" id="iw-keeper-name"></label>
            <label class="optional">رقم أمين المخازن<input type="text" id="iw-keeper-number"></label>
            <label class="optional field-wide">حقل إضافي (يظهر كتذييل عند طباعة الفاتورة)<input type="text" id="iw-extra"></label>
          </div>
          <div class="sheet-actions">
            <button type="button" class="btn btn-ghost" id="iw-cancel">إلغاء</button>
            <button type="submit" class="btn btn-primary">حفظ</button>
          </div>
        </form>
      </div>

      <div class="popup-sheet" id="iw-group-popup">
        <div class="popup-header"><span>إضافة مجموعة مخازن</span><button class="btn-close" id="iw-group-popup-close">✖️</button></div>
        <form id="iw-group-form">
          <label class="optional">رقم المجموعة<input type="text" id="iwg-number" readonly></label>
          <label class="required">اسم مجموعة المخازن<input type="text" id="iwg-name" required></label>
          <label class="required">نوع المخزون<select id="iwg-type"><option value="رئيسي">رئيسي</option><option value="فرعي">فرعي</option></select></label>
          <label class="optional">الفرع<input type="text" id="iwg-branch"></label>
          <button type="submit" class="btn btn-primary full">حفظ</button>
        </form>
      </div>
    `;

    const currencies = await FarisDB.getAll(STORES.CURRENCIES);
    document.getElementById('iw-currency').innerHTML = currencies.map(c => `<option value="${c.id}">(${Utils.escapeHtml(c.symbol)}) ${Utils.escapeHtml(c.name)}</option>`).join('');
    await fillGroupSelect(document.getElementById('iw-group'));

    container.querySelector('#iw-add').addEventListener('click', () => openSheet(null));
    container.querySelector('#iw-edit').addEventListener('click', () => openSheet(selectedId));
    container.querySelector('#iw-del').addEventListener('click', onDelete);
    container.querySelector('#iw-cancel').addEventListener('click', () => Utils.closeSheet(document.getElementById('iw-sheet')));

    container.querySelector('#iw-open-group').addEventListener('click', async () => {
      document.getElementById('iw-group-form').reset();
      document.getElementById('iwg-number').value = await nextGroupNumber();
      Utils.openSheet(document.getElementById('iw-group-popup'));
    });
    container.querySelector('#iw-group-popup-close').addEventListener('click', () => Utils.closeSheet(document.getElementById('iw-group-popup')));
    container.querySelector('#iw-group-form').addEventListener('submit', onSaveGroup);
    container.querySelector('#iw-form').addEventListener('submit', onSave);

    await loadRows();
  }

  async function fillGroupSelect(select, selectedValue) {
    const groups = await FarisDB.getAll(STORES.INV_WAREHOUSE_GROUPS);
    select.innerHTML = groups.map(g => `<option value="${g.id}">${g.id} - ${Utils.escapeHtml(g.name)}</option>`).join('');
    if (selectedValue) select.value = selectedValue;
  }

  async function nextGroupNumber() {
    const groups = await FarisDB.getAll(STORES.INV_WAREHOUSE_GROUPS);
    return groups.length ? Math.max(...groups.map(g => g.id)) + 1 : 1;
  }

  async function onSaveGroup(e) {
    e.preventDefault();
    const name = document.getElementById('iwg-name').value.trim();
    if (!name) return;
    const existing = await FarisDB.getAll(STORES.INV_WAREHOUSE_GROUPS);
    if (existing.some(g => g.name === name)) {
      Utils.toast('اسم مجموعة المخازن موجود مسبقًا', 'error');
      return;
    }
    const id = await FarisDB.add(STORES.INV_WAREHOUSE_GROUPS, {
      name, type: document.getElementById('iwg-type').value, branch: document.getElementById('iwg-branch').value.trim()
    });
    Utils.closeSheet(document.getElementById('iw-group-popup'));
    await fillGroupSelect(document.getElementById('iw-group'), id);
    Utils.toast('تمت إضافة مجموعة المخازن', 'success');
  }

  async function loadRows() {
    const items = await FarisDB.getAll(STORES.INV_WAREHOUSES);
    const currencies = await FarisDB.getAll(STORES.CURRENCIES);
    const groups = await FarisDB.getAll(STORES.INV_WAREHOUSE_GROUPS);
    const curMap = Object.fromEntries(currencies.map(c => [c.id, c.symbol]));
    const groupMap = Object.fromEntries(groups.map(g => [g.id, g.name]));

    const rows = document.getElementById('iw-rows');
    rows.innerHTML = items.map(w => `
      <tr data-id="${w.id}">
        <td>${w.id}</td><td>${Utils.escapeHtml(groupMap[w.groupId] || '')}</td><td>${Utils.escapeHtml(w.name)}</td><td>${Utils.escapeHtml(w.code || '')}</td>
        <td>${Utils.escapeHtml(curMap[w.currencyId] || '')}</td><td>${Utils.escapeHtml(w.keeperName || '')}</td>
      </tr>`).join('') || '<tr><td colspan="6" class="empty-row">لا توجد مخازن بعد</td></tr>';

    rows.querySelectorAll('tr[data-id]').forEach(tr => {
      tr.addEventListener('click', () => selectRow(Number(tr.dataset.id), tr));
    });
  }

  function selectRow(id, tr) {
    selectedId = id;
    document.querySelectorAll('#iw-rows tr').forEach(r => r.classList.remove('selected'));
    tr.classList.add('selected');
    document.getElementById('iw-edit').disabled = false;
    document.getElementById('iw-del').disabled = false;
  }

  async function openSheet(id) {
    const sheet = document.getElementById('iw-sheet');
    document.getElementById('iw-form').reset();

    if (id) {
      const w = await FarisDB.get(STORES.INV_WAREHOUSES, id);
      document.getElementById('iw-number').value = w.id;
      await fillGroupSelect(document.getElementById('iw-group'), w.groupId);
      document.getElementById('iw-name').value = w.name;
      document.getElementById('iw-code').value = w.code || '';
      document.getElementById('iw-currency').value = w.currencyId;
      document.getElementById('iw-keeper-name').value = w.keeperName || '';
      document.getElementById('iw-keeper-number').value = w.keeperNumber || '';
      document.getElementById('iw-extra').value = w.extraField || '';
      sheet.dataset.editId = id;
    } else {
      const all = await FarisDB.getAll(STORES.INV_WAREHOUSES);
      const nextNum = all.length ? Math.max(...all.map(w => w.id)) + 1 : 1;
      document.getElementById('iw-number').value = nextNum;
      sheet.dataset.editId = '';
    }
    Utils.openSheet(sheet);
    Utils.bindKeyboardAwareScroll(sheet);
  }

  async function onSave(e) {
    e.preventDefault();
    const sheet = document.getElementById('iw-sheet');
    const editId = sheet.dataset.editId ? Number(sheet.dataset.editId) : null;

    const value = {
      groupId: Number(document.getElementById('iw-group').value),
      name: document.getElementById('iw-name').value.trim(),
      code: document.getElementById('iw-code').value.trim(),
      currencyId: Number(document.getElementById('iw-currency').value),
      keeperName: document.getElementById('iw-keeper-name').value.trim(),
      keeperNumber: document.getElementById('iw-keeper-number').value.trim(),
      extraField: document.getElementById('iw-extra').value.trim()
    };
    if (editId) value.id = editId;

    const existing = await FarisDB.getAll(STORES.INV_WAREHOUSES);
    if (existing.some(w => w.name === value.name && w.id !== editId)) {
      Utils.toast('اسم المخزن موجود مسبقًا', 'error');
      return;
    }

    await FarisDB.put(STORES.INV_WAREHOUSES, value);
    Utils.closeSheet(sheet);
    Utils.toast('تم الحفظ بنجاح', 'success');
    await loadRows();
  }

  async function onDelete() {
    if (!selectedId) return;
    const stock = await FarisDB.getAll(STORES.INV_OPENING_STOCK);
    if (stock.some(s => s.warehouseId === selectedId)) {
      Utils.toast('لا يمكن حذف هذا المخزن، توجد أرصدة مسجَّلة فيه', 'error');
      return;
    }
    const ok = await Utils.confirmDialog('هل تريد حذف هذا المخزن؟');
    if (!ok) return;
    await FarisDB.remove(STORES.INV_WAREHOUSES, selectedId);
    selectedId = null;
    document.getElementById('iw-edit').disabled = true;
    document.getElementById('iw-del').disabled = true;
    await loadRows();
    Utils.toast('تم الحذف', 'success');
  }

  return { render };
})();
