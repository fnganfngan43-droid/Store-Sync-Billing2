/* =========================================================
   بطاقة حركة الصنف
   المرجع الموحّد لحركة أي صنف: يجمع كل الحركات الفعلية
   (رصيد افتتاحي + فواتير مبيعات + مرتجع مبيعات) عبر
   ItemMovementEngine، بثلاثة أوضاع عرض: تفصيلية/إجمالية/تحليلية.
   ========================================================= */

const InvItemCard = (function () {
  let itemsCache = [];
  let mainGroupsCache = [];
  let subGroupsCache = [];
  let detailGroupsCache = [];
  let warehousesCache = [];
  let unitsFlat = [];
  let lastResult = null;
  let selectedItem = null;

  async function render(container, params) {
    params = params || {};
    itemsCache = await FarisDB.getAll(STORES.INV_ITEMS);
    mainGroupsCache = await FarisDB.getAll(STORES.INV_GROUPS_MAIN);
    subGroupsCache = await FarisDB.getAll(STORES.INV_GROUPS_SUB);
    detailGroupsCache = await FarisDB.getAll(STORES.INV_GROUPS_DETAIL);
    warehousesCache = await FarisDB.getAll(STORES.INV_WAREHOUSES);
    unitsFlat = await FarisDB.getAll(STORES.INV_UNITS);
    lastResult = null;
    selectedItem = null;

    container.innerHTML = `
      <div class="form-grid">
        <label class="optional">من تاريخ<input type="date" id="ic-from"></label>
        <label class="optional">إلى تاريخ<input type="date" id="ic-to"></label>

        <label class="required field-wide">الصنف
          <div class="combo-wrap">
            <input type="text" id="ic-item-input" autocomplete="off" placeholder="ابحث برقم أو اسم الصنف">
            <div class="autocomplete-list" id="ic-item-list"></div>
          </div>
        </label>
        <input type="hidden" id="ic-item-code">

        <label class="optional">المجموعة الرئيسية<input type="text" id="ic-main-group" readonly></label>
        <label class="optional">المجموعة الفرعية<input type="text" id="ic-sub-group" readonly></label>
        <label class="optional">المجموعة التفصيلية<input type="text" id="ic-detail-group" readonly></label>

        <label class="optional"><select id="ic-warehouse"><option value="">كل المخازن</option></select></label>
        <label class="optional"><select id="ic-unit"><option value="">كل الوحدات</option></select></label>

        <label class="required">نوع العرض
          <select id="ic-view-type">
            <option value="تفصيلية">بطاقة صنف تفصيلية</option>
            <option value="إجمالية">حركة إجمالية</option>
            <option value="تحليلية">حركة تحليلية</option>
          </select>
        </label>
      </div>

      <div class="toolbar icon-only">
        <button class="btn btn-icon" id="ic-view" title="عرض">👁️</button>
        ${ReportPrint.toolbarHtml('ic')}
        <button class="btn btn-icon" id="ic-back" title="رجوع">↩️</button>
      </div>

      <div id="ic-gl-info" class="hint"></div>
      <div id="ic-result"></div>
    `;

    document.getElementById('ic-warehouse').innerHTML += warehousesCache.map(w => `<option value="${w.id}">${Utils.escapeHtml(w.name)}</option>`).join('');

    const itemInput = document.getElementById('ic-item-input');
    const itemList = document.getElementById('ic-item-list');
    Utils.attachAutocomplete(itemInput, itemList, (query) => {
      const list = itemsCache.map(it => ({ value: it.code, label: `${it.code} - ${it.name}`, displayValue: `${it.code} - ${it.name}` }));
      return query ? list.filter(it => it.label.includes(query)) : list;
    }, (item) => {
      itemInput.value = item.displayValue;
      onItemChosen(item.value);
    });

    document.getElementById('ic-view').addEventListener('click', onView);
    document.getElementById('ic-back').addEventListener('click', () => ScreenInventory.backFromItemCard());
    ReportPrint.bindToolbar('ic', async () => lastResult);

    if (params.itemCode) {
      const item = itemsCache.find(i => i.code === params.itemCode);
      if (item) {
        itemInput.value = `${item.code} - ${item.name}`;
        onItemChosen(item.code);
        if (params.warehouseId) document.getElementById('ic-warehouse').value = params.warehouseId;
        await onView();
      }
    }
  }

  function onItemChosen(code) {
    const item = itemsCache.find(i => i.code === code);
    selectedItem = item || null;
    document.getElementById('ic-item-code').value = code;

    const mainName = item ? (mainGroupsCache.find(m => m.id === item.mainGroupId) || {}).name : '';
    const subName = item ? (subGroupsCache.find(s => s.id === item.subGroupId) || {}).name : '';
    const detailName = item ? (detailGroupsCache.find(d => d.id === item.detailGroupId) || {}).name : '';
    document.getElementById('ic-main-group').value = mainName || '';
    document.getElementById('ic-sub-group').value = subName || '';
    document.getElementById('ic-detail-group').value = detailName || '';

    const unitSelect = document.getElementById('ic-unit');
    unitSelect.innerHTML = '<option value="">كل الوحدات</option>' + (item ? item.units : []).map(u => {
      const unit = unitsFlat.find(x => x.id === u.unitId);
      return `<option value="${u.unitId}">${unit ? Utils.escapeHtml(unit.name) : ''}</option>`;
    }).join('');
  }

  function unitName(id) { const u = unitsFlat.find(x => x.id === id); return u ? u.name : ''; }
  function warehouseName(id) { const w = warehousesCache.find(x => x.id === id); return w ? w.name : ''; }

  async function showGlInfo(warehouseId) {
    const box = document.getElementById('ic-gl-info');
    if (!warehouseId) { box.innerHTML = ''; return; }
    const mapping = await ItemMovementEngine.getGlLinks(Number(warehouseId));
    if (!mapping) { box.innerHTML = 'لا توجد حسابات مربوطة لمجموعة مخازن هذا المخزن في "ربط المخزون بالأستاذ العام".'; return; }
    const fields = [
      ['حساب المخزون', mapping.inventoryAccount], ['حساب الرصيد الافتتاحي', mapping.openingStockAccount],
      ['حساب المبيعات', mapping.salesAccount], ['حساب تكلفة المبيعات', mapping.costOfSalesAccount],
      ['حساب مردود المبيعات', mapping.salesReturnAccount], ['حساب تكلفة مردود المبيعات', mapping.costOfSalesReturnAccount]
    ];
    box.innerHTML = `<b>الأثر المحاسبي (للعرض فقط):</b> ` + fields.map(([label, acc]) => `${label}: ${acc ? Utils.escapeHtml(acc.code + ' - ' + acc.name) : '—'}`).join(' | ');
  }

  async function onView() {
    const itemCode = document.getElementById('ic-item-code').value;
    if (!itemCode) { Utils.toast('اختر الصنف أولًا', 'error'); return; }

    const fromDate = document.getElementById('ic-from').value || null;
    const toDate = document.getElementById('ic-to').value || null;
    const warehouseId = document.getElementById('ic-warehouse').value ? Number(document.getElementById('ic-warehouse').value) : null;
    const unitId = document.getElementById('ic-unit').value ? Number(document.getElementById('ic-unit').value) : null;
    const viewType = document.getElementById('ic-view-type').value;

    await showGlInfo(warehouseId);

    const { rows, carriedForward } = await ItemMovementEngine.getItemCard({ itemCode, warehouseId, unitId, fromDate, toDate });
    const item = selectedItem;
    const subtitle = `الصنف: ${itemCode} - ${item ? item.name : ''}${warehouseId ? ' — المخزن: ' + warehouseName(warehouseId) : ''}`;
    const resultEl = document.getElementById('ic-result');

    if (viewType === 'تفصيلية') {
      const headers = ['التاريخ', 'نوع الحركة', 'رقم المستند', 'رقم الصنف', 'اسم الصنف', 'المخزن', 'الوحدة', 'الكمية الواردة', 'الكمية المنصرفة', 'الرصيد', 'تكلفة الوحدة', 'إجمالي التكلفة', 'سعر البيع', 'إجمالي البيع', 'رقم المرجع', 'البيان'];
      const dataRows = [];
      if (fromDate && carriedForward) {
        dataRows.push(['—', 'رصيد مرحّل', '—', itemCode, item ? item.name : '', warehouseId ? warehouseName(warehouseId) : '', '', '', '', carriedForward, '', '', '', '', '', 'رصيد ما قبل الفترة']);
      }
      rows.forEach(r => {
        dataRows.push([
          r.date || '—', r.type, r.docNo, r.itemCode, r.itemName || (item ? item.name : ''), warehouseName(r.warehouseId), unitName(r.unitId),
          r.incomingQty || '', r.outgoingQty || '', r.balance,
          r.unitCost ? r.unitCost.toFixed(2) : '', r.unitCost ? ((r.incomingQty || r.outgoingQty) * r.unitCost).toFixed(2) : '',
          r.salePrice ? r.salePrice.toFixed(2) : '', r.salePrice ? (r.outgoingQty * r.salePrice).toFixed(2) : '',
          r.reference || '', r.statement || ''
        ]);
      });
      const totals = ItemMovementEngine.aggregateTotal(rows);
      const footerRow = ['', '', '', '', '', '', 'الإجماليات', totals.incomingQty, totals.outgoingQty, totals.balance, totals.avgCost.toFixed(2), totals.totalValue.toFixed(2), '', totals.totalSale.toFixed(2), '', ''];

      lastResult = { title: 'بطاقة حركة الصنف', fromDate, toDate, subtitle, headers, rows: dataRows, footerRow };
      resultEl.innerHTML = renderTable(headers, dataRows, footerRow);
    } else if (viewType === 'إجمالية') {
      const totals = ItemMovementEngine.aggregateTotal(rows);
      const headers = ['رقم الصنف', 'اسم الصنف', 'إجمالي الوارد', 'إجمالي المنصرف', 'الرصيد', 'متوسط التكلفة', 'إجمالي القيمة', 'إجمالي المبيعات'];
      const dataRows = [[itemCode, item ? item.name : '', totals.incomingQty, totals.outgoingQty, totals.balance, totals.avgCost.toFixed(2), totals.totalValue.toFixed(2), totals.totalSale.toFixed(2)]];
      lastResult = { title: 'حركة إجمالية للصنف', fromDate, toDate, subtitle, headers, rows: dataRows };
      resultEl.innerHTML = renderTable(headers, dataRows, null);
    } else {
      const groups = ItemMovementEngine.aggregateByAnalytic(rows);
      const headers = ['الجهة التحليلية', 'إجمالي الوارد', 'إجمالي المنصرف', 'الرصيد', 'متوسط التكلفة', 'إجمالي القيمة'];
      const dataRows = groups.map(g => [g.label, g.totals.incomingQty, g.totals.outgoingQty, g.totals.balance, g.totals.avgCost.toFixed(2), g.totals.totalValue.toFixed(2)]);
      lastResult = { title: 'حركة تحليلية للصنف', fromDate, toDate, subtitle, headers, rows: dataRows };
      resultEl.innerHTML = renderTable(headers, dataRows, null);
    }
  }

  function renderTable(headers, rows, footerRow) {
    const head = `<tr>${headers.map(h => `<th>${Utils.escapeHtml(h)}</th>`).join('')}</tr>`;
    const body = rows.map(r => `<tr>${r.map(c => `<td>${Utils.escapeHtml(c)}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${headers.length}" class="empty-row">لا توجد حركة ضمن هذه الفلاتر</td></tr>`;
    const foot = footerRow ? `<tfoot><tr>${footerRow.map(c => `<td><b>${Utils.escapeHtml(c)}</b></td>`).join('')}</tr></tfoot>` : '';
    return `<div class="table-scroll" style="overflow-x:auto;"><table class="data-table" style="table-layout:auto; width:auto; min-width:100%;"><thead>${head}</thead><tbody>${body}</tbody>${foot}</table></div>`;
  }

  return { render };
})();
