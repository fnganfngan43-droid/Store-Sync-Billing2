/* =========================================================
   نافذة "الكميات حسب المخزن" - تعرض رصيد الصنف المتاح في كل مخزن
   (بأصغر وحدة) لمراجعة الأرصدة قبل الإضافة إلى الفاتورة
   ========================================================= */

const WarehouseStockPopup = (function () {
  function ensureEl() {
    let el = document.getElementById('wh-stock-popup');
    if (el) return el;
    el = Utils.el(`
      <div class="popup-sheet" id="wh-stock-popup">
        <div class="popup-header"><span>الكميات حسب المخزن</span><button class="btn-close" id="wh-stock-close">✖️</button></div>
        <div id="wh-stock-content"></div>
      </div>`);
    document.body.appendChild(el);
    el.querySelector('#wh-stock-close').addEventListener('click', () => Utils.closeSheet(el));
    return el;
  }

  async function open(itemCode, itemName) {
    const el = ensureEl();
    const content = el.querySelector('#wh-stock-content');
    content.innerHTML = '<p>جارٍ الحساب...</p>';
    Utils.openSheet(el);

    const [warehouses, items, units, movements] = await Promise.all([
      FarisDB.getAll(STORES.INV_WAREHOUSES),
      FarisDB.getAll(STORES.INV_ITEMS),
      FarisDB.getAll(STORES.INV_UNITS),
      ItemMovementEngine.gatherRawMovements(itemCode)
    ]);
    const item = items.find(i => i.code === itemCode);
    const baseUnit = item && item.units ? (item.units.find(u => u.isBase) || item.units[0]) : null;
    const unitName = baseUnit ? ((units.find(u => u.id === baseUnit.unitId) || {}).name || '') : '';

    const bal = {};
    movements.forEach(m => {
      const id = m.warehouseId;
      if (!id) return;
      bal[id] = (bal[id] || 0) + (Number(m.incomingBaseQty) || 0) - (Number(m.outgoingBaseQty) || 0);
    });

    let total = 0;
    const rows = warehouses.map(w => {
      const q = Math.round((bal[w.id] || 0) * 1000) / 1000;
      total += q;
      return `<tr><td>${Utils.escapeHtml(w.code || '')}</td><td>${Utils.escapeHtml(w.name)}</td><td>${q}</td></tr>`;
    }).join('') || '<tr><td colspan="3" class="empty-row">لا توجد مخازن</td></tr>';

    content.innerHTML = `
      <p><b>الصنف:</b> ${Utils.escapeHtml(itemCode + ' - ' + (itemName || ''))}${unitName ? ` &nbsp; <b>الوحدة:</b> ${Utils.escapeHtml(unitName)}` : ''}</p>
      <table class="data-table"><thead><tr><th>رمز المخزن</th><th>المخزن</th><th>الكمية المتاحة</th></tr></thead>
      <tbody>${rows}<tr><td colspan="2"><b>الإجمالي</b></td><td><b>${Math.round(total * 1000) / 1000}</b></td></tr></tbody></table>`;
  }

  return { open };
})();
