/* =========================================================
   تقرير الدليل المحاسبي
   ========================================================= */

const ReportChartReport = (function () {
  let lastResult = null;

  async function render(container) {
    lastResult = null;
    container.innerHTML = `
      <div class="toolbar">
        <button class="btn btn-primary" id="cha-view">🔍 عرض</button>
        ${ReportPrint.toolbarHtml('cha')}
      </div>
      <div id="cha-result"></div>
    `;
    container.querySelector('#cha-view').addEventListener('click', onView);
    ReportPrint.bindToolbar('cha', async () => lastResult);
    onView();
  }

  async function onView() {
    const accounts = await ReportData.getAllAccountsFlat();
    const headers = ['رقم الحساب', 'اسم الحساب', 'الرتبة', 'النوع', 'الطبيعة', 'نوع التقرير', 'النوع التحليلي'];
    const rows = accounts.map(a => [a.code, a.name, a.rank, a.type, a.nature, a.reportType || '', a.analyticType || '']);
    lastResult = { title: 'تقرير الدليل المحاسبي', headers, rows };

    document.getElementById('cha-result').innerHTML = `
      <div class="table-scroll">
        <table class="data-table">
          <thead><tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr></thead>
          <tbody>${rows.map(r => `<tr>${r.map(c => `<td>${Utils.escapeHtml(c)}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="7" class="empty-row">لا توجد حسابات</td></tr>`}</tbody>
        </table>
      </div>
    `;
  }

  return { render };
})();
