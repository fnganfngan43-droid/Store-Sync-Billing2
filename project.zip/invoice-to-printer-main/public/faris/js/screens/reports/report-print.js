/* =========================================================
   أدوات الطباعة والتصدير المشتركة لكل شاشات التقارير
   ========================================================= */

const ReportPrint = (function () {

  function toolbarHtml(idPrefix) {
    return `
      <button class="btn btn-icon" id="${idPrefix}-print" title="طباعة">🖨️</button>
      <button class="btn btn-icon" id="${idPrefix}-pdf" title="PDF">📄</button>
      <button class="btn btn-icon" id="${idPrefix}-excel" title="Excel">📊</button>
      <button class="btn btn-icon" id="${idPrefix}-whatsapp" title="إرسال واتساب">📤</button>
    `;
  }

  // getData هي دالة (async) تُرجع بيانات آخر تقرير مُعروض، أو null إن لم يُعرض شيء بعد
  function bindToolbar(idPrefix, getData) {
    async function withData(fn) {
      const data = await getData();
      if (!data) { Utils.toast('اضغط "عرض" أولًا لعرض التقرير قبل الطباعة أو التصدير', 'error'); return; }
      fn(data);
    }
    document.getElementById(`${idPrefix}-print`).addEventListener('click', () => withData(print));
    document.getElementById(`${idPrefix}-pdf`).addEventListener('click', () => withData(print));
    document.getElementById(`${idPrefix}-excel`).addEventListener('click', () => withData(exportExcel));
    document.getElementById(`${idPrefix}-whatsapp`).addEventListener('click', () => withData(shareWhatsApp));
  }

  function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  /* -------------------- تحويل الأرقام إلى كلمات عربية -------------------- */
  const ONES = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة', 'عشرة',
    'أحد عشر', 'اثنا عشر', 'ثلاثة عشر', 'أربعة عشر', 'خمسة عشر', 'ستة عشر', 'سبعة عشر', 'ثمانية عشر', 'تسعة عشر'];
  const TENS = ['', '', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون'];
  const HUNDREDS = ['', 'مائة', 'مئتان', 'ثلاثمائة', 'أربعمائة', 'خمسمائة', 'ستمائة', 'سبعمائة', 'ثمانمائة', 'تسعمائة'];
  const SCALES = [null,
    { singular: 'ألف', dual: 'ألفان', plural: 'آلاف' },
    { singular: 'مليون', dual: 'مليونان', plural: 'ملايين' },
    { singular: 'مليار', dual: 'ملياران', plural: 'مليارات' }];

  function threeDigitsToWords(n) {
    const parts = [];
    const h = Math.floor(n / 100), rem = n % 100;
    if (h) parts.push(HUNDREDS[h]);
    if (rem) {
      if (rem < 20) parts.push(ONES[rem]);
      else {
        const t = Math.floor(rem / 10), o = rem % 10;
        parts.push(o ? `${ONES[o]} و${TENS[t]}` : TENS[t]);
      }
    }
    return parts.join(' و');
  }

  function integerToArabicWords(num) {
    num = Math.floor(num);
    if (num === 0) return 'صفر';
    const chunks = [];
    let n = num;
    while (n > 0) { chunks.push(n % 1000); n = Math.floor(n / 1000); }
    const parts = [];
    for (let i = chunks.length - 1; i >= 0; i--) {
      const c = chunks[i];
      if (!c) continue;
      if (i === 0) { parts.push(threeDigitsToWords(c)); continue; }
      const scale = SCALES[i];
      if (c === 1) parts.push(scale.singular);
      else if (c === 2) parts.push(scale.dual);
      else if (c >= 3 && c <= 10) parts.push(`${threeDigitsToWords(c)} ${scale.plural}`);
      else parts.push(`${threeDigitsToWords(c)} ${scale.singular}`);
    }
    return parts.join(' و');
  }

  // مبلغ (رقم) + اسم العملة + اسم الفكة => نص عربي كامل
  function amountToWords(amount, currencyName, subunitName) {
    amount = Math.abs(Number(amount) || 0);
    const intPart = Math.floor(amount);
    const fracPart = Math.round((amount - intPart) * 100);
    let text = `${integerToArabicWords(intPart)} ${currencyName || ''}`.trim();
    if (fracPart > 0) text += ` و${integerToArabicWords(fracPart)} ${subunitName || 'هللة'}`;
    return text;
  }

  /* -------------------- الترويسة (نفس تصميم واحد لكل التقارير) -------------------- */
  async function buildLetterheadHtml(title, dateRangeText) {
    const settings = await ScreenReports.getPrintSettings();
    const s = await FarisDB.get(STORES.SETTINGS, 'main') || {};
    if (settings.reportShowHeader === false) {
      return `<h2 class="lh-title-standalone">${escapeHtml(title)}</h2><div class="print-subtitle">${escapeHtml(dateRangeText || '')}</div>`;
    }
    return `
      <div class="print-letterhead">
        <div class="lh-row">
          <div class="lh-ar">${[s.arLine1, s.arLine2, s.arLine3].filter(Boolean).map(l => `<div>${escapeHtml(l)}</div>`).join('')}</div>
          <div class="lh-logo">${s.logo ? `<img src="${s.logo}">` : ''}</div>
          <div class="lh-en" dir="ltr">${[s.enLine1, s.enLine2, s.enLine3].filter(Boolean).map(l => `<div>${escapeHtml(l)}</div>`).join('')}</div>
        </div>
        <div class="lh-title-row">${escapeHtml(title)}</div>
        <div class="lh-date-row">${escapeHtml(dateRangeText || '')}</div>
      </div>`;
  }

  function buildAccountInfoHtml(info) {
    if (!info) return '';
    const prefix = info.labelPrefix ? ` ${info.labelPrefix}` : '';
    return `
      <table class="account-info-bar"><tr>
        <td class="aib-code"><b>رقم الحساب${prefix}:</b> <span class="acc-code">${escapeHtml(info.accountCode || '—')}</span></td>
        <td class="aib-name"><b>اسم الحساب${prefix}:</b> ${escapeHtml(info.accountName || '—')}</td>
        <td class="aib-currency"><b>${info.currencyLabel !== undefined ? 'العملة:' : ''}</b> ${info.currencyLabel !== undefined ? escapeHtml(info.currencyLabel || '—') : ''}</td>
      </tr></table>`;
  }

  function computeColumnCount(block) {
    if (block.headerRows) return block.headerRows[0].reduce((s, c) => s + (c.colspan || 1), 0);
    return (block.headers || []).length || 1;
  }

  function buildTableHtml(block, repeatHeaderHtml) {
    let theadHtml = '';
    if (repeatHeaderHtml) {
      theadHtml += `<tr class="repeat-header-row"><th colspan="${computeColumnCount(block)}">${repeatHeaderHtml}</th></tr>`;
    }
    if (block.headerRows) {
      theadHtml += block.headerRows.map(row => `<tr>${row.map(c => `<th ${c.colspan ? `colspan="${c.colspan}"` : ''} ${c.rowspan ? `rowspan="${c.rowspan}"` : ''}>${escapeHtml(c.text)}</th>`).join('')}</tr>`).join('');
    } else {
      theadHtml += `<tr>${(block.headers || []).map(h => `<th>${escapeHtml(h)}</th>`).join('')}</tr>`;
    }
    const bodyHtml = (block.rows || []).map(r => `<tr>${r.map(c => `<td>${escapeHtml(c)}</td>`).join('')}</tr>`).join('')
      || `<tr><td colspan="${computeColumnCount(block)}" style="text-align:center;color:#888;">لا توجد بيانات</td></tr>`;

    let footHtml = '';
    if (block.totals) {
      const t = block.totals;
      footHtml += `<tfoot>`;
      if (t.summaryRow) footHtml += `<tr class="totals-row">${t.summaryRow.map(c => `<td>${escapeHtml(c)}</td>`).join('')}</tr>`;
      footHtml += `</tfoot>`;
    }

    return `<table class="report-table ${block.tableClass || ''}"><thead>${theadHtml}</thead><tbody>${bodyHtml}</tbody>${footHtml}</table>`;
  }

  function buildBalanceWordsHtml(block) {
    if (!block.totals || block.totals.balance === undefined) return '';
    const balance = block.totals.balance;
    const label = balance > 0 ? 'إجمالي الرصيد عليكم' : (balance < 0 ? 'إجمالي الرصيد لكم' : 'الرصيد متساوٍ (لا يوجد مستحق)');
    return `
      <table class="balance-words-box"><tr>
        <td class="bw-label">${escapeHtml(label)} :</td>
        <td class="bw-amount">${escapeHtml(block.totals.balanceFormatted)}</td>
      </tr><tr>
        <td colspan="2" class="bw-words">${escapeHtml(block.totals.balanceWords)}</td>
      </tr></table>`;
  }

  const SIGNATURE_ROLES = ['المحاسب', 'المراجع', 'المدير المالي', 'المدير العام'];

  function buildSignaturesHtml(certText) {
    return `
      <table class="signatures-box">
        <tr><td colspan="${SIGNATURE_ROLES.length}" class="cert-note">${escapeHtml(certText)}</td></tr>
        <tr>${SIGNATURE_ROLES.map(r => `<td class="sig-cell">${r}</td>`).join('')}</tr>
        <tr>${SIGNATURE_ROLES.map(() => `<td class="sig-line"></td>`).join('')}</tr>
      </table>`;
  }

  function buildPageFooterHtml(printedBy) {
    const now = new Date();
    const dateStr = now.toLocaleDateString('ar');
    const timeStr = now.toLocaleTimeString('ar');
    return `
      <div class="print-page-footer">
        <span>طبع بواسطة: ${escapeHtml(printedBy || '')}</span>
        <span class="pf-page"></span>
        <span>تاريخ التقرير: ${escapeHtml(dateStr)} ${escapeHtml(timeStr)}</span>
      </div>`;
  }

  async function getPrintedByName() {
    try {
      const session = await FarisDB.get(STORES.SESSION, 'current');
      if (session && session.userId) {
        const user = await FarisDB.get(STORES.USERS, session.userId);
        if (user) return user.userName;
      }
    } catch (e) { /* تجاهل */ }
    return '';
  }

  /* -------------------- الطباعة الرئيسية --------------------
     data = {
       title, fromDate, toDate,
       blocks: [ { accountCode, accountName, currencyLabel, headers|headerRows, rows, totals, showSignatures } ],
       headers, rows, footerRow   // شكل مبسّط (تقارير غير كشف الحساب) يُحوَّل تلقائيًا لبلوك واحد
     }
  ------------------------------------------------------------- */
  function normalizeBlocks(data) {
    if (data.blocks) return data.blocks;
    return [{
      headers: data.headers,
      rows: data.rows,
      totals: data.footerRow ? { summaryRow: data.footerRow } : null
    }];
  }

  async function print(data) {
    const settings = await ScreenReports.getPrintSettings();
    const paper = settings.reportPaperSize || 'A4';
    const orientation = settings.reportOrientation || 'portrait';
    const marginTop = settings.reportMarginTop ?? 14;
    const marginRight = settings.reportMarginRight ?? 14;
    const marginBottom = settings.reportMarginBottom ?? 14;
    const isInvoice = data.documentKind === 'invoice';
    const marginLeft = isInvoice ? marginRight : (settings.reportMarginLeft ?? 14);
    const isPlain = settings.reportColorMode === 'عادي';
    const dateRangeText = data.fromDate || data.toDate ? `من تاريخ : ${data.fromDate || '—'}    إلى تاريخ : ${data.toDate || '—'}` : (data.subtitle || '');
    // extraHeaderHtml/extraFooterHtml: تُستخدم لمستندات ذات شكل مخصص (فواتير/مرتجعات) تحتاج صفوفًا محدَّدة
    // أسفل الشعار مباشرة وتذييلًا خاصًا أسفل الجدول، بدل السطر التلقائي الواحد وتذييل الجدول العادي
    const letterheadHtml = data.extraHeaderHtml
      ? (await buildLetterheadHtml(data.title, '')).replace('<div class="lh-date-row"></div>', '') + data.extraHeaderHtml
      : await buildLetterheadHtml(data.title, dateRangeText);
    const printedBy = await getPrintedByName();
    const blocks = normalizeBlocks(data);

    const s = await FarisDB.get(STORES.SETTINGS, 'main') || {};
    const certText = (s.extraField && s.extraField.trim()) || 'يعتبر هذا الكشف صحيحًا مالم يتم الرد عليه خلال 15 يوم';

    const style = `
      @page { size: ${paper} ${orientation}; margin: ${marginTop}mm ${marginLeft}mm ${marginBottom}mm ${marginRight}mm; }
      * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; color-adjust: exact !important; }
      body{font-family:Tajawal,Arial,sans-serif;direction:rtl;color:#1F2A24;padding:0;font-size:12px}
      *{-webkit-print-color-adjust:exact;print-color-adjust:exact;color-adjust:exact}
      .print-letterhead{border:2px solid #333;border-radius:10px;padding:8px 14px;margin-bottom:10px}
      .lh-row{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #999;padding-bottom:6px;margin-bottom:6px}
      .lh-ar{text-align:right;font-weight:700;font-size:12px;line-height:1.5}
      .lh-en{text-align:left;font-weight:700;font-size:12px;line-height:1.5;direction:ltr}
      .lh-logo img{width:55px;height:55px;max-width:55px;max-height:55px;object-fit:cover;border-radius:50%;border:2px solid #777;display:inline-block;overflow:hidden}
      .lh-logo{width:59px;height:59px;display:flex;align-items:center;justify-content:center;flex:0 0 59px}
      table.report-table.invoice-table{border:2px solid #222;border-collapse:collapse}
      table.report-table.invoice-table th,table.report-table.invoice-table td{border:1.5px solid #222}
      .lh-title-row{text-align:center;font-weight:800;font-size:15px;font-family:Cairo,Arial,sans-serif;padding:4px 0}
      .lh-date-row{text-align:center;font-size:12px;color:#333}
      .lh-title-standalone{font-family:Cairo,Arial,sans-serif;margin:0 0 2px}
      .print-subtitle{color:#555;margin-bottom:10px;font-size:12px}

      .account-info-bar{width:100%;border:1px solid #333;border-collapse:collapse;margin:8px 0;font-size:12px;table-layout:fixed}
      .account-info-bar td{padding:5px 10px;border:1px solid #333}
      .aib-code{width:22%}
      .aib-name{width:56%}
      .aib-currency{width:22%}
      .acc-code{color:#B3452D;font-weight:800}

      table.report-table{width:100%;border-collapse:collapse;font-size:11.5px;margin-bottom:6px;color:#000}
      table.report-table th,table.report-table td{border:1.5px solid #444;padding:5px 7px;text-align:right}
      table.report-table.invoice-table th,table.report-table.invoice-table td{border:1.5px solid #222}
      table.report-table th{background:#BEE7F5;color:#111;font-size:13px;font-weight:700}
      table.report-table td{color:#111}
      table.report-table.summary-style th{background:#BEE7F5;color:#111;font-size:13px;font-weight:700}
      table.report-table tfoot td{font-weight:bold;background:#eef1f7;color:#111}

      table.balance-words-box{width:100%;border-collapse:collapse;margin-bottom:10px;font-size:12px}
      table.balance-words-box td{border:1px solid #333;padding:6px 10px}
      .bw-label{width:170px;font-weight:700;background:#f5f5f5}
      .bw-amount{font-weight:800;color:#1e3a8a}
      .bw-words{color:#333}

      table.signatures-box{width:100%;border-collapse:collapse;margin-top:16px;font-size:12px}
      .cert-note{text-align:center;padding:8px;border:1px solid #333;background:#fafafa}
      .sig-cell{text-align:center;font-weight:700;padding-top:26px;border-top:1px solid #333}
      .sig-line{height:20px}

      .print-page-footer{display:flex;justify-content:space-between;border-top:1px solid #999;padding-top:6px;margin-top:16px;font-size:11px;color:#555}
      .block-separator{border:none;border-top:2px dashed #999;margin:16px 0}

      /* صفوف هيدر مخصصة للمستندات (فواتير/مرتجعات): 3 أعمدة يمين/وسط/يسار */
      .doc-header-row{display:flex;justify-content:space-between;align-items:center;font-size:12.5px;padding:4px 0;border-bottom:1px dashed #ccc}
      .doc-header-row .dh-right{text-align:right;flex:1}
      .doc-header-row .dh-center{text-align:center;flex:1;font-weight:800;font-family:Cairo,Arial,sans-serif}
      .doc-header-row .dh-left{text-align:left;flex:1;direction:ltr}
      .doc-header-row b{font-weight:800}

      /* تذييل مخصص للمستندات: أسطر تفاصيل الإجمالي بمحاذاة اليسار */
      .doc-footer-lines{margin-top:10px;font-size:12.5px}
      .doc-footer-lines .df-line{padding:3px 0;display:flex;justify-content:flex-end;gap:6px}
      .doc-footer-lines .df-line b{font-weight:800}
      .doc-footer-lines .df-customer-balances{break-inside:avoid;text-align:start}
      .doc-footer-lines .df-balance{justify-content:flex-start;flex-wrap:wrap}
      .invoice-frame{border:2px solid #222;padding:10px;box-sizing:border-box;width:100%}
      .invoice-frame .df-summary-row{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:12px;align-items:baseline;break-inside:avoid}
      .invoice-frame .df-summary-row .df-line{min-width:0;flex-wrap:wrap}
      .invoice-frame .df-total{text-align:end}
      .doc-footer-lines .df-words{padding-top:6px;border-top:1px solid #ccc;margin-top:4px;display:block;text-align:right}

      table.report-table thead { display: table-header-group; }
      table.report-table tfoot { display: table-footer-group; }
      tr.repeat-header-row th { background:#fff !important; padding:0; border:none; text-align:right; font-weight:normal; }
      tr.repeat-header-row .print-letterhead { margin-bottom:6px; }
      tr.repeat-header-row .account-info-bar { margin:0 0 8px; }
      ${isPlain ? `
        .print-letterhead, table.report-table th, table.report-table.summary-style th,
        table.report-table tfoot td, .bw-label, .cert-note { background:#fff !important; color:#000 !important; }
        img { filter: grayscale(100%); }
      ` : ''}
    `;

    const blocksHtml = blocks.map((b, i) => {
      const accountInfoHtml = buildAccountInfoHtml(b.accountCode ? b : (b.infoRow ? { ...b.infoRow, labelPrefix: 'الفرعي' } : null));
      const repeatHeaderHtml = `${letterheadHtml}${accountInfoHtml}`;
      return `
      ${i > 0 ? '<hr class="block-separator">' : ''}
      ${buildTableHtml({ ...b, tableClass: isInvoice ? 'invoice-table' : (data.reportKind === 'اجمالي') ? 'summary-style' : '' }, repeatHeaderHtml)}
      ${buildBalanceWordsHtml(b)}
      ${b.showSignatures ? buildSignaturesHtml(certText) : ''}
    `;
    }).join('');

    const contentHtml = `${blocksHtml}${data.extraFooterHtml || ''}${buildPageFooterHtml(printedBy)}`;
    const printHtml = `<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(data.title)}</title><style>${style}
      @media screen { body { margin: 12px; } }
      @media print { html, body { width: 100%; } }
      ${isInvoice ? '@media print { html, body { width:auto; margin:0; padding:0; } }' : ''}
      </style></head><body>${isInvoice ? `<div class="invoice-frame">${contentHtml}</div>` : contentHtml}</body></html>`;

    await Utils.printHtml(data.title || 'مستند', printHtml);
  }

  function exportExcel(data) {
    if (typeof XLSX === 'undefined') {
      Utils.toast('تعذّر تحميل مكتبة إكسل، تأكد من الاتصال بالإنترنت عند أول استخدام', 'error');
      return;
    }
    const blocks = normalizeBlocks(data);
    const wb = XLSX.utils.book_new();
    blocks.forEach((b, i) => {
      const sheetData = [b.headers || [], ...(b.rows || [])];
      if (b.totals && b.totals.summaryRow) sheetData.push(b.totals.summaryRow);
      const ws = XLSX.utils.aoa_to_sheet(sheetData);
      XLSX.utils.book_append_sheet(wb, ws, (b.accountName || `تقرير${i + 1}`).slice(0, 28));
    });
    XLSX.writeFile(wb, `${data.title || 'تقرير'}.xlsx`);
  }

  function shareWhatsApp(data) {
    // ملاحظة: بدون خادم، لا يمكن إرفاق ملف PDF فعلي عبر رابط واتساب — يتم إرسال ملخص نصي للتقرير بدلًا من ذلك
    const blocks = normalizeBlocks(data);
    let text = `${data.title}\n\n`;
    blocks.forEach(b => {
      if (b.accountName) text += `الحساب: ${b.accountName}\n`;
      text += (b.headers || []).join(' | ') + '\n';
      (b.rows || []).slice(0, 20).forEach(r => { text += r.join(' | ') + '\n'; });
      if ((b.rows || []).length > 20) text += `... و${b.rows.length - 20} سطر إضافي\n`;
      text += '\n';
    });
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  }

  return { toolbarHtml, bindToolbar, print, exportExcel, shareWhatsApp, amountToWords };
})();
