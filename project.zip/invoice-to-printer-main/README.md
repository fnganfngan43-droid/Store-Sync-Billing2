# نظام مدون حسابات

اسم التطبيق محاسب مطاور

ساعدني في عاده بنا Android Studio

وا 

تعديل آلية الطباعة داخل التطبيق بحيث:

يستدعي زر الطباعة خدمة الطباعة الأصلية في Android.

تظهر نافذة اختيار الطابعة الموجودة في الهاتف، بما فيها الطابعات المدعومة عبر Wi-Fi أو Bluetooth أو خدمات الطباعة المثبتة.

تُرسل الفاتورة أو التقرير إلى خدمة الطباعة مع الحفاظ على التنسيق والشعار.

تُطبّق المعالجة على جميع شاشات الطباعة، وليس على فواتير المبيعات فقط.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://invoice-to-printer.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/774a2906-4fda-4708-9b30-d9c5c7ebcf0e).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
