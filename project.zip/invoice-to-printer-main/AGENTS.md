<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep imported Faris account-statement calculations in its existing browser report module; the screen and print/export share the same report blocks to prevent divergent balances.
- Test imported browser reports with isolated ledger fixtures through their public render flow, without changing the user's accounting data.
- Keep invoice print presentation in its existing browser invoice module and shared print stylesheet; resolve missing unit labels on read without rewriting saved accounting records.
